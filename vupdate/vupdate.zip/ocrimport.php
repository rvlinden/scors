<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$aktie=$_REQUEST["aktie"];
$kidx="";if(isset($_REQUEST["kidx"])){$kidx=$_REQUEST["kidx"];}
$extensie="";if(isset($_REQUEST["extensie"])){$extensie=$_REQUEST["extensie"];}
if ($rechten!=="mo" and $rechten!=="sup" and $aktie!=="ocrimport"){exit();}

$dirslash="/";
$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsbeeldlog.txt";
$Key="";$zin="";$logzin="";
$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();

// Voer de import uit en maak een zin voor de logfile
if ($aktie=="ocrimport"){
	$user="ocrimport";
	function bewerktekst(){
		global $filenaam,$tekst;
		$tekst=file_get_contents ($filenaam);
		if(strlen($tekst)<1024*1024){
			// Replace diacritical characters for single-byte characters
			$replaceTable = array(
				'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
				'Å'=>'A', 'Æ'=>'Ae', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
				'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
				'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O',
				'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
				'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'Th',
				'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
				'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e',
				'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i',
				'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n', 'ò'=>'o',
				'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o',
				'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y',
				'þ'=>'th', 'ÿ'=>'y', chr(10)=>" ", chr(13)=>"", "^"=>"",
				"`"=>"", "“"=>"", ")"=>"", "("=>"", "]"=>"", "["=>"",
				"{"=>"", "}"=>"", "'"=>"", '"'=>'', '-'=>''
			);
			$tekst=strtr($tekst, $replaceTable);
			// verwijder ongeldige karakters in de inputstring
			$karyes=" abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-+=()@:;/?!,.";
			$strippedtekst="";
			for ($strip=0;$strip<strlen($tekst);$strip++){
				$eenkar=substr($tekst,$strip,1);
				if(!empty($eenkar)){
					if(strpos( $karyes,$eenkar)!==false){$strippedtekst=$strippedtekst.$eenkar;}
				}
			}
			$tekst=$strippedtekst;
			while(strpos($tekst,"  ")!==false){$tekst=str_replace("  "," ",$tekst);}
			while(strpos($tekst,"..")!==false){$tekst=str_replace("..",".",$tekst);}
		}
	}
	if (strpos($kidx,"-Jrg-")!==false and $extensie="pdf"){
	//Tijdschrift
		$logfile="log/scorsttlog.txt";
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/tt.mdb","","");
		$filenaam="ocr/out/".str_replace(".pdf",".txt",$kidx);$tekst=""; //kidx is filenaam met extensie
		bewerktekst();
	// Zoek de bijbehorende Key en andere gegevens
		$kidxkaal=str_replace(".pdf","",$kidx);
		$fprs=odbc_exec($objConnect,"SELECT * FROM tt WHERE filenaam='".$kidxkaal."'");
		while($row = odbc_fetch_array($fprs)){; //Tijdschrift kan intussen verwijderd zijn
			$Key=$row["Key"];
		// Gooi oude OCR records weg
			$fprs=odbc_exec($objConnect,"DELETE FROM ocr2 WHERE Key=".strval($Key));
			$volgnummer=1;$eristekst=false;
			//Maak nieuwe records aan in database en vul velden
			while (strlen($tekst)>0){
				$eristekst=true;
				if (strlen($tekst)>64000){	$tekstdeel=substr($tekst,0,64000);$tekst=substr($tekst,64000);}
				else{$tekstdeel=$tekst;$tekst="";}
				$fprs=odbc_exec($objConnect,"INSERT INTO ocr2 (Key,volgnummer,tekst) VALUES (".strval($Key).",'".strval($volgnummer)."','".$tekstdeel."')");
				$volgnummer++;
			}
		// gooi evt. oude pdf weg
			error_reporting(0);
			unlink("TTD/".$kidx);
			error_reporting(-1);
		//kopieer de PDF naar TTD
			copy("ocr/out/".$kidx, "TTD/".$kidx);
			
		//Cleanup in/out
			unlink("ocr/out/".$kidx);
			unlink("ocr/out/".str_replace(".pdf",".txt", $kidx));

			if($eristekst){$logzin=$zinTime." OCR tekst toegevoegd voor tijdschrift ".$kidx;}
			else{$logzin=$zinTime." OCR scan heeft geen tekst gevonden in tijdschrift ".$kidx;}
		}
	}else if(strpos($kidx,"BP-")!==false){
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/bidprent.mdb","","");
		if($extensie=="txt"){$kidx=substr($kidx,4);} //bij .txt is kidx out/file.txt
		$kidx=substr($kidx,0,16); // kidx is nu filenaam in map ocr/out zonder extensie
		$filenaam="ocr/out/".$kidx.".txt";$tekst="";
		bewerktekst();
		
		//Maak nieuwe records van elk max 64KB aan in database en vul velden
		//zoek het record waar kidx nu in zit
		$delcheck=odbc_exec($objConnect,"SELECT * FROM archief WHERE foto1&' '&foto2&' '&foto3&' '&foto4&' '&foto5&' '&foto6&' '&foto7&' '&foto8&' '&foto9&' '&foto10&' '&foto11&' '&foto12 like '%".substr($kidx,3)."%'");
		$eristekst=false;
		while($row=odbc_fetch_array($delcheck)){ //foto kan intussen verwijderd zijn
			$volgnummer=1;
			while (strlen($tekst)>0){
				$eristekst=true;
				if (strlen($tekst)>64000){	$tekstdeel=substr($tekst,0,64000);$tekst=substr($tekst,64000);}
				else{$tekstdeel=$tekst;$tekst="";}
				$hulpkidx=substr($kidx,3);
				$fprs=odbc_exec($objConnect,"INSERT INTO ocr (kidx,tekstdeel, volgnummer) VALUES ('".$hulpkidx.".pdf','".$tekstdeel."',".strval($volgnummer) .")");
				$volgnummer++;
			}
			if($eristekst and $extensie=="pdf"){
				//wijzig de bestandsnaam in het originele record in .pdf en maak een nieuwe thumbnail
				$Key=$row["Key"];
				//vind het fotonummer
				for($i=1;$i<=12;$i++){
					$fotonaam=$row["foto".strval($i)];
					$thumbnaam=$row["thumb".strval($i)];
					if(strpos($fotonaam,$hulpkidx)!==false){
						$fprs=odbc_exec($objConnect,"UPDATE archief set foto".strval($i)."='".$hulpkidx.".pdf' WHERE Key=".strval($Key));
						// maak nieuwe thumbnail
						$thumbsmap="./BPT/".substr($fotonaam,0,3) . "/";
						$thumbfile=$thumbsmap.$thumbnaam;
						$im = new imagick();
						$im->setResolution( 300, 300);
						$im->readImage($thumbfile.'[0]');
						$im->setImageFormat('jpg');
						$draw = new ImagickDraw();
						$draw->setFillColor('red');
						$draw->setFont('Arial');
						$draw->setFontSize( 18 );
						$im->annotateImage($draw, 4, $im->getImageHeight()-4, 0, 'PDF');
						unlink($thumbfile);
						$im->writeImage($thumbfile);
						unset ($im);
						break;
					}
				}
				//kopieer de PDF naar AAD
				copy("ocr/out/".$kidx.".pdf", "BPD/".substr($hulpkidx,0,3)."/".$hulpkidx.".pdf");
			}
		}
		//verwijder tekstfile en pdffile uit queue
		if($extensie=="pdf"){unlink("ocr/out/".$kidx.".pdf");}
		unlink("ocr/out/".$kidx.".txt");
		if($eristekst){$zin=" OCR tekst toegevoegd voor archiefdocument #".$hulpkidx;}
		else{$zin=" OCR scan heeft geen tekst gevonden in archiefdocument #".$hulpkidx;}
		$logzin=$zin;
	}else{
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
		if($extensie=="txt"){$kidx=substr($kidx,4);} //bij .txt is kidx out/file.txt
		$kidx=substr($kidx,0,13); // kidx is nu filenaam in map ocr/out zonder extensie
		$filenaam="ocr/out/".$kidx.".txt";$tekst="";
		bewerktekst();
		
		//Maak nieuwe records van elk max 64KB aan in database en vul velden
		//zoek het record waar kidx nu in zit
		$delcheck=odbc_exec($objConnect,"SELECT * FROM archief WHERE foto1&' '&foto2&' '&foto3&' '&foto4&' '&foto5&' '&foto6&' '&foto7&' '&foto8&' '&foto9&' '&foto10&' '&foto11&' '&foto12 like '%".$kidx."%'");
		$eristekst=false;
		while($row=odbc_fetch_array($delcheck)){ //foto kan intussen verwijderd zijn
			$volgnummer=1;
			while (strlen($tekst)>0){
				$eristekst=true;
				if (strlen($tekst)>64000){	$tekstdeel=substr($tekst,0,64000);$tekst=substr($tekst,64000);}
				else{$tekstdeel=$tekst;$tekst="";}
				$fprs=odbc_exec($objConnect,"INSERT INTO ocr (kidx,tekstdeel, volgnummer) VALUES ('".$kidx.".pdf','".$tekstdeel."',".strval($volgnummer) .")");
				$volgnummer++;
			}
			if($eristekst and $extensie=="pdf"){
				//wijzig de bestandsnaam in het originele record in .pdf en maak een nieuwe thumbnail
				$Key=$row["Key"];
				//vind het fotonummer
				for($i=1;$i<=12;$i++){
					$fotonaam=$row["foto".strval($i)];
					$thumbnaam=$row["thumb".strval($i)];
					if(strpos($fotonaam,$kidx)!==false){
						$fprs=odbc_exec($objConnect,"UPDATE archief set foto".strval($i)."='".$kidx.".pdf' WHERE Key=".strval($Key));
						// maak nieuwe thumbnail
						$thumbsmap="./AAT/".substr($fotonaam,0,3) . "/";
						$thumbfile=$thumbsmap.$thumbnaam;
						$im = new imagick();
						$im->setResolution( 300, 300);
						$im->readImage($thumbfile.'[0]');
						$im->setImageFormat('jpg');
						$draw = new ImagickDraw();
						$draw->setFillColor('red');
						$draw->setFont('Arial');
						$draw->setFontSize( 18 );
						$im->annotateImage($draw, 4, $im->getImageHeight()-4, 0, 'PDF');
						unlink($thumbfile);
						$im->writeImage($thumbfile);
						unset ($im);
						break;
					}
				}
				//kopieer de PDF naar AAD
				copy("ocr/out/".$kidx.".pdf", "AAD/".substr($kidx,0,3)."/".$kidx.".pdf");
			}
		}
		//verwijder tekstfile en pdffile uit queue
		if($extensie=="pdf"){unlink("ocr/out/".$kidx.".pdf");}
		unlink("ocr/out/".$kidx.".txt");
		if($eristekst){$zin=" OCR tekst toegevoegd voor archiefdocument #".$kidx;}
		else{$zin=" OCR scan heeft geen tekst gevonden in archiefdocument #".$kidx;}
		$logzin=$zin;
	}
}

// Update logfile
if(strlen($logzin)>0){
	$logzin=$zinDate." ".$zinTime." ".$logzin.chr(13).chr(10);
	//		error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	fwrite($oTextFile,$logzin);
	fclose($oTextFile);
	//		error_reporting(-1);
}
if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
	$newname=$logfile." ".$zinDate." ".$zinTime.".txt";
	echo "<br>Log recycled: ".$newname;
	rename ($logfile,$newname);
}

// Close connection
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
?>