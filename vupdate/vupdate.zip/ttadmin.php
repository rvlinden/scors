<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

if ($rechten!="mo" and $rechten!=="sup"){exit();}

$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsttlog.txt";
$Key="";$zin="";$aktie="";$naam="";$pg="";$sort="";$term="";$doel="";
$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/tt.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();

//Check of OCR enabled
$ocr=$row["txt"];

$afbdir="TTD/";$thumbsdir="TTT/";

function diak($inputString) {
    // Replace diacritical characters for single-byte characters
    $replaceTable = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
        'Å'=>'A', 'Æ'=>'Ae', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
        'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
        'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O',
        'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'Th',
        'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
        'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e',
        'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i',
        'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n', 'ò'=>'o',
        'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o',
        'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y',
        'þ'=>'th', 'ÿ'=>'y', '"'=>'', "'"=>''
    );
    $inputString=strtr($inputString, $replaceTable);
	iconv('UTF-8', 'ASCII//TRANSLIT', $inputString);
	// verwijder ongeldige karakters in de inputstring
	$karyes="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-1234567890.,()= :";
	for ($i=0;$i<strlen($inputString);$i++){
		$hulp=substr($inputString,$i,1);
		if (strpos($karyes, $hulp)===false){
			$inputString=str_replace($hulp," ",$inputString);
		}
	}
	$inputString=trim(str_replace("  "," ",$inputString));
    return $inputString;
}

if (isset($_REQUEST["pg"])){$pg=$_REQUEST["pg"];}
if (isset($_REQUEST["sort"])){$sort=$_REQUEST["sort"];}
if (isset($_REQUEST["aktie"])){$aktie=$_REQUEST["aktie"];}
if (isset($_REQUEST["Key"])){$Key=$_REQUEST["Key"];}
if (isset($_REQUEST["naam"])){$naam=$_REQUEST["naam"];}
if (isset($_REQUEST["term"])){$term=$_REQUEST["term"];}

if($_SERVER['REQUEST_METHOD']=="POST"){
	
// Lees de aktie die moet worden uitgevoerd: 
// nieuw: voeg gegevens uit formulier voor nieuwe TT toe in database
// edit: wijzig gegevens
	$jaar=diak($_POST["jaar"]);
	$maand=$_POST["maand"];
	$jaargang=diak($_POST["jaargang"]);
	$naamtt=diak($_POST["naamtt"]);
	if(isset($_POST["doel"])){$doel=$_POST["doel"];}
	if($doel==""){$doel="e";}
	$no=diak($_POST["no"]);if($no==""){$no="X";}
	$extratitel=str_replace(","," ",str_replace("+"," ",$_POST["extratitel"]));
	$extratitel=diak(str_replace("%20"," ",$extratitel));
	$naamtt=diak(str_replace("%20"," ",$naamtt));
	if($extratitel==""){$extratitel="X";}
	if(isset($_POST["filenaam"]) and strlen($_FILES["orgfilename"]["tmp_name"])==0){$filenaam=$_POST["filenaam"];}
	else{
		$filenaam=$naamtt."-".strval($jaar)."-".strval($maand)."-Jrg-".strval($jaargang)."-No-".strval($no)."-".$extratitel;
		$filenaam=str_replace(" ","-",$filenaam);
	}
	if($aktie=="edit"){
		$fprs=odbc_exec($objConnect,"UPDATE tt SET tse=".strval($diffSeconds).",aanpasser='".$user."',doel='".$doel."',naamtt='".$naamtt."',jaar='".$jaar."',maand='".$maand."',jaargang='".$jaargang."',nummer='".$no."',extratitel='".$extratitel."',filenaam='".$filenaam."' WHERE Key=".strval($Key));
		$zin="Tijdschrift indexnr ".$Key." ".$naamtt." ".$jaar." ".$maand." ".$no." ".$extratitel." aangepast";
	}else if($aktie=="nieuw"){
		$fprs=odbc_exec($objConnect,"INSERT INTO tt (doel,naamtt,jaar,maand,jaargang,nummer,extratitel,Key,filenaam,toevoeger,ts,tse) VALUES ('".$doel."','".$naamtt."','".$jaar."','".$maand."','".$jaargang."','".$no."','".$extratitel."','".strval($Key)."','".$filenaam."','".$user."',".strval($diffSeconds).",".strval($diffSeconds).")");
		$zin="Tijdschrift indexnr ".$Key." ".$naamtt." ".$jaar." ".$maand." ".$no." ".$extratitel." toegevoegd";
	}
//plaats upload, indien die bestaat, in map ful
	if(strlen($_FILES["orgfilename"]["tmp_name"])>0){
		$fulname="ful/".$filenaam.".pdf";
		move_uploaded_file($_FILES["orgfilename"]["tmp_name"], $fulname);
		$pdfname=$filenaam.".pdf";
		$thumbname=$filenaam.".jpg";
		$filesmap="TTD/";
		$thumbsmap="TTT/";
// Gooi evt. oude thumb weg
		error_reporting(0);
		unlink($thumbsmap.$thumbname);
		error_reporting(-1);
// Maak thumbnail van PDF
		$im = new imagick();
		$im->setResolution( 300, 300);
		$im->setOption('pdf:use-cropbox', 'true');
		$im->readImage($fulname.'[0]');
		$im->setImageFormat('jpg');
		$im->setImageBackgroundColor('white');
		$im->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
		$im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
		$im->thumbnailImage(175,247,true);
		$im->transformImageColorspace(Imagick::COLORSPACE_SRGB);
		$im->writeImage($thumbsmap.$thumbname);
		unset ($im);
		if($ocr!=""){ // Kopieer het nieuwe bestand van ful naar OCR map
			rename($fulname, "ocr/".$pdfname);
		}
	}
}else if ($aktie=="del"){
	$fprs=odbc_exec($objConnect, "SELECT filenaam FROM tt WHERE Key=".strval($Key));
	while($row = odbc_fetch_array($fprs)){$filenaam=$row["filenaam"];}
	$fprs=odbc_exec($objConnect,"DELETE FROM tt WHERE Key=".strval($Key));
	$fprs=odbc_exec($objConnect,"DELETE FROM ocr2 WHERE Key=".strval($Key));
	error_reporting(0);
	$naamfile="TTD/".$filenaam.".pdf";
	unlink($naamfile);
	$naamfile="TTT/".$filenaam.".jpg";
	unlink($naamfile);
	error_reporting(-1);
	$zin="Tijdschrift indexnr ".$Key." ".$naam." verwijderd";
}else if ($aktie=="vulnamen"){
	$fprs=odbc_exec($objConnect, "SELECT DISTINCT naamtt FROM tt WHERE naamtt like '%".$term."%' ORDER BY naamtt ASC");
	//Retourneer het resultaat in de vorm ["<resultaat1>","<resultaat2>","<enz.>"]
	$i=0;
	echo "[";
	while($row = odbc_fetch_array($fprs)){
	    if($i==1){echo ",";}
		echo chr(34).$row["naamtt"].chr(34);
		$i = 1;
	}
	echo "]";
}

// Close connection
unset($fprs);
odbc_close($objConnect);
unset($objConnect);

if($aktie!=="vulnamen"){
	// Update logfile
	$zin=$zinTime." ".$zin;
	$zin=$zinDate." ".$zin.chr(13).chr(10);
	//	error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	fwrite($oTextFile,$bronadres." ".$_COOKIE["user"].":".$zin);
	fclose($oTextFile);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsttlog_".$zinDate."_".$zinTime.".txt";
		rename ($logfile,$newname);
		$oTextFile = fopen($logfile, "a");
		fwrite($oTextFile,"Log recycled: ".$newname.chr(13).chr(10));
		fclose($oTextFile);
	}
	// error_reporting(-1);
	// ga terug naar lijst
	echo "OK";
} ?>