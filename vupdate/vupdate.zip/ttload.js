var vlinden = "https://"+new URL(document.currentScript.src).host+"/";
var head = document.getElementsByTagName('head')[0];
var insertpoint = document.getElementById('ttscript');
var style;var script;
style=document.createElement('link');style.rel = 'stylesheet';style.href = vlinden+'scors.css';head.appendChild(style);
script=document.createElement('script');script.src = vlinden + "tt.js";insertpoint.appendChild(script);