<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//redirect HTTP naar HTTPS
if (! isset($_SERVER['HTTPS']) or $_SERVER['HTTPS'] == 'off') {
    $redirect_url = "https://" . $_SERVER['HTTP_HOST'] . "/". $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url");
    exit();
}
//plaats huidige domeinnaam in bestand ocr/domein.scors
$oTextFile = fopen("ocrtools/domein.scors", "w");fwrite($oTextFile,$_SERVER["HTTP_HOST"]);fclose($oTextFile);
//genereer logfiles als die nog niet bestaan
$oTextFile = fopen("log/scorsaanvullog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorsaudiovideolog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorsbeeldlog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorsbidlog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorslogonlog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorssetuplog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorszoeklog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorsbpzoeklog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);

$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
$bidConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/bidprent.mdb","","");
$rechten="";$wijzig="settings";
//check of is ingelogd
if(isset($_COOKIE['user'])){$user=$_COOKIE['user'];}
if(isset($_COOKIE['logon'])){$rechten=$_COOKIE['logon'];}
if ($rechten!=="sup"){
	$fprs=odbc_exec($defConnect,"SELECT * FROM users ORDER BY user ASC");
	$nummer=1;while($row = odbc_fetch_array($fprs)){$nummer++;}
	odbc_free_result($fprs);
	if($nummer==1){ //geen gebruikers gedefinieerd; maak nieuwe admin aan met wachtwoord admin
		$fprs=odbc_exec($defConnect,"INSERT INTO users (user,pass,rechten) VALUES ('admin','".password_hash('admin',PASSWORD_DEFAULT)."','sup')");
		odbc_free_result($fprs);
		$rechten="sup";setcookie("user", "admin");setcookie("logon", "sup");$wijzig="users";
		echo '<font size="4" style="color:red;">Nieuwe gebruiker Admin aangemaakt met wachtwoord Admin.<br>Pas zo spoedig mogelijk het wachtwoord aan en wijzig het admin-account in een geldig email adres.</font>';
	}else{
		header("Location: /");
	}
}

if (isset($_REQUEST["setupsave"])){ 
	$dirslash="/";
	$bronadres=$_SERVER["REMOTE_ADDR"];
	$zinDate=date("Y-M-d");
	$zinTime=date("h.i.s");
	$logfile="log".$dirslash."scorssetuplog.txt";
	$Key="";$tabel="";$veldnaam="";$veldinhoud="";$zin="";

	// Lees de aktie die moet worden uitgevoerd: 
	// edit,del,nieuw: update gegevens van lijsten
	if(isset($_REQUEST["aktie"])){$aktie=$_REQUEST["aktie"];}
	// Lees het record dat moet worden aangepast
	if(isset($_REQUEST["Key"])){$Key=strval($_REQUEST["Key"]);}
	// Lees in welke tabel het record moet worden aangepast
	if(isset($_REQUEST["tabel"])){$tabel=strval($_REQUEST["tabel"]);}
	// Lees in welk veld het record moet worden aangepast
	if(isset($_REQUEST["veldnaam"])){$veldnaam=strval($_REQUEST["veldnaam"]);}
	// Lees in welke tabel het record moet worden aangepast
	if(isset($_REQUEST["veldinhoud"])){$veldinhoud=strval($_REQUEST["veldinhoud"]);}
	// Lees de oude waarde van mappen of soorten n.a.v. een wijziging
	if(isset($_REQUEST["oudewaarde"])){$oudewaarde=strval($_REQUEST["oudewaarde"]);}

	// Voer de gevraagde aktie uit en maak een zin voor de logfile
	if ($aktie=="edit"){
		// verwijder ongeldige karakters in de veldinhoud
		$karyes="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?+-1234567890#.,/()=@_ ";
		for ($i=0;$i<strlen($veldinhoud);$i++){
			$hulp=substr($veldinhoud,$i,1);
			if (strpos($karyes, $hulp)===false){
				$veldinhoud=str_replace($hulp," ",$veldinhoud);
			}
		}
		$veldinhoud=trim(str_replace("  "," ",$veldinhoud));
		$fprs=odbc_exec($defConnect,"UPDATE ".$tabel." SET ".$veldnaam."='".$veldinhoud."' WHERE Key = ".strval($Key));
		$zin="Lijst ".$tabel." Key:".strval($Key)." ".$veldnaam." aangepast: ".$veldinhoud;
		odbc_free_result($fprs);
		if($tabel=="soorten"){
			$fprs=odbc_exec($objConnect, "UPDATE archief SET soort1='".$veldinhoud."' WHERE soort1='".$oudewaarde."'");
		}else if ($tabel=="soortenb"){
			$fprs=odbc_exec($bidConnect, "UPDATE archief SET soort1='".$veldinhoud."' WHERE soort1='".$oudewaarde."'");
		}else if ($tabel=="mappen"){
			$fprs=odbc_exec($objConnect, "UPDATE archief SET mapnr='".$veldinhoud."' WHERE mapnr='".$oudewaarde."'");
		}
	}else if ($aktie=="del"){
		$fprs=odbc_exec($defConnect,"DELETE FROM ".$tabel." WHERE Key = ".strval($Key));
		$zin="Lijst ".$tabel." verwijderd: ".$veldinhoud;
		odbc_free_result($fprs);
	}else if ($aktie=="nieuw" and $tabel=="users"){
		$fprs=odbc_exec($defConnect,"INSERT INTO users (user,pass,rechten) VALUES ('___nieuw___','".password_hash('*$frY&bJll32@c',PASSWORD_DEFAULT)."','ufa')");
		odbc_free_result($fprs);
		$zin="Lijst users nieuw item toegevoegd";
	}else if ($aktie=="nieuw" and $tabel=="mappen"){
		$fprs=odbc_exec($defConnect,"INSERT INTO mappen (mappen) VALUES ('___nieuw___')");
		odbc_free_result($fprs);
		$zin="Lijst mappen nieuw item toegevoegd";
	}else if ($aktie=="nieuw" and $tabel=="soorten"){
		$fprs=odbc_exec($defConnect,"INSERT INTO soorten (soorten,volgorde) VALUES ('___nieuw___','0')");
		odbc_free_result($fprs);
		$zin="Lijst soorten hoofdcollectie nieuw item toegevoegd";
	}else if ($aktie=="nieuw" and $tabel=="soortenb"){
		$fprs=odbc_exec($defConnect,"INSERT INTO soortenb (soortenb,volgordeb) VALUES ('___nieuw___','0')");
		odbc_free_result($fprs);
		$zin="Lijst soorten bidprentjes nieuw item toegevoegd";
	}else if ($aktie=="updatesettings"){
		$zin="Settings updated";
		$fields = [];$values = [];
		foreach ($_POST as $field => $value) {
			$fields[] = $field;$values[] = $value;
			if ($field=="basiskleur1"){$basiskleur1=$value;}
			if ($field=="basiskleur2"){$basiskleur2=$value;}
		}
		$fields = implode(',', $fields);$values = implode("','", $values);
		odbc_exec($defConnect,"DELETE * FROM settings");
		odbc_exec($defConnect, "INSERT INTO settings ($fields) VALUES ('$values')");
	}

	// Update logfile
	$zin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$_COOKIE["user"]." ".$zin.chr(13).chr(10);
	//		error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	fwrite($oTextFile,$zin);
	fclose($oTextFile);
	//		error_reporting(-1);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log".$dirslash."deflog_".$zinDate."_".$zinTime.".txt";
		echo "<br>Log recycled: ".$newname;
		rename ($logfile,$newname);
	}

}else{

	$fprs=odbc_exec($defConnect,"SELECT * from settings");
	$row = odbc_fetch_array($fprs);
	$sitenaam=$row["sitenaam"];
	$basiskleur1=$row["basiskleur1"];
	$basiskleur2=$row["basiskleur2"];
	odbc_free_result($fprs);
	unset($fprs);

	//Verwijder ongeoorloofde karakters van inputstrings
	//'Level 1 is strenger
	function cleaninput($ipar, $level){
		$acx=str_replace("<", "",$ipar);
		$acx=str_replace(">", "",$acx);
		$acx=str_replace(";", "",$acx);
		$acx=str_replace("]", "",$acx);
		$acx=str_replace("[", "",$acx);
		$acx=str_replace("{", "",$acx);
		$acx=str_replace("}", "",$acx);
		$acx=str_replace("%", "",$acx);
		$acx=str_replace("'", "",$acx);
		if ($level==1){
			$acx=str_replace("(", "",$acx);
			$acx=str_replace(")", "",$acx);
			$acx=str_replace(",", "",$acx);
			$acx=str_replace("%", "",$acx);
			$acx=str_replace(".", "",$acx);
		}
		return $acx;
	}

	//Lees de input parameters
	if (isset($_REQUEST["wijzig"])){$wijzig=cleaninput(strtolower($_REQUEST["wijzig"]),1);}
	$now = new DateTime( 'NOW' );
	$diffSeconds = $now->getTimestamp();

	?>

	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
	<html><head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="author" content="Rob van Linden, R.F.J. van Linden">
	<title><?php echo $sitenaam." Setup"; ?></title>
	<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
	<link rel="stylesheet" type="text/css" href="scors.css" /> 
	<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
	<link rel="stylesheet" href="jquery/jqte.css" type="text/css">
	<script src="jquery/jquery-te-1.4.0.js" charset="utf-8"></script>
	<link rel="stylesheet" href="jquery/jquery.fancybox.css">
	<script src="jquery/jquery.fancybox.min.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css" type="text/css">
	<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
	</head>

	<body class="archiefbody">
	<script type="text/Javascript">
	function changerechten(sleutel){
		var hulp=document.getElementById("rechten"+sleutel);
		var ouderechten=$('#ouderechten'+sleutel).val();
		var nieuwerechten=hulp.options[hulp.selectedIndex].value;
		var aantaladmins=parseInt($('#aantaladmins').val());
		if(ouderechten=="sup" && aantaladmins==1){
			alert("U kunt de rechten van dit account niet wijzigen omdat dit het enige admin account is.\nMaak eerst een alternatief admin account.");
			$('#rechten'+sleutel).val('sup');
			return;
		}
		$('#ouderechten'+sleutel).val(nieuwerechten);
		if(nieuwerechten=='sup'){aantaladmins++;}
		if(ouderechten=='sup'){aantaladmins--;}
		$('#aantaladmins').val(aantaladmins);
		xmltrein('setup.php?setupsave=1&aktie=edit&tabel=users&veldnaam=rechten&Key='+sleutel+'&veldinhoud='+nieuwerechten);
	return;}
	function additem(tabel,veldnaam){
		xmltrein('setup.php?setupsave=1&aktie=nieuw&tabel='+tabel+'&veldnaam='+veldnaam);
		location.reload(true);
	return;}
	function editrow(tabel,veldnaam,sleutel,oudewaarde,aantal){
		$('#settingssaved').hide();
		$('#wachten').show();
		var answer=true;
		var nieuwewaarde=document.getElementById(veldnaam+sleutel).value;
		if (veldnaam.indexOf('volgorde')==-1 && aantal>0){answer=confirm("Weet u zeker dat u "+oudewaarde+" wilt veranderen in "+nieuwewaarde+" ?\nArchiefrecords die nu de aan de oude naam zijn gekoppeld zullen ook naar de nieuwe naam worden omgezet.\nDit kan even duren.");}
		if(answer){
			xmltrein('setup.php?setupsave=1&aktie=edit&tabel='+tabel+'&veldnaam='+veldnaam+'&Key='+sleutel+'&veldinhoud='+nieuwewaarde+'&oudewaarde='+oudewaarde);
			if(veldnaam=="mappen" || veldnaam=="soorten"){xmltrein('aaupdate.php?aktie=selectblok');}
			if(veldnaam=="soortenb"){xmltrein('bpupdate.php?aktie=selectblok');}
			if(veldnaam.indexOf('volgorde')!==-1){location.reload(true);return;}
		}else{$('#'+veldnaam+sleutel).val(oudewaarde);}
		$('#wachten').hide();
		$('#settingssaved').show();
	return;}
	function delregel(tabel,sleutel,oudewaarde){
		$('#settingssaved').hide();
		$('#wachten').show();var answer=false;
		answer=confirm("Weet U zeker dat U "+oudewaarde+" uit "+tabel+" wilt verwijderen?");
		if (answer){
			xmltrein('setup.php?setupsave=1&aktie=del&tabel='+tabel+'&Key='+sleutel+'&veldinhoud='+oudewaarde);
			location.reload(true);
			return;
		}
		$('#wachten').hide();
	return;}
	function xmltrein(url){
		var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	return;}
	function alertchange(){
		$('#savebutton').attr('class','ggbuttonrood');
		$("#settingssaved").hide();
	return;}
	function controleergegevens(){
		var tekst="";
		if ($("#wpdomein").val()!=""){if ($("#wpdomein").val().indexOf(".")==-1){tekst=tekst+"Ongeldige naam voor Remote domein\n";}}
		if ($("#mailerHOST").val()!=""){if ($("#mailerHOST").val().indexOf(".")==-1){tekst=tekst+"Ongeldige naam voor SMTP server\n";}}
		if ($("#mailerFROM").val()!=""){if ($("#mailerFROM").val().indexOf("@")==-1){tekst=tekst+"Ongeldig 'Van' adres\n";}}
		if(tekst!=""){alert(tekst);return false;}
		else{$("#settingsform").submit();$("#settingssaved").show();$('#savebutton').attr('class','ggbutton');}	
	return;}
	</script>

	<br><br>
	<div style="max-width:1055px;margin:auto;background-color:#FFFFFF; border-color:#afafaf;border-left-width:0px; border-right-width:0px; border-top-style:solid; border-top-width:2px; border-bottom-width:0px;">

		<!-- KOP EN NAVIGATIE-->

		<table border="0" class="bcollapse" cellpadding="0" cellspacing="0" width="100%"><tr>
			<td width="125" align="right">
				<img src="images/logoscors.png" valign="top" height="25">
			</td><td align="left">
				<H3>&nbsp;&nbsp;<i><?php echo $sitenaam; ?>&nbsp;&nbsp;Systeembeheer</i></H3>
			</td>
		</td><td align="left">
			<div class="dropdown">
				<b>Admin&nbsp<?php echo $user; ?></b>&nbsp;&nbsp;
				<div class="dropdown-content">
					<a href="logon.php?lu=lo">&nbsp;Uitloggen&nbsp;</a>
					<a href="logon.php?lu=cww">&nbsp;Wachtwoord&nbsp;wijzigen&nbsp;</a>
				</div>
			</div>
		</td><td align="right">&nbsp;</td>
		</tr></table>
		
		<table border="0" class="bcollapse bgzoek" cellpadding="0" cellspacing="0" width="100%"><tr><td>
		<H3>&nbsp;&nbsp;&nbsp;
			<a class="menuscors <?php if ($wijzig=='settings'){echo 'bright';} ?>" href="setup.php?wijzig=settings">Configuratie</a>&nbsp;
			<a class="menuscors <?php if ($wijzig=='users'){echo 'bright';} ?>" href="setup.php?wijzig=users">Gebruikersaccounts</a>&nbsp;
			<a class="menuscors <?php if ($wijzig=='mappen'){echo 'bright';} ?>" href="setup.php?wijzig=mappen">Mappen</a>&nbsp;
			<a class="menuscors <?php if ($wijzig=='soorten'){echo 'bright';} ?>" href="setup.php?wijzig=soorten">Soorten</a>&nbsp;
			<a class="menuscors <?php if ($wijzig=='velden'){echo 'bright';} ?>" href="setup.php?wijzig=velden">Velden</a>&nbsp;&nbsp;&nbsp;&nbsp;
		</H3>
		</td><td>
			<H3><a class="menu" href="index.php">Terug naar Collectie</a>&nbsp;&nbsp;</H3>
		</td></tr></table>

		<div style="margin:0px 75px;max-width:1055px;" align="left">
			&nbsp;<br>
		
			<?php
			if ($wijzig=="settings"){ ?>
				<table width="100%" align="left" border="0" class="bcollapse"><tr>
				<td width="30" align="left">
					<img src="images/setup.png">
				</td><td width="200" align="left">
					<span style="color: var(--basiskleur2);font-size:26px;"><b>Configuratie&nbsp;&nbsp;</b></span>
				</td><td width="150" align="left">
					<button id="savebutton" class="ggbutton" onclick="controleergegevens();">Sla gewijzigde<br>gegevens op</button>&nbsp;&nbsp;
				</td><td width="120" align="left">
					<a data-fancybox="setup" data-type="iframe" href="log/scorssetuplog.txt?t=<?php echo $diffSeconds; ?>"><button class="ggbutton">Open logfile</button></a>
				</td><td align="left">
				<?php
					error_reporting(E_ALL);
					$localVersionFile = __DIR__ . "/versie.txt";
					$remoteVersionUrl = "https://scors.nl/versie.txt";
					// Function to get file contents safely
					function getRemoteVersion($url) {
						$version = file_get_contents($url);
						return $version ? trim($version) : false;
					}
					$localVersion = file_exists($localVersionFile) ? trim(file_get_contents($localVersionFile)) : "0";
					$remoteVersion = getRemoteVersion($remoteVersionUrl);
					if ($remoteVersion !== false) {
						// Check if an update is available
						if (version_compare($remoteVersion, $localVersion, '>')) { ?>
							<a data-fancybox="update" data-type="iframe" href="vupdate.php">
							<button class="ggbuttonrood">Versie <?php echo $remoteVersion; ?> beschikbaar. Uw huidige versie <?php echo $localVersion; ?>.<br>Update SCORS</button>
							</a>
						<?php
						}else{
							echo "SCORS versie ".$localVersion;
						}
					}
					?>
				</td><td align="left">
					&nbsp;
					<div id="wachten" style="display:none;"><img src="images/wacht.gif"></div>
					<div id="settingssaved" style="display:none;color:red;">&nbsp;&nbsp;Gewijzigde gegevens opgeslagen</div>
				</td></tr><tr><td colspan="3">
					&nbsp;
				</td></tr></table>
				
				<br><br>	
				<?php
				$fprs=odbc_exec($defConnect, "SELECT * FROM settings");
				$row=odbc_fetch_array($fprs);
				?>

				<table class="bcollapse" bordercolor="lightgrey" border="1" align="center">
					<tr>
						<td align="right"><b>Sitetitel:&nbsp;</b></td>
						<td align="left">
						<form id="settingsform" action="setup.php?setupsave=1&aktie=updatesettings" target="sul" method="post" autocomplete="off">
						<input type="text" style="display:none"><input type="password" style="display:none">
						<input value="<?php echo $row["sitenaam"]; ?>" type="text" size="35" id="sitenaam" name="sitenaam" onchange="alertchange();"></td>
						<td>Titel zoals die wordt getoond in de kop van de pagina's.</td>
					</tr><tr>
						<td align="right"><b>Gebruik Audio-&nbsp;<br> Videocollectie:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["allowav"]=="on"){echo " checked ";} ?> id="allowav" name="allowav" onchange="alertchange();"></td>
						<td>Vink aan als u de Audio-Videocollectie module wilt gebruiken in SCORS. Deze wordt dan ook getoond in het hoofdmenu.<br>
						</td>
					</tr><tr>
						<td align="right"><b>Gebruik&nbsp;<br> Boekencollectie:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["allowbb"]=="on"){echo " checked ";} ?> id="allowbb" name="allowbb" onchange="alertchange();"></td>
						<td>Vink aan als u de Boekencollectie module wilt gebruiken in SCORS. Deze wordt dan ook getoond in het hoofdmenu.<br>
						</td>
					</tr><tr>
						<td align="right"><b>Gebruik&nbsp;<br> Tijdschriftencollectie:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["allowtt"]=="on"){echo " checked ";} ?> id="allowtt" name="allowtt" onchange="alertchange();"></td>
						<td>Vink aan als u de Tijdschriftencollectie module wilt gebruiken in SCORS. Deze wordt dan ook getoond in het hoofdmenu.<br>
						</td>
<!--				</tr><tr>
						<td align="right"><b>Bestellink voor boeken:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["bbbestellink"]; ?>" type="text" size="35" id="bbbestellink" name="bbbestellink" onchange="alertchange();"></td>
						<td>Als u boeken als 'bestelbaar' wilt kunnen markeren, geef hier dan een webadres op voor het bestelformulier.<br>
						</td> -->
					</tr><tr>
						<td align="right"><b>Gebruik&nbsp;<br> Bidprentjescollectie:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["allowbp"]=="on"){echo " checked ";} ?> id="allowbp" name="allowbp" onchange="alertchange();"></td>
						<td>Vink aan als u de Bidprentjes module wilt gebruiken in SCORS. Deze wordt dan ook getoond in het hoofdmenu.<br>
						</td>
					</tr><tr>
						<td align="right"><b>Downloaden:&nbsp;</b></td>
						<td align="left">
						<select id="pft" name="pft" onchange="alertchange();">
						<option value="J" <?php if ($row["pft"]=="J"){echo " selected ";} ?>>Ja voor iedereen</option>
						<option value="I" <?php if ($row["pft"]=="I"){echo " selected ";} ?>>Ja voor ingelogde leden</option>
						<option value="N" <?php if ($row["pft"]=="N"){echo " selected ";} ?>>Nee</option>
						</td>
						<td>Heeft betrekking op het downloaden van foto's en documenten in de Hoofdcollectie en Bidprentjescollectie. Editors kunnen altijd downloaden.
						<br></td>
					</tr><tr>
						<td align="right"><b>Tekstherkenning:&nbsp;</b></td>
						<td align="left">
						<select id="txt" name="txt" onchange="alertchange();">
						<option value="" <?php if ($row["txt"]==""){echo " selected ";} ?>>UIT</option>
						<option value="t" <?php if ($row["txt"]=="t"){echo " selected ";} ?>>AAN voor doorzoekbare PDF en TXT</option>
						<option value="p" <?php if ($row["txt"]=="p"){echo " selected ";} ?>>AAN voor beeld-PDF, TXT en plaatjes</option>
						</td>
						<td>Heeft betrekking op de Hoofdcollectie (button <button>TXT</button>), Tijdschriftencollectie en Bidprentjescollectie. Als u deze functie wilt gebruiken op documenten of plaatjes moet een achtergrondproces op uw server dit uitvoeren.
						<br>Zie de handleiding voor meer informatie.<br></td>
					</tr><tr>
						<td align="right"><b>Archiefnummering&nbsp;<br>Hoofdcollectie:&nbsp;</b></td>
						<td align="left">
						<select id="hoofdnum" name="hoofdnum" onchange="alertchange();">
						<option value="H" <?php if ($row["hoofdnum"]=="H"){echo " selected ";} ?>>Handmatig</option>
						<option value="A" <?php if ($row["hoofdnum"]=="A"){echo " selected ";} ?>>Automatisch</option>
						</select>
						</td>
						<td rowspan="2"><b>Automatisch</b> kent unieke 6-cijferige archiefnummers toe aan records bij aanmaak. Noteer deze achteraf op de originele stukken.<br>
						Bij <b>Handmatig</b> bepaalt men zelf het 6-cijferig unieke archiefnummer. U kunt dit dan invullen bij aanmaak van het record.
						</td>
					</tr><tr>
						<td align="right"><b>Archiefnummering&nbsp;<br>Bidprentjescollectie:&nbsp;</b></td>
						<td align="left">
						<select id="bidnum" name="bidnum" onchange="alertchange();">
						<option value="H" <?php if ($row["bidnum"]=="H"){echo " selected ";} ?>>Handmatig</option>
						<option value="A" <?php if ($row["bidnum"]=="A"){echo " selected ";} ?>>Automatisch</option>
						</select>
						</td>
					</tr><tr>
						<td align="right"><b>Basiskleur 1:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["basiskleur1"]; ?>" type="color" id="basiskleur1" name="basiskleur1" onchange="alertchange();"></td>
						<td>Deze kleur wordt gebruikt als achtergrond voor sommige vlakken en knoppen.<br></td>
					</tr><tr>
						<td align="right"><b>Basiskleur 2:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["basiskleur2"]; ?>" type="color" id="basiskleur2" name="basiskleur2" onchange="alertchange();"></td>
						<td>Deze kleur wordt gebruikt voor sommige titels en links.<br></td>
					</tr><tr>
						<td align="right"><b>Remote sleutel:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["wpkey"]; ?>" type="text" size="35" id="wpkey" name="wpkey" onchange="alertchange();"></td>
						<td>Van toepassing als de presentatie van de collectie op een remote website plaatsvindt (b.v. Wordpress) en men een toegangsbeperking
						wil instellen (b.v. alleen op die website ingelogde leden).
						De sleutel moet in de remote pagina met de toegangsbeperking worden opgenomen. Zie de handleiding voor meer informatie.<br></td>
					</tr><tr>
						<td align="right"><b>Remote domein:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["wpdomein"]; ?>" type="text" size="35" id="wpdomein" name="wpdomein" onchange="alertchange();"></td>
						<td>Van toepassing als de presentatie van de collectie op een remote website plaatsvindt (b.v. Wordpress).<br>
						Geef hier het domein op van de remote website. Voorbeeld: <b>www.onzewebsite.nl</b>. Zie de handleiding voor meer informatie.<br></td>
					</tr><tr>
						<td align="right"><b>JSON interface:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["allowjson"]=="on"){echo " checked ";} ?> id="allowjson" name="allowjson" onchange="alertchange();"></td>
						<td>Via de JSON interface kan de database door derden in JSON-formaat worden uitgelezen. Zie handleiding voor meer info.<br>
						Voor JSON toegang wordt eveneens de Remote sleutel gebruikt.<br>
						</td>
					</tr><tr>
						<td align="right"><b>JSON rechten:&nbsp;</b></td>
						<td align="left">
						<select id="jsonrechten" name="jsonrechten" onchange="alertchange();">
						<option value="" <?php if ($row["jsonrechten"]==""){echo " selected ";} ?>>Alleen Publieke records</option>
						<option value="ufa" <?php if ($row["jsonrechten"]=="ufa"){echo " selected ";} ?>>Publieke en Leden records</option>
						</td>
						<td>Rechten voor de JSON interface.<br></td>
					</tr><tr>
						<td colspan="3"><br><br><i>
						&nbsp;Geef hieronder de gegevens van uw mailserver voor uitgaande mail.<br>&nbsp;Deze zijn nodig voor de 'wachtwoord vergeten' functie in de login-pagina van uw eigen webserver.
						</i><br><br></td>
					</tr><tr>
						<td align="right"><b>SMTP server:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["mailerHOST"]; ?>" type="text" size="35" id="mailerHOST" name="mailerHOST" onchange="alertchange();"></td>
						<td>Vraag dit na bij uw mail provider.</td>
					</tr><tr>
						<td align="right"><b>Authenticatie&nbsp;<br>vereist?:&nbsp;</b></td>
						<td align="left"><input value="on" type="checkbox" <?php if ($row["mailerAUTH"]=="on"){echo " checked ";} ?> id="mailerAUTH" name="mailerAUTH" onchange="alertchange();"></td>
						<td>Vink aan als de SMTP server voor uitgaande mail authenticatie vereist.</td>
					</tr><tr>
						<td align="right"><b>Versleutelings type:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["mailerSEC"]; ?>" type="text" size="35" id="mailerSEC" name="mailerSEC" onchange="alertchange();"></td>
						<td>Geef de versleutelings techniek aan (indien van toepassing). Veelgebruikte types zijn <b>SSL</b>, <b>TLS</b> en <b>STARTTLS</b>.<br>Vraag dit na bij uw mail provider.</td>
					</tr><tr>
						<td align="right"><b>Poort:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["mailerPORT"]; ?>" type="number" size="6" id="mailerPORT" name="mailerPORT" onchange="alertchange();"></td>
						<td>Geef de SMTP communicatiepoort aan. Niet-versleutelde communicatie gebruikt gewoonlijk poort <b>25</b>. Voor versleutelde communicatie wordt vaak poort <b>587</b> gebruikt. Vraag dit na bij uw mail provider.</td>
					</tr><tr>
						<td align="right"><b>Login&nbsp;<br>gebruikersnaam:&nbsp;</b></td>
						<td align="left"><input autocomplete="off" value="<?php echo $row["mailerloginUID"]; ?>" type="text" size="35" id="mailerloginUID" name="mailerloginUID" onchange="alertchange();"></td>
						<td>Van toepassing als authenticatie is vereist.</td>
					</tr><tr>
						<td align="right"><b>Login&nbsp;<br>wachtwoord:&nbsp;</b></td>
						<td align="left"><input autocomplete="off" class="pass" value="<?php echo $row["mailerloginPASS"]; ?>" type="password" size="35" id="mailerloginPASS" name="mailerloginPASS" onchange="alertchange();"><br>
						<img id="spw" src="images/spw.png" onclick="showpw();" class="vmidden" style="margin:0px 0px 5px 0px;"></td>
						<td>Van toepassing als authenticatie is vereist.</td>
					</tr><tr>
						<td align="right"><b>'Van' adres:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["mailerFROM"]; ?>" type="text" size="35" id="mailerFROM" name="mailerFROM" onchange="alertchange();"></td>
						<td>Het mailadres waar de mail aan de gebruiker vandaan komt.<br>Betreft de mail met de <b>wachtwoord instellen</b> link.</td>
					</tr><tr>
						<td align="right"><b>'Van' naam:&nbsp;</b></td>
						<td align="left"><input value="<?php echo $row["mailerFROMNAME"]; ?>" type="text" size="35" id="mailerFROMNAME" name="mailerFROMNAME" onchange="alertchange();"></td>
						<td>Dit is het naam die de gebruiker als afzender ziet.</form></td>
					</tr>
				</table><br>
			<?php
			}else if($wijzig=="mappen"){ ?>
				<table width="100%" align="left" border="0" class="bcollapse"><tr>
				<td width="30" align="left">
					<img src="images/setup.png">
				</td><td align="left">
					<span style="color: var(--basiskleur2);font-size:26px;"><b>Mappen</b></span>&nbsp;&nbsp;<i>(alleen hoofdcollectie)</i>
				</td><td>&nbsp;</td></tr></table>
				<br>
				Met <b>Mappen</b> wordt een koppeling gemaakt tussen records uit de database en fysiek opgeslagen archiefstukken.<br><br>
				Indien u een mapnaam <b>wijzigt</b> worden ook alle records die aan deze mapnaam zijn gekoppeld aangepast.<br>
				Door de namen van 2 verschillende mappen uit de lijst <b>gelijk te maken</b> worden deze 2 mappen samengevoegd tot 1.<br><br>
				Een mapnaam kan pas worden <b>verwijderd</b> als er geen archiefrecords meer aan die map zijn toegewezen.<br>
				Wijs eerst alle eraan gekoppelde records toe aan een andere map voordat u een mapnaam verwijdert.<br><br>

				<button class="ggbutton" onclick="additem('mappen','mappen');">Voeg nieuwe map toe</button><br><br>
				
				<table class="bgzoek bcollapse" bordercolor="lightgrey" border="1" align="center"><tr>
				<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Mappen</b></font></td>
				<td style="padding:4px;" bgcolor="#000000"></td>
				</tr>
				<?php
				//Lees Mapgegevens
				$mappen=array_fill(0,250,"");
				$mapsleutel=array_fill(0,250,"");
				$mapcount=array_fill(0,250,0);
				$mapteller=0;
				$fprs=odbc_exec($defConnect, "SELECT * FROM mappen ORDER BY mappen ASC");
				while($row=odbc_fetch_array($fprs)){
					if(strlen($row["mappen"])>0){ 
						$mapteller++;
						$mappen[$mapteller]=$row["mappen"];
						$mapsleutel[$mapteller]=strval($row["Key"]);
						$fpcount=odbc_exec($objConnect,"SELECT COUNT (*) AS aantal FROM archief WHERE mapnr='".$row["mappen"]."'");
						if($fprscount=odbc_fetch_array($fpcount)){$mapcount[$mapteller]=$fprscount['aantal'];}
					}
				}
				unset($fprs);unset ($fprscount);
				$nummer=1;$vorigemapnaam="85fgj6d";
				for($mi=1;$mi<=$mapteller;$mi++){
					if($mappen[$mi]==$vorigemapnaam){//gooi deze map weg
						odbc_exec($defConnect,"DELETE FROM mappen WHERE Key=".$mapsleutel[$mi]);
					}else{
						$vorigemapnaam=$mappen[$mi];
						?>
						<tr><td style="padding:4px;" bgcolor="#ffffff">
							<input size="60" id="mappen<?php echo $mapsleutel[$mi]; ?>" type="text" value="<?php echo $mappen[$mi]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('mappen','mappen','<?php echo $mapsleutel[$mi]; ?>',document.getElementById('oudewaarde'+<?php echo $mapsleutel[$mi]; ?>).value,<?php echo $mapcount[$mi]; ?>);">
							<input id="oudewaarde<?php echo $mapsleutel[$mi]; ?>" type="hidden" value="<?php echo $mappen[$mi]; ?>">
						</td><td width="70" class="vmidden"  align="center" bgcolor="#ffffff">
							<?php if ($mapcount[$mi]==0){ ?>
								<button class="ggbutton" onclick="delregel('mappen','<?php echo $mapsleutel[$mi]; ?>',document.getElementById('oudewaarde<?php echo $mapsleutel[$mi]; ?>').value);">Del</button>
							<?php }else{ ?>
								<font size="1">(<?php echo $mapcount[$mi]; ?> records)</font>
							<?php } ?>
						</td></tr>
					<?php
					}
				$nummer++;
				} ?>
				</table><br>
				<?php
				if ($nummer==1){ ?>
					<br><br>Geen resultaten gevonden voor mappen.
				<?php
				}
			}else if ($wijzig=="soorten"){ ?>
				<table width="100%" align="left" border="0" class="bcollapse"><tr>
				<td width="30" align="left">
					<img src="images/setup.png">
				</td><td align="left">
					<span style="color: var(--basiskleur2);font-size:26px;"><b>Soorten</b></span>&nbsp;&nbsp;<i>(hoofdcollectie en bidprentjescollectie)</i>
				</td><td>&nbsp;</td></tr></table>
				<br>
				<b>Soorten</b> helpen om uw digitale archief beter doorzoekbaar te maken. Beperk het aantal echter zo veel mogelijk.<br><br>
				Vaste soorten in de Hoofdcollectie zijn <b>Document, Foto</b> en <b>Bidprentje</b>. Deze kunnen niet worden gewijzigd of verwijderd.<br>
				Suggesties voor aanvullende soorten in de Hoofdcollectie: <b>Prentbriefkaart, Artikel in media, Topgrafische kaart, Tekening, Boek, Tijdschrift, Voorwerp</b>.<br><br>
				Vaste soorten voor de Bidprentjescollectie zijn <b>Bidprentje</b> en <b>Gedachtenisprentje</b>. Overige suggesties: <b>Overlijdensadvertentie</b> en <b>Rouwbrief</b>.<br><br>
				Indien u een soortnaam <b>wijzigt</b> worden ook alle records die aan deze soort zijn gekoppeld aangepast.<br>
				Door de namen van 2 verschillende soorten uit de lijst <b>gelijk te maken</b> worden deze 2 soorten samengevoegd tot 1.<br><br>
				Een soort kan pas worden <b>verwijderd</b> als er geen archiefrecords meer aan die soort zijn toegewezen.<br>
				Wijs eerst alle eraan gekoppelde records toe aan een andere soort voordat u een soort verwijdert.<br><br>
				<table><tr><td class="vtop">
					<button class="ggbutton" onclick="additem('soorten','soorten');">Voeg nieuwe soort toe voor Hoofdcollectie</button><br><br>
					<table class="bgzoek bcollapse" bordercolor="lightgrey" border="1" align="center">
					<tr>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Soorten in Hoofdcollectie</b></font></td>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Volgnr</b></font></td>
					<td width="60" style="padding:4px;" bgcolor="#000000"></td>
					</tr>
					<?php
					//Lees Soorten hoofdcollectie
					$soorten=array_fill(0,150,"");
					$soortsleutel=array_fill(0,150,"");
					$soortfixed=array_fill(0,150,"");
					$soortteller=0;
					$fprs=odbc_exec($defConnect, "SELECT * FROM soorten ORDER BY soorten ASC");
					while($row=odbc_fetch_array($fprs)){
						if(strlen($row["soorten"])>0){ 
							$soortteller++;
							$soorten[$soortteller]=$row["soorten"];
							$soortfixed[$soortteller]=$row["fixed"];
							$soortsleutel[$soortteller]=strval($row["Key"]);
						}
					}
					$vorigesoortnaam="85fgj6d";
					for($si=1;$si<=$soortteller;$si++){
						if(strtolower($soorten[$si])==strtolower($vorigesoortnaam)){//gooi deze soort weg
							if($soortfixed[$si]=="f"){$eraf=1;}else{$eraf=0;}
							odbc_exec($defConnect,"DELETE FROM soorten WHERE Key=".$soortsleutel[$si-$eraf]);
						}else{
							$vorigesoortnaam=$soorten[$si];
						}
					}
					$nummer=1;
					$fprs=odbc_exec($defConnect, "SELECT * FROM soorten ORDER BY volgorde ASC");
					while($row=odbc_fetch_array($fprs)){
						$fpcount=odbc_exec($objConnect,"SELECT COUNT (*) AS aantal FROM archief WHERE soort1='".$row["soorten"]."'");
						if($fprscount=odbc_fetch_array($fpcount)){$soortcount=$fprscount['aantal'];}
						?>
						<tr><td style="padding:4px;" bgcolor="#ffffff">
							<?php if($row["fixed"]=="f"){
								echo "<b>".$row["soorten"]."</b>";
							}else{ ?>
								<input size="35" id="soorten<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row["soorten"]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('soorten','soorten','<?php echo $row["Key"]; ?>',document.getElementById('oudewaarde'+<?php echo $row["Key"]; ?>).value,<?php echo $soortcount; ?>);">
							<?php
							} ?>
							<input id="oudewaarde<?php echo $row["Key"]; ?>" type="hidden" value="<?php echo $row["soorten"]; ?>">
						</td><td style="padding:4px;" bgcolor="#ffffff">
							<input size="3" id="volgorde<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row["volgorde"]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('soorten','volgorde','<?php echo $row["Key"]; ?>','',0);">
						</td><td width="60" class="vmidden"  align="center" bgcolor="#ffffff">
							<?php if ($soortcount==0 and $row["fixed"]!="f"){ ?>
								<button class="ggbutton" onclick="delregel('soorten','<?php echo $row["Key"]; ?>',document.getElementById('oudewaarde<?php echo $row["Key"]; ?>').value);">Del</button>
							<?php }else{ ?>
								<font size="1">(<?php echo $soortcount; ?> records)</font>
							<?php } ?>
						</td></tr>
						<?php
						$nummer++;
					} ?>
					</table><br>
					<?php
					unset ($fprscount);
					if ($nummer==1){ ?>
						<br><br>Geen resultaten gevonden voor soorten.
					<?php
					} ?>
				</td><td>
					&nbsp;&nbsp;&nbsp;
				</td><td class="vtop">
					<button class="ggbutton" onclick="additem('soortenb','soortenb');">Voeg nieuwe soort toe voor Bidprentjescollectie</button><br><br>
					<table class="bgzoek bcollapse" bordercolor="lightgrey" border="1" align="center">
					<tr>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Soorten in Bidprentjescollectie</b></font></td>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Volgnr</b></font></td>
					<td width="60" style="padding:4px;" bgcolor="#000000"></td>
					</tr>
					<?php
					//Lees Soorten bidprentjescollectie
					$soortenb=array_fill(0,150,"");
					$soortbsleutel=array_fill(0,150,"");
					$soortbfixed=array_fill(0,150,"");
					$soortbteller=0;
					$fprs=odbc_exec($defConnect, "SELECT * FROM soortenb ORDER BY soortenb ASC");
					while($row=odbc_fetch_array($fprs)){
						if(strlen($row["soortenb"])>0){ 
							$soortbteller++;
							$soortenb[$soortbteller]=$row["soortenb"];
							$soortbfixed[$soortbteller]=$row["fixed"];
							$soortbsleutel[$soortbteller]=strval($row["Key"]);
						}
					}
					$vorigesoortnaam="85fgj6d";
					for($si=1;$si<=$soortbteller;$si++){
						if(strtolower($soortenb[$si])==strtolower($vorigesoortnaam)){//gooi deze soort weg
							if($soortbfixed[$si]=="f"){$eraf=1;}else{$eraf=0;}
							odbc_exec($defConnect,"DELETE FROM soortenb WHERE Key=".$soortbsleutel[$si-$eraf]);
						}else{
							$vorigesoortnaam=$soortenb[$si];
						}
					}
					$nummer=1;
					$fprs=odbc_exec($defConnect, "SELECT * FROM soortenb ORDER BY volgordeb ASC");
					while($row=odbc_fetch_array($fprs)){
						$fpcount=odbc_exec($bidConnect,"SELECT COUNT (*) AS aantal FROM archief WHERE soort1='".$row["soortenb"]."'");
						if($fprscount=odbc_fetch_array($fpcount)){$soortbcount=$fprscount['aantal'];}
						?>
						<tr><td style="padding:4px;" bgcolor="#ffffff">
							<?php if($row["fixed"]=="f"){
								echo "<b>".$row["soortenb"]."</b>";
							}else{ ?>
								<input size="35" id="soortenb<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row["soortenb"]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('soortenb','soortenb','<?php echo $row["Key"]; ?>',document.getElementById('oudewaardeb'+<?php echo $row["Key"]; ?>).value,<?php echo $soortbcount; ?>);">
							<?php
							} ?>
							<input id="oudewaardeb<?php echo $row["Key"]; ?>" type="hidden" value="<?php echo $row["soortenb"]; ?>">
						</td><td style="padding:4px;" bgcolor="#ffffff">
							<input size="3" id="volgordeb<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row["volgordeb"]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('soortenb','volgordeb','<?php echo $row["Key"]; ?>','',0);">
						</td><td width="60" class="vmidden"  align="center" bgcolor="#ffffff">
							<?php if ($soortbcount==0 and $row["fixed"]!="f"){ ?>
								<button class="ggbutton" onclick="delregel('soortenb','<?php echo $row["Key"]; ?>',document.getElementById('oudewaardeb<?php echo $row["Key"]; ?>').value);">Del</button>
							<?php }else{ ?>
								<font size="1">(<?php echo $soortbcount; ?> records)</font>
							<?php } ?>
						</td></tr>
						<?php
						$nummer++;
					} ?>
					</table><br>
					<?php
					unset ($fprscount);
					if ($nummer==1){ ?>
						<br><br>Geen resultaten gevonden voor soorten.
					<?php
					} ?>
				
				</td></tr></table>
			<?php
			}else if ($wijzig=="velden"){ ?>
				<table width="100%" align="left" border="0" class="bcollapse"><tr>
				<td width="30" align="left">
					<img src="images/setup.png">
				</td><td align="left">
					<span style="color: var(--basiskleur2);font-size:26px;"><b>Velden</b></span>&nbsp;&nbsp;<i>(aleen hoofdcollectie)</i>
				</td><td>&nbsp;</td></tr></table>
				<br>
				Van een aantal <b>velden</b> kan de naam vrij worden gekozen. Standaard zijn dit: <b>Onderwerp, Straat / Wijk, Familienaam, Bron</b> en <b>Auteur</b>.<br>
				Elk veld komt in het invoerformulier een bepaald aantal keer voor. Dat aantal staat tussen haakjes achter de standaardnaam.<br>
				Staat bij <b>Onderwerp</b> b.v. (3x) dan kunnen er 3 verschillende onderwerpen aan het record worden gekoppeld.<br><br>

				<table class="bgzoek bcollapse" bordercolor="lightgrey" border="1" align="center">
				<tr>
				<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Standaard veldnaam</b></font></td>
				<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Gewijzigde veldnaam</b></font></td>
				</tr>
				<?php
				//Lees Veldnamen
				$fprs=odbc_exec($defConnect, "SELECT * FROM velden ORDER BY Key ASC");
				while($row=odbc_fetch_array($fprs)){
					?>
					<tr><td style="padding:4px;" bgcolor="#ffffff">
						<?php echo "<b>".$row["velden"]."</b> (".$row["veldkeus"]."x)" ?>
					</td><td style="padding:4px;" bgcolor="#ffffff">
						<input maxlength="15" size="15" id="veldalt<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row["veldalt"]; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('velden','veldalt','<?php echo $row["Key"]; ?>','',0);">
					</td></tr>
					<?php
				} ?>
				</table><br>
			<?php
			}else if ($wijzig=="users"){ ?>
				<table width="100%" align="left" border="0" class="bcollapse"><tr>
				<td width="30" align="left">
					<img src="images/setup.png">
				</td><td align="left">
					<span style="color: var(--basiskleur2);font-size:26px;"><b>Gebruikersaccounts</b></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</td><td>&nbsp;</td></tr></table>
				<br>
				Met onderstaande accounts kan worden ingelogd op deze SCORS website. De accounts zijn niet te gebruiken voor de presentatie van de collectie op een remote website.<br>
				Nieuwe gebruikers dienen het wachtwoord voor hun account zelf in te stellen via <b>Inloggen -> Wachtwoord vergeten</b>. Dit vereist een geldig email-adres
				als gebruikersaccount.<br><br>
				Een <b>Lid</b> heeft alleen kijkrechten op 'Leden' en 'Publiek' records.<br>
				Een <b>Editor</b> heeft kijk- en editrechten op alle records (inclusief de 'Prive' records).<br>
				Een <b>Admin</b> heeft kijk- en editrechten op alle records en heeft toegang tot het 'Systeembeheer' gedeelte waar u zich nu in bevindt.<br><br>
				Niet-ingelogde website bezoekers hebben kijkrechten op 'Publiek' records.<br><br>
				
				<button class="ggbutton" onclick="additem('users','user');">Voeg nieuw gebruikersaccount toe</button>&nbsp;&nbsp;&nbsp;
				<a data-fancybox="logon" data-type="iframe" href="log/scorslogonlog.txt?t=<?php echo $diffSeconds; ?>"><button class="ggbutton">Open login-logfile</button></a><br>

				<?php
				//Lees de input parameters
				$hulppg="";$pg=1;
				if(isset($_REQUEST['pg'])){$hulppg=cleaninput($_REQUEST["pg"],1);}
				if (is_numeric($hulppg)){
					$pg=0+$hulppg;
					if ($pg==0){$pg=1;}
				}
				if ($pg==0){$pg=1;}
				$pagesize=50;

				//check aantal admin accounts
				$fprs=odbc_exec($defConnect,"SELECT COUNT(*) as aantal FROM users WHERE rechten='sup'");
				$aantaladmins=0;
				if($row=odbc_fetch_array($fprs)){$aantaladmins=$row['aantal'];}
				?>
					<input id="aantaladmins" type="hidden" value="<?php echo $aantaladmins; ?>">
				<?php 
				if($aantaladmins==0){ ?>
					<font size="4" style="color:red;">LET OP: Er is geen gebruiker meer met admin rechten! Maak er een aan voordat u deze pagina verlaat!</font>
				<?php }
				$fprs=odbc_exec($defConnect,"SELECT COUNT(*) as aantal FROM users ");
				$aantalrecords=0;
				if($row=odbc_fetch_array($fprs)){$aantalrecords=$row['aantal'];}
				if ($aantalrecords>0){
					$CurrentPage=$pg;
					$PageCount=intdiv($aantalrecords,$pagesize)-(($aantalrecords%$pagesize)==0)+1;
					if ($CurrentPage<1){$CurrentPage=1;}
					if ($CurrentPage>$PageCount){$CurrentPage=$PageCount;}
					
					include "setupnav.php";
					?>
					<div style="margin:0px 65px 0px 0px;" align="right">Aantal: <?php echo $aantalrecords; ?><br></div>
					
					<table class="bcollapse" bordercolor="lightgrey" border="1" align="center">
					<tr>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Gebruikersaccount</b></font></td>
					<td style="padding:4px;" bgcolor="#000000"><font color="#ffffff" size="3"><b>Rechten</b></font></td>
					<td style="padding:4px;" bgcolor="#000000"></td>
					</tr>
					<?php //doe de query
					$nummer=1;$regelteller=1;
					$fprs=odbc_exec($defConnect,"SELECT * FROM users ORDER BY user ASC");
					while($row = odbc_fetch_array($fprs)){
						$positieteller=($pagesize*($pg-1))+$regelteller;
						if ($regelteller>$pagesize){break;}
						if($positieteller>$aantalrecords){break;}
						if (!$row=odbc_fetch_array($fprs,$positieteller)){break;}
						?>
						<tr><td style="padding:4px;">
							<input size="50" id="user<?php echo $row["Key"]; ?>" type="text" value="<?php echo $row['user']; ?>" onfocus="$('#settingssaved').hide();" onchange="editrow('users','user','<?php echo $row["Key"]; ?>',document.getElementById('oudewaarde<?php echo $row["Key"]; ?>').value,0);">
							<input id="oudewaarde<?php echo $row["Key"]; ?>" type="hidden" value="<?php echo $row["user"]; ?>">
						</td><td>
							<input id="ouderechten<?php echo $row["Key"]; ?>" type="hidden" value="<?php echo $row["rechten"]; ?>">
							<select class="rechtenveld" id="rechten<?php echo $row["Key"]; ?>" onfocus="$('#settingssaved').hide();" onchange="changerechten('<?php echo $row["Key"]; ?>');">
							<option value="mo"  <?php if ($row["rechten"]=="mo") {echo " selected "; } ?>>Editor</option>
							<option value="ufa" <?php if ($row["rechten"]=="ufa"){echo " selected "; } ?>>Lid</option>
							<option value="sup" <?php if ($row["rechten"]=="sup"){echo " selected "; } ?>>Admin</option>
							</select>
						</td><td width="50" class="vmidden"  align="center">
							<button class="ggbutton" onclick="delregel('users','<?php echo $row["Key"]; ?>',document.getElementById('user<?php echo $row["Key"]; ?>').value);">Del</button>
						</td></tr>
						<?php
						$nummer++;
						$regelteller=$regelteller+1;
					} //next record 
					?>
					</tr></table><br>

					<?php
					include "setupnav.php";
				}	
				
				if ($nummer==1){ ?>
					<br><br>Geen resultaten gevonden voor gebruikersaccounts.
				<?php			
				}
			} ?>
			
		</div>
		
		<!-- FOOTER -->		

		<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td align="right">
			<br>
			<font size="1">SCORS&nbsp;v3.0&nbsp;Systeembeheer&nbsp;&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font>
		</td></tr></table>
		
	</div>
	<?php
	unset($fprs);
	?>

<iframe style="display:none;" name="sul" id="sul"></iframe>

<script type="text/Javascript">
function showpw() { 
	var x = document.getElementsByClassName("pass");
	var ximg=document.getElementById("spw");
	for(i=0;i<x.length;i++){
		if (x[i].type === "password") {x[i].type = "text";ximg.src="images/spwnot.png";} else {x[i].type = "password";ximg.src="images/spw.png";}
	}
	return;} 
</script>

	</body></html>

<?php
}
// Close connections
odbc_close($defConnect);
odbc_close($objConnect);
odbc_close($bidConnect);
unset($defConnect);
unset($objConnect);
unset($bidConnect);
 ?>