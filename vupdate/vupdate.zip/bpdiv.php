﻿<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/bidprent.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Get hostserver voor media
$basis="https://" . $_SERVER['HTTP_HOST']."/";
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$basiskleur1=$row["basiskleur1"];
$basiskleur2=$row["basiskleur2"];
?>
<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
<?php

//Check of OCR enabled
$ocr=$row["txt"];
//Check of download is disabled
$pft=false;
if($row["pft"]=="N" or ($row["pft"]=="I" and $rechten=="")){$pft=true;};
//Check handmatige of automatische archiefnummering
$bidnum=$row["bidnum"];
//Check of JSON enabled en aangevraagd
$json=false;$jsonrechten="";$allowjson="";$jsonsleutel="";
$allowjson=$row["allowjson"];
$jsonrechten=$row["jsonrechten"];
if (isset($_GET["json"])){$jsonsleutel=$_GET["json"];}
if ($allowjson=="on" and $jsonsleutel==$wpkey){$json=true;$rechten=$jsonrechten;}
//genereer logfiles voor collectie en zoeken als die nog niet bestaan
$oTextFile = fopen("log/scorsbidlog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);
$oTextFile = fopen("log/scorsbpzoeklog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);

//Definieer veldnamen
$veldrnaam="Geboren te";
$veldwnaam="Overleden te";
$veldmnaam="Familienamen";
$veldunaam="Begraven te";
$veldanaam="Bron";

$doelstub=" WHERE doel='v' ";
if ($rechten=="mo" or $rechten=="sup"){$doelstub="";}
if ($rechten=="ufa"){$doelstub=" WHERE doel<>'p' ";}
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();
//Geen OCR support voor bidprentjes
//$ocr="";

//ADMIN BLOCK
if (($rechten=="mo" or $rechten=="sup") and $json===false){
	$fprs=odbc_exec($objConnect,"SELECT * FROM delta");
	$row=odbc_fetch_array($fprs);$erisdelta=$row["delta"];
	$eriserrarchnr=0;
	$fprs=odbc_exec($objConnect,"SELECT COUNT(*) as aantal FROM archief WHERE fout='x' OR dubbel='x' OR archiefnr='999999'");
	if($row=odbc_fetch_array($fprs)){$eriserrarchnr=$row['aantal'];}
	?>
	<br>
	<div align="center">
		<button class="ggbutton<?php if($eriserrarchnr>0){echo "rood";} ?>" onclick="getcontainer('?av=bp&z=errarchnrs');">Incorrecte archiefnrs</button>&nbsp;
		<a data-fancybox="update" data-type="iframe" href="bpupdate.php"><button class="ggbutton<?php if($erisdelta=="X"){echo "rood";} ?>">Update lijsten</button></a>&nbsp;
		<a data-fancybox="log" data-type="iframe" href="log/scorsbidlog.txt?t=<?php echo $diffSeconds; ?>"><button class="ggbutton">Logfile</button></a>&nbsp;
		<?php
			$objaanvul=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/bpvulling.mdb","","");
			$fprs=odbc_exec($objaanvul,"SELECT COUNT(*) as aantal FROM aanvul where verwerkt<>'j' ");
			$aantalrecords=0;
			if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];}
		?>
		<a data-fancybox="aanvul" data-type="iframe" href="bpshowstatus.php?aktie=aanvullingen"><button class="ggbutton<?php if($aantalrecords>0){echo "rood";} ?>">Aanvullingen</button></a>&nbsp;
		<?php if($ocr){
			$bestanden=scandir("./ocr/");$aantal=0;
			foreach($bestanden as $bestand){
				if($bestand!="." and $bestand!=".." and $bestand!="out"){
					$bestandstype=strtolower(pathinfo($bestand,PATHINFO_EXTENSION));
					if (strpos("jpg pdf txt",$bestandstype)!==false){$aantal++;}
				}
			} ?>
			<a data-fancybox="ocrqueue" data-type="iframe" href="bpshowstatus.php?aktie=ocrqueue"><button class="ggbutton<?php if($aantal>0){echo "rood";} ?>">TXT wachtrij</button></a>&nbsp;
		<?php } ?>
		<a data-fancybox="zoeklog" data-type="iframe" href="log/scorsbpzoeklog.txt?t=<?php echo $diffSeconds; ?>"><button class="ggbutton">Zoekgedrag</button></a>&nbsp;
		<button class="ggbutton" onclick="copyornew('bpadmin.php?aktie=newrec');">Nieuw object</button>&nbsp;
		<a class="ainfo deconone" id="buttonteksten" style="color:white"><button class="ggbutton"><b>?</b></button>
		<span><font size="2">
		<b>Incorrecte archiefnummers</b>: dit zijn nummers die (per ongeluk) dubbel zijn toegekend of niet uit 6 cijfers bestaan.<br><br>
		<b>Update lijsten</b>: hiermee worden diverse suggestie- en lookup lijsten ververst en opgeschoond. Zo af en toe uitvoeren, zeker als men veel velden heeft aangepast.
		<br><br>
		<b>Nieuw object</b>: maakt een nieuw leeg object aan. Het is in de objecten zelf ook mogelijk om daarvan een kopie
		te maken waarbij de inhoud van de meeste velden wordt overgenomen.
		<br><br>
		<b>Logfile</b>: toont de laatste wijzigingen in chronologische volgorde.
		<br><br>
		<b>Aanvullingen</b>: toont door bezoekers gemelde aanvullingen (de knop is rood als er onverwerkte aanvullingen zijn).
		<br><br>
		<?php if($ocr){ ?>
		<b>TXT wachtrij</b>: toont de bestanden die nog voor tekstherkenning in de wachtrij staan (de knop is dan rood).
		<br><br>
		<?php } ?>
		<b>Zoekgedrag</b>: toont door bezoekers gebruikte zoekwoorden en het resultaat.
		<br><br>
		</font></span></a><br>
	</div>

<?php	
}

//***Functies

//Verwijder niet toegestane karakters uit de input parameters
//3 levels van strengheid
function cleaninput($ipar, $level){
	$bloklijst1=array("'","<",">",";","]","[","{","}","%", "@");
	$bloklijst2=array("=","(",")");
	$bloklijst3=array(".","-");
	$acx=$ipar;
	foreach ($bloklijst1 as $letter){
		$hulp=strpos($acx,$letter);
		if ($hulp>0){$acx=substr($acx,0,$hulp-1);}
	}
	if ($level>0){
		foreach ($bloklijst2 as $letter){
			$hulp=strpos($acx,$letter);
			if ($hulp>0){$acx=substr($acx,0,$hulp-1);}
		}
	}
	if ($level>1){
		foreach ($bloklijst3 as $letter){
			$hulp=strpos($acx,$letter);
			if ($hulp>0){$acx=substr($acx,0,$hulp-1);}
		}
	}
	return $acx;
}

//Filter HTML code uit tekst
function filtercode($tekst){
	while(strpos($tekst,"<")!==false and strpos($tekst,">")>strpos($tekst,"<")){
		$beginpos=strpos($tekst,"<");
		$eindpos=strpos($tekst,">");
		$tekst=substr($tekst,0,$beginpos).substr($tekst,$eindpos+1);
	}
	$tekst=str_replace("[[","",str_replace("]]","",$tekst));
	return $tekst;
}

function str_replace_first($from, $to, $content){
    $from = '/'.preg_quote($from, '/').'/';
    return preg_replace($from, $to, $content, 1);
}

//Converteer HTML gecodeerde karakters naar ascii
function chrkode($veldinhoud){
	if (strlen($veldinhoud)>0){
		$veldinhoud=str_replace("&aacute;","á",$veldinhoud);
		$veldinhoud=str_replace("&auml;"  ,"ä",$veldinhoud);
		$veldinhoud=str_replace("&egrave;","è",$veldinhoud);
		$veldinhoud=str_replace("&Eacute;","É",$veldinhoud);
		$veldinhoud=str_replace("&eacute;","é",$veldinhoud);
		$veldinhoud=str_replace("&euml;"  ,"ë",$veldinhoud);
		$veldinhoud=str_replace("&iuml;"  ,"ï",$veldinhoud);
		$veldinhoud=str_replace("&oacute;","ó",$veldinhoud);
		$veldinhoud=str_replace("&ouml;"  ,"ö",$veldinhoud);
		$veldinhoud=str_replace('&quot;','"',$veldinhoud);
		$veldinhoud=str_replace("&#39;","'",$veldinhoud);
	}
	return $veldinhoud;
}

function zclean($zinhoud){
	$z=iconv('UTF-8', 'ASCII//TRANSLIT', $zinhoud);
	$z=str_replace("+"," ",$z);
	$z=str_replace("-"," ",$z);
	$z=str_replace("%20", " ",$z);
	$z=str_replace("%", "",$z);
	$z=str_replace(chr(34), "'",$z);
	$z=str_replace(chr(132), "'",$z);
	$z=str_replace(chr(147), "'",$z);
	$z=str_replace(chr(148), "'",$z);
	while (strpos($z,"  ")!==false){$z=str_replace("  ", " ",$z);}
	while (strpos($z,"''")!==false){$z=str_replace("''", "' '",$z);}	
	$z=trim($z);
	return $z;
}

function selectstring($z,$a,$u,$m,$r,$s,$w,$veld){
	global $objConnect,$defConnect,$rechten;
	//Lees de doelgroep: v(isitors) of e(ditors)
	$doel="v";$doelstub=" WHERE doel='v' ";
	if ($rechten=="mo" or $rechten=="sup"){$doel="e";$doelstub="";}
	if ($rechten=="ufa"){$doel="e";$doelstub=" WHERE doel<>'p' ";}
	$stub="";$tussen="WHERE ";
	if (strlen($w)>0 and $veld<>"w") {$stub=$stub.$tussen."(straat='".$w."')";$tussen=" AND ";}
	if (strlen($m)>0 and $veld<>"m") {$stub=$stub.$tussen."(persoon='".$m."' OR persoon2='".$m."')";$tussen=" AND ";}
	if (strlen($a)>0 and $veld<>"a") {$stub=$stub.$tussen."(auteur1='".$a."' OR auteur2='".$a."' OR auteur3='".$a."')";$tussen=" AND ";}
	if (strlen($u)>0 and $veld<>"u") {$stub=$stub.$tussen."(bron1='".$u."' OR bron2='".$u."' OR bron3='".$u."')";$tussen=" AND ";}
	if (strlen($s)>0 and $veld<>"s") {$stub=$stub.$tussen."(soort1='".$s."')";$tussen=" AND ";}
	if (strlen($r)>0 and $veld<>"r") {$stub=$stub.$tussen."(veldr1='".$r."' OR veldr2='".$r."' OR veldr3='".$r."' OR veldr4='".$r."')";$tussen=" AND ";}
	if ($doel=="v"){$stub=$stub.$tussen."(doel='v')";$tussen=" AND ";}

	//Voorselectie voor de inhoud van de velden van de uitgebreide zoekfunctie
	if ($veld=="r" and strlen($m.$w.$a.$u.$s)==0) {$sqlstuk="SELECT DISTINCT onderwerpen FROM rlist ".$doelstub." order by onderwerpen asc";$veldnaam="onderwerpen";
	}elseif($veld=="w" and strlen($m.$a.$r.$u.$s)==0) {$sqlstuk="SELECT DISTINCT straten FROM wlist ".$doelstub." order by straten asc";	$veldnaam="straten";
	}elseif($veld=="m" and strlen($w.$a.$r.$u.$s)==0) {$sqlstuk="SELECT DISTINCT personen FROM plist ".$doelstub." order by personen asc";$veldnaam="personen";
	}elseif($veld=="a" and strlen($m.$w.$r.$u.$s)==0) {$sqlstuk="SELECT DISTINCT auteurs FROM alist ".$doelstub." order by auteurs asc";$veldnaam="auteurs";
	}elseif($veld=="u" and strlen($m.$w.$r.$a.$s)==0) {$sqlstuk="SELECT DISTINCT bronnen FROM ulist ".$doelstub." order by bronnen asc";$veldnaam="bronnen";
	}elseif($veld=="s" and strlen($m.$w.$r.$a.$u)==0) {$sqlstuk="SELECT DISTINCT soorten FROM slist ".$doelstub." order by soorten asc";$veldnaam="soorten";
	}else{
		if ($veld=="r") {$sqlstuk="SELECT veldr1 FROM lijst ".$stub." union select veldr2 from lijst ".$stub." union select veldr3 from lijst ".$stub." union select veldr4 from lijst ".$stub;$veldnaam="veldr1";
		}elseif($veld=="w") {$sqlstuk="SELECT DISTINCT straat FROM lijst ".$stub;$veldnaam="straat";
		}elseif($veld=="m") {$sqlstuk="SELECT persoon FROM lijst ".$stub." union select persoon2 from lijst ".$stub;$veldnaam="persoon";
		}elseif($veld=="a") {$sqlstuk="SELECT auteur1 FROM lijst ".$stub." union select auteur2 from lijst ".$stub." union select auteur3 from lijst ".$stub;$veldnaam="auteur1";
		}elseif($veld=="s") {$sqlstuk="SELECT DISTINCT soort1 FROM lijst ".$stub;$veldnaam="soort1";
		}elseif($veld=="u") {$sqlstuk="SELECT bron1 FROM lijst ".$stub." union select bron2 from lijst ".$stub." union select bron3 from lijst ".$stub;$veldnaam="bron1";
		}
	}
	//Doe de query
	$fprs=odbc_exec($objConnect, $sqlstuk);
	//Retourneer het resultaat in de HTML vorm van een select field
	$selectstring="";
	while($row=odbc_fetch_array($fprs)){
		$hulp=$row[$veldnaam];
		if (strlen($hulp)>0) {
			$selectstring=$selectstring."<option ";
			if ($z==$hulp){$selectstring=$selectstring." selected";}
			$selectstring=$selectstring.">".$hulp."</option>";
		}
	}
	unset($fprs);
	return $selectstring;;
}

//Voeg HTML code toe aan invoerstring om de zoekwoorden met gele achtergrond te markeren
//Indien compact=1 dan spaties negeren bij het vinden van de zoekwoorden (dus het woord erger wordt ook gevonden in de string: er geruime tijd)
function markeerzoekwoorden($invoerstring, $compact){
	global $zkw,$rechten,$zkwoorden,$mkstart,$mkeind,$z;
	$dezestring=$invoerstring;
	$mkgevonden=false;
	if (strlen($dezestring)>0){
		for ($mkteller=1;$mkteller<=$zkw;$mkteller++){ //aantal zoekwoorden
			$zinpointer=1;
			$woordpointer=1;
			$mkstart[$mkteller]=0;
			$mkeind[$mkteller]=0;
			$mkzk=$zkwoorden[$mkteller];
			$mklengte=strlen($mkzk);
			$mksuspend=0;
			if ($mklengte>1){
				while ($zinpointer<=strlen($dezestring) and $woordpointer<=$mklengte){
					$mkhulp=strtolower(substr($dezestring,$zinpointer-1,1));
					if ($mkhulp=="<" or $mkhulp==chr(16)){
						//skip eventueel aanwezige HTML code: <
						$mksuspend=1;
					}elseif($mkhulp==strtolower(substr($mkzk,$woordpointer-1,1)) and $mksuspend==0){
						if ($woordpointer==1){
							$mkstart[$mkteller]=$zinpointer;
						}else{
							$mkeind[$mkteller]=$zinpointer;
						}
						$woordpointer=$woordpointer+1;
					}elseif($mkhulp==chr(16) or $mkhulp==chr(17) or $mksuspend==1){
						if ($mkhulp==">" or $mkhulp==chr(17)){$mksuspend=0;} //Einde HTML code >
					}elseif($mksuspend==0 and !($mkhulp==" " and $compact>0)){
						if (strpos(strtolower($dezestring), strtolower($mkzk))!==false and $mkstart[$mkteller]>0){$zinpointer=$mkstart[$mkteller];}
						$mkstart[$mkteller]=0;
						$mkeind[$mkteller]=0;
						$woordpointer=1;
					}
					$zinpointer=$zinpointer+1;
				}
				if ($woordpointer>$mklengte){
					$mkhulp="";
					$mkgevonden=true;
					if ($mkstart[$mkteller]>1){$mkhulp=substr($dezestring,0,$mkstart[$mkteller]-1);}
					$dezestring=$mkhulp.chr(16).substr($dezestring,$mkstart[$mkteller]-1,$mkeind[$mkteller]-$mkstart[$mkteller]+1).chr(17).substr($dezestring,$mkeind[$mkteller]);
				}
			}
		}
		if ($mkgevonden==true and $compact==1){
			return str_replace(chr(17),"</span>",str_replace(chr(16),"<span class=".chr(39)."markeer".chr(39).">",$dezestring));
		}elseif ($mkgevonden==true and ($compact==2 or $compact==0)){
			return str_replace(chr(16),"<font style=".chr(39)."background-color:#FFFF00;color:#000000;".chr(39).">",str_replace(chr(17),"</font>",$dezestring));
		}else{
			return $dezestring;
		}
	}else{
		return $dezestring;
	}
}

//Bewerk input parameter z (zoekwoorden)
function bewerkz(){	
	global $toonalles,$m,$z,$zw,$u,$r,$s,$a,$w,$j,$p,$j2,$archiefnr,$uz,$zkw,$zkwoorden,$compactedsearch,$znav,$zinfo,$zkteller,$veldensom,$rechten,$zoekdbindex,$zoekwoord1;
	if(($rechten=="mo"  or $rechten=="sup") and (strpos($z,"dbindex")!==false or strpos($z,"NIEUWOBJECT")!==false)){
		$zoekdbindex=true;$z=str_replace("dbindex","",$z);
	}
	$z=zclean($z);
	if ($z=="*"){
		$toonalles=1;
		$m="";$u="";$r="";$s="";$a="";$w="";$j="";$j2="";$j3="";$j4="";$archiefnr="";$zw="";
		$z=str_replace("*", "",$z);
	}
	if (strlen($z)>0){
		$zkw=1;$zexact=false;
		for ($zkteller=1;$zkteller<=strlen($z);$zkteller++){
			$hulp=substr($z,$zkteller-1,1);
			if ($hulp=="'"){
				$zexact=!($zexact);
			}else{
				if ($hulp==" " and $zexact===false and $zkw<15){
					$zkw=$zkw+1;
				}else{
					$zkwoorden[$zkw]=$zkwoorden[$zkw].$hulp;
				}
			}
		}
		$znav=0;
		for($zki=1;$zki<=$zkw;$zki++){
			$zkwoorden[$zki]=trim($zkwoorden[$zki]);	 
			if (strlen($zkwoorden[$zki])>0){$znav=$znav+1;}
		}
		$zoekwoord1=$zkwoorden[1];
		$zinfo=str_replace("<","",$z);
		$zinfo=str_replace(">","",$zinfo);
		$zinfo=str_replace("?","",$zinfo);
		$zinfo=str_replace("!","",$zinfo);
		$zinfo=str_replace("*","",$zinfo);
		$zinfo=str_replace("'","",$zinfo);
		$zinfo=str_replace(".","",$zinfo);
		$zinfo=str_replace(",","",$zinfo);
		$zinfo=str_replace(chr(34),"",$zinfo);
		$compactedsearch=str_replace(" ", "",$zinfo);
	}
}

//Bewerk input parameter zw (zonder de woorden)
function bewerkzw(){
	global $zwkw,$zwkwoorden,$zw;
	$zw=zclean($zw);
	if (strlen($zw)>0){
		$zwkw=1;$zwexact=false;
		for ($zwkteller=1;$zwkteller<=strlen($zw);$zwkteller++){
			$hulp=substr($zw,$zwkteller-1,1);
			if ($hulp=="'"){
				$zwexact=!($zwexact);
			}else{
				if ($hulp==" " and $zwexact===false and $zwkw<10){
					$zwkw=$zwkw+1;
				}else{
					$zwkwoorden[$zwkw]=$zwkwoorden[$zwkw].$hulp;
				}
			}
		}
		for ($zwki=1;$zwki<=$zwkw;$zwki++){
			$zwkwoorden[$zwki]=trim($zwkwoorden[$zwki]);	 
		}
	}
}

//Stel de SQL Querystring samen
function construeerSQL(){
	global $somstuk,$fotoarchsom,$zsomstuk,$somstukcount,$zwsomstuk,$zkw,$zwkw,$m,$p,$u,$w,$s,$r,$a,$j,$j2,$j3,$j4,$compactedsearch,$veldensom,$zkwoorden,$zwkwoorden,$rechten,$doelstuk,$zoekdbindex,$zid,$tablename,$objConnect,$totaalstukocr;
	$stuk=array_fill(0, 25, '');$zstuk=array_fill(0, 25, '');$zwstuk=array_fill(0, 25, '');
	$ocrstukz=array_fill(0, 25, '');$ocrstukzw=array_fill(0, 25, '');
	$somstuk="";$ocrsomstuk="";$zsomstuk="";$zwsomstuk="";$uzstuk="";$ocrsomstukz="";$ocrsomstukzw="";
	$totaalstuk1=false;$totaalstuk2=false;$totaalstuk3=false;$totaalstukocr=false;
	$erzijn="";

	for ($zki=1;$zki<=$zkw;$zki++){
		if (strlen($zkwoorden[$zki])>0){
			$erzijn="a";
			if($zid=="j"){$ocrstukz[$zki]="tekstdeel like '%".$zkwoorden[$zki]."%'";}
		}
	}
	if($zid=="j"){
		for ($ocri=1;$ocri<=$zkw;$ocri++){
			$ocrsomstukz=$ocrsomstukz.$ocrstukz[$ocri];
			if (strlen($ocrstukz[$ocri+1])>0 and strlen($ocrsomstukz)>0){$ocrsomstukz=$ocrsomstukz." AND ";}
		}
		if(strlen($ocrsomstukz)>0){$ocrsomstukz="(".$ocrsomstukz.")";$totaalstukocr=true;}
	}
	for ($zki=1;$zki<=$zwkw;$zki++){
		if (strlen($zwkwoorden[$zki])>0){
			$erzijn="a";
			if($zid=="j"){$ocrstukzw[$zki]="tekstdeel NOT like '%".$zwkwoorden[$zki]."%'";}
		}
	}
	if($zid=="j"){
		for ($ocri=1;$ocri<=$zwkw;$ocri++){
			$ocrsomstukzw=$ocrsomstukzw.$ocrstukzw[$ocri];
			if (strlen($ocrstukzw[$ocri+1])>0 and strlen($ocrsomstukzw)>0){$ocrsomstukzw=$ocrsomstukzw." AND ";}
		}
		if(strlen($ocrsomstukzw)>0){$ocrsomstukzw="(".$ocrsomstukzw.")";$totaalstukocr=true;}
	}
	if($totaalstukocr==true){
		if(strlen($ocrsomstukzw)>0 and strlen($ocrsomstukz)>0){$ocrsomstukz="(".$ocrsomstukz." AND ".$ocrsomstukzw.")";}else{$ocrsomstukz=$ocrsomstukz.$ocrsomstukzw;}
		$tablename=strval(time());
		$ocrsql="SELECT kidx into ".$tablename." FROM ocr WHERE ".$ocrsomstukz;
		odbc_exec($objConnect,$ocrsql);
	}

	if (strlen("".$erzijn.$m.$p.$u.$w.$s.$r.$a.$j.$j2.$j3.$j4)>0){
		if (strlen($u)>0){$stuk[1]="(bron1='".$u."' OR bron2='".$u."' OR bron3='".$u."')";}
		if (strlen($s)>0){$stuk[2]="(soort1='".$s."')";}
		if (strlen($r)>0){$stuk[3]="(veldr1='".$r."' OR veldr2='".$r."' OR veldr3='".$r."' OR veldr4='".$r."')";}
		if (strlen($a)>0){$stuk[4]="(auteur1='".$a."' OR auteur2='".$a."' OR auteur3='".$a."')";}
		if (strlen($m)>0){$stuk[6]="(persoon='".$m."' OR persoon2='".$m."')";}
		if (strlen($w)>0){$stuk[5]="(straat='".$w."')";}
		
		if (strlen($j)>0){
			if (strlen($j2)>0){
				$stuk[7]="((jaar >= '".$j."' AND jaar <= '".$j2."') OR jaar like '%".$j2."%')";
			}else{
				$stuk[7]="((jaar >= '".$j."' AND jaar not like '%onbekend%') OR jaar like '%".$j."%')" ;
			}
		}else{
			if (strlen($j2)>0){$stuk[7]="(jaar <= '".$j2."' OR jaar like '%".$j2."%')";}
		}

		if (strlen($j3)>0){
			if (strlen($j4)>0){
				$stuk[8]="((jaar2 >= '".$j3."' AND jaar2 <= '".$j4."') OR jaar2 like '%".$j4."%')";
			}else{
				$stuk[8]="((jaar2 >= '".$j3."' AND jaar2 not like '%onbekend%') OR jaar2 like '%".$j3."%')" ;
			}
		}else{
			if (strlen($j4)>0){$stuk[8]="(jaar2 <= '".$j4."' OR jaar2 like '%".$j4."%')";}
		}

		for ($ii=1;$ii<=10;$ii++){
			$uzstuk=$uzstuk.$stuk[$ii];
			if (strlen($stuk[$ii+1])>0 and strlen($uzstuk)>0){$uzstuk=$uzstuk." AND ";}
		}
		if (strlen($uzstuk)>0){
			$uzstuk="(".$uzstuk.")";
			$totaalstuk3=true;
		}
		
		$doelstuk="(doel='v')";$vepi=1;
		if($rechten=="mo" or $rechten=="sup"){
			$doelstuk="";$vepstub="";
			for($vepi=0;$vepi<3;$vepi++){
				$hulpvepi=substr($p,$vepi,1);
				if($hulpvepi!="_"){$doelstuk=$doelstuk.$vepstub."doel='".$hulpvepi."'";$vepstub=" OR ";}
			}
			if($doelstuk!=""){$doelstuk="(".$doelstuk.")";}
		}

		if ($rechten=="ufa"){$doelstuk="(doel <>'p')";}

		for ($stukteller=1;$stukteller<=$zwkw;$stukteller++){
			$zwk=$zwkwoorden[$stukteller];
			if (strlen($zwk)>0){
				$zwstuk[$stukteller]="((".$veldensom."&' '&beschrijving NOT like '%".$zwk."%')";
				if (strlen($zwk)==4){$zwstuk[$stukteller]=$zwstuk[$stukteller]." AND (jaar&' '&jaar2 NOT like '%".$zwk."%')";}
				$zwstuk[$stukteller]=$zwstuk[$stukteller].")";
			}
		}
		for ($zwii=1;$zwii<=$zwkw;$zwii++){
			$zwsomstuk=$zwsomstuk.$zwstuk[$zwii];
			if (strlen($zwstuk[$zwii+1])>0 and strlen($zwsomstuk)>0){$zwsomstuk=$zwsomstuk." AND ";}
		}
		if (strlen($zwsomstuk)>0){
			$zwsomstuk="(".$zwsomstuk.")";
			$totaalstuk1=true;
		}

		for ($stukteller=1;$stukteller<=$zkw;$stukteller++){
			$zk=$zkwoorden[$stukteller];
			if (strlen($zk)>0){
				$zstuk[$stukteller]="(".$veldensom."&".$fotoarchsom." like '%".$zk."%'";
				$zstuk[$stukteller]=$zstuk[$stukteller]." OR beschrijving like '%".$zk."%'";
				if (strlen($zk)==4){$zstuk[$stukteller]=$zstuk[$stukteller]." OR jaar&' '&jaar2 like '%".$zk."%'";}
				if ($zoekdbindex==true){$zstuk[$stukteller]=$zstuk[$stukteller]." OR (Str(Key) like '%".$zk."%')";}
				$zstuk[$stukteller]=$zstuk[$stukteller].")";
			}
		}
		for ($zii=1;$zii<=$zkw;$zii++){
			$zsomstuk=$zsomstuk.$zstuk[$zii];
			if (strlen($zstuk[$zii+1])>0 and strlen($zsomstuk)>0){$zsomstuk=$zsomstuk." AND ";}
		}
		if (strlen($zsomstuk)>0 and strlen($compactedsearch)>0){$zsomstuk=$zsomstuk." OR (titelsamen like '%".$compactedsearch."%')";}

		if (strlen($zsomstuk)>0){
			$zsomstuk="(".$zsomstuk.")";
			$totaalstuk2=true;
		}

		$erissom=false;
		if ($totaalstuk1){
			$somstuk=$zwsomstuk;
			$erissom=true;
		}
		if ($totaalstuk2){
			if ($erissom){$somstuk=$somstuk. " AND ";}
			$somstuk=$somstuk.$zsomstuk;
			$erissom=true;
		}
		if ($totaalstuk3){
			if ($erissom){$somstuk=$somstuk. " AND ";}
			$somstuk=$somstuk.$uzstuk;
			$erissom=true;
		}
		if ($erissom and strlen($doelstuk)>0){$somstuk=$somstuk." AND ".$doelstuk;}
		if($erissom){$somstuk="SELECT * FROM archief WHERE (".$somstuk.")";}

		if($zid=="j" and $totaalstukocr==true){
			for ($zidi=1;$zidi<=12;$zidi++){
				$ocrsomstuk=$ocrsomstuk."SELECT * FROM archief WHERE (foto".strval($zidi)." IN (SELECT kidx FROM ".$tablename.")";
				if($totaalstuk3){$ocrsomstuk=$ocrsomstuk." AND ".$uzstuk;}
				if (strlen($doelstuk)>0){$ocrsomstuk=$ocrsomstuk." AND ".$doelstuk;}
				$ocrsomstuk=$ocrsomstuk.")";
				if($zidi<12){$ocrsomstuk=$ocrsomstuk." UNION ";}
			}
			if($erissom){
				$somstuk="SELECT DISTINCT * FROM (".$ocrsomstuk." UNION ".$somstuk.")";
			}else{
				$somstuk="SELECT DISTINCT * FROM (".$ocrsomstuk.")";
			}
		}
		$somstukcount="Select COUNT(*) AS aantal FROM(".$somstuk.")";
	}
}

$ios=false;
if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPad')) {$ios=true;}

//Initialiseer variabelen
$thumbsmap=$basis."BPT";$fotomap=$basis."BPD";
$RecordsExist=0;
$toonalles=0;
$somstuk="";$sortstuk="";$zsomstuk="";$somstukcount="";
$uz=""; //uitgebreid zoeken
$vi=""; //lijst of galerij
$zid="n"; //zoek in documenten
$zoekdbindex=false;$zoekwoord1="";
$zki=0;$zkw=0;$zwkw=0;$stukteller=0;
$zk="";$zwk="";
$m="";$w="";$u="";$r="";$s="";$a="";$p="";$j="";$j2="";$j3="";$j4="";$archiefnr="";$mapnr="";$z="";$zw="";$li="";
$zorig="";$zworig="";
$zkteller=0;$zwkteller=0;
$znav=0;
$zinfo="";
$bck="";
$compactedsearch="";
$googlewoord=false;
$jaar="";$maand="";$dag="";$datsort="";
$jaar2="";$maand2="";$dag2="";$datsort2="";
$hulppg="";$pg=1;
$fp_sQry="";$fp_sQryCount="";
$faantal=0;
$tablename="";$totaalstukocr=false;

//Initialiseer arrays
$zkwoorden=array_fill(0, 20, '');$zkwoordenoud=array_fill(0, 20, '');$zwkwoorden=array_fill(0, 20, '');$zwkwoordenoud=array_fill(0, 20, '');
$mkstart=array_fill(0, 16, '');$mkeind=array_fill(0, 16, '');
$soorten=array_fill(0, 150, '');
$mappen=array_fill(0,250,"");
$soortteller=0;$mapteller=0;
	
//Lees parameters
if(isset($_REQUEST['bck'])){$bck=cleaninput($_REQUEST["bck"],1);}
if(isset($_REQUEST['vi'])){$vi=cleaninput($_REQUEST["vi"],1);}
if(isset($_REQUEST['uz'])){$uz=cleaninput($_REQUEST["uz"],1);}
if(isset($_REQUEST['pg'])){$hulppg=cleaninput($_REQUEST["pg"],2);}
if(isset($_REQUEST['archiefnr'])){$archiefnr=cleaninput(str_replace(" ","",$_REQUEST["archiefnr"]),2);$uz="j";}
if(isset($_REQUEST['mapnr'])){$mapnr=cleaninput($_REQUEST["mapnr"],0);$uz="j";}
if(isset($_REQUEST['z'])){$z=cleaninput($_REQUEST["z"],1);}
if(isset($_REQUEST['uz'])){$uz=cleaninput($_REQUEST["uz"],0);}
if(isset($_REQUEST['w'])){$w=cleaninput($_REQUEST["w"],0);}
if(isset($_REQUEST['a'])){$a=cleaninput($_REQUEST["a"],0);}
if(isset($_REQUEST['u'])){$u=cleaninput($_REQUEST["u"],0);}
if(isset($_REQUEST['r'])){$r=cleaninput($_REQUEST["r"],0);}
if(isset($_REQUEST['s'])){$s=cleaninput($_REQUEST["s"],0);}
if(isset($_REQUEST['m'])){$m=cleaninput($_REQUEST["m"],0);}
if(isset($_REQUEST['p'])){$p=cleaninput($_REQUEST["p"],2);}
if(isset($_REQUEST['zw'])){$zw=cleaninput($_REQUEST["zw"],1);}
if(isset($_REQUEST['j'])){$j=cleaninput($_REQUEST["j"],2);}
if(isset($_REQUEST['j2'])){$j2=cleaninput($_REQUEST["j2"],2);}
if(isset($_REQUEST['j3'])){$j3=cleaninput($_REQUEST["j3"],2);}
if(isset($_REQUEST['j4'])){$j4=cleaninput($_REQUEST["j4"],2);}
if(isset($_REQUEST['zid'])){$zid=cleaninput($_REQUEST["zid"],0);}
	
//Bewerk parameters voordat ze gebruikt worden
if(strlen($w.$a.$u.$r.$s.$zw.$p.$j.$j2.$j3.$j4)>0){$uz="j";}
$av="bp";
if ($uz!="j"){$uz="n";}
if ($zid!="j"){$zid="n";}
if ($vi!="ga"){$vi="li";}
if ($p=="" and ($rechten=="mo" or $rechten=="sup")){$p="vep";}
if (is_numeric($hulppg)){
	$pg=0+$hulppg;
	if ($pg==0){$pg=1;}
}
if ($pg==0){$pg=1;}
if (strlen($j)>0){
	str_pad($j, 4, "0", STR_PAD_LEFT);
	if (strlen($j)>4 and $j<>"Onbekend"){$j=substr($j,0,4);}
}
if (strlen($j2)>0){
	str_pad($j2, 4, "0", STR_PAD_LEFT);
	if (strlen($j2)>4 and $j<>"Onbekend"){$j2=substr($j2,0,4);}
}
if ($j2<$j and strlen($j2)>0){$jtemp=$j;$j=$j2;$j2=$jtemp;}
if ($j4<$j3 and strlen($j4)>0){$jtemp=$j3;$j3=$j4;$j4=$jtemp;}

$paramstring="&amp;av=bp";
if(strlen($w)>0){$paramstring=$paramstring."&amp;w=".$w;}
if(strlen($u)>0){$paramstring=$paramstring."&amp;u=".$u;}
if(strlen($a)>0){$paramstring=$paramstring."&amp;a=".$a;}
if(strlen($s)>0){$paramstring=$paramstring."&amp;s=".$s;}
if(strlen($r)>0){$paramstring=$paramstring."&amp;r=".$r;}
if(strlen($z)>0){$paramstring=$paramstring."&amp;z=".$z;}
if(strlen($zw)>0){$paramstring=$paramstring."&amp;zw=".$zw;}
if(strlen($zid)>0){$paramstring=$paramstring."&amp;zid=".$zid;}
if(strlen($p)>0){$paramstring=$paramstring."&amp;p=".$p;}
if(strlen($m)>0){$paramstring=$paramstring."&amp;m=".$m;}
if(strlen($j)>0){$paramstring=$paramstring."&amp;j=".$j;}
if(strlen($j2)>0){$paramstring=$paramstring."&amp;j2=".$j2;}
if(strlen($j3)>0){$paramstring=$paramstring."&amp;j3=".$j3;}
if(strlen($j4)>0){$paramstring=$paramstring."&amp;j4=".$j4;}
if(strlen($uz)>0){$paramstring=$paramstring."&amp;uz=".$uz;}
if(strlen($archiefnr)>0){$paramstring=$paramstring."&amp;archiefnr=".$archiefnr;}
if(strlen($mapnr)>0){$paramstring=$paramstring."&amp;mapnr=".$mapnr;}
if(strlen($paramstring)>0){$paramstring="?".substr($paramstring,5);}else{$paramstring="?z=";}
$paramstring=str_replace(chr(34), "%22", $paramstring);

$w=str_replace("%20", " ",$w);
$a=str_replace("%20", " ",$a);
$u=str_replace("%20", " ",$u);
$r=str_replace("%20", " ",$r);
$s=str_replace("%20", " ",$s);
$m=str_replace("%20", " ",$m);
$zorig=$z;
$zworig=$zw;
if (strlen($z)>0){bewerkz();}
if (strlen($zw)>0){bewerkzw();}

$veldensom="archiefnr&' '&mapnr&' '&itemtitle&' '&persoon&' '&persoon2&' '&straat&' '&veldr1&' '&veldr2&' '&veldr3&' '&veldr4&' '&soort1&' '&bron1&' '&bron2&' '&bron3&' '&auteur1&' '&auteur2&' '&auteur3";
$fotoarchsom="' '&foto1arch&' '&foto2arch&' '&foto3arch&' '&foto4arch&' '&foto5arch&' '&foto6arch&' '&foto7arch&' '&foto8arch&' '&foto9arch&' '&foto10arch&' '&foto11arch&' '&foto12arch";
if($z!=""){
	if (strpos(".doc .xls .xls .ppt .rtf .pdf .txt", substr($z,0,4))!==false){
		$fotoarchsom="' '&foto1&' '&foto2&' '&foto3&' '&foto4&' '&foto5&' '&foto6&' '&foto7&' '&foto8&' '&foto9&' '&foto10&' '&foto11&' '&foto12";
	}
}

//Finaliseer de SQL Querystring
construeerSQL();

//if ($somstuk=="" and $p=="n"){$toonalles=1;}
$aantalrecords=0;
$sortstuk=" ORDER BY persoon,persoon2,jaar,itemtitle ASC";
if (strlen($archiefnr)>0 and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE archiefnr&".$fotoarchsom." like '%".$archiefnr."%'";
	$fp_sQry="SELECT * FROM archief WHERE archiefnr&".$fotoarchsom." like '%".$archiefnr."%'";
}elseif(strlen($archiefnr)>0 and $rechten=="ufa"){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel<>'p' AND archiefnr='".$archiefnr."'";
	$fp_sQry="SELECT * FROM archief WHERE doel<>'p' AND archiefnr='".$archiefnr."'";
}elseif(strlen($archiefnr)>0){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel='v' AND archiefnr='".$archiefnr."'";
	$fp_sQry="SELECT * FROM archief WHERE doel='v' AND archiefnr='".$archiefnr."'";
}elseif(strlen($archiefnr)>0){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel='v' AND archiefnr='".$archiefnr."'";
	$fp_sQry="SELECT * FROM archief WHERE doel='v' AND archiefnr='".$archiefnr."'";
}elseif (strlen($mapnr)>0 and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE mapnr='".$mapnr."'";
	$fp_sQry="SELECT * FROM archief WHERE mapnr='".$mapnr."'";
}elseif(strlen($mapnr)>0 and $rechten=="ufa"){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel<>'p' AND mapnr='".$mapnr."'";
	$fp_sQry="SELECT * FROM archief WHERE doel<>'p' AND mapnr='".$mapnr."'";
}elseif(strlen($mapnr)>0){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel='v' AND mapnr='".$mapnr."'";
	$fp_sQry="SELECT * FROM archief WHERE doel='v' AND mapnr='".$mapnr."'";
}elseif($toonalles==1 and ($rechten=="ufa")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE doel<>'p' ";
	$fp_sQry="SELECT * FROM archief WHERE doel<>'p' ";
	$fp_sQry=$fp_sQry.$sortstuk;
}elseif($toonalles==1 and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief ";
	$fp_sQry="SELECT * FROM archief ";
	if($doelstuk!=""){$fp_sQry=$fp_sQry." WHERE ".$doelstuk;$fp_sQryCount=$fp_sQryCount." WHERE ".$doelstuk;}
	$fp_sQry=$fp_sQry.$sortstuk;
}elseif($toonalles==1){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief where doel ='v' ";
	$fp_sQry="SELECT * FROM archief where doel='v' ".$sortstuk;
}elseif($z=="recent toegevoegd" and ($rechten=="ufa")){
	$fp_sQryCount="SELECT COUNT (*) as aantal FROM (SELECT TOP 250 * FROM archief WHERE doel<>'p')";
	$fp_sQry="SELECT TOP 250 * FROM archief WHERE doel<>'p' ORDER BY ts DESC";
}elseif($z=="recent toegevoegd" and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT (*) as aantal FROM (SELECT TOP 250 * FROM archief)";
	$fp_sQry="SELECT TOP 250 * FROM archief ORDER BY ts DESC";
}elseif($z=="recent toegevoegd"){
	$fp_sQryCount="SELECT COUNT (*) as aantal FROM (SELECT TOP 250 * FROM archief WHERE doel='v')";
	$fp_sQry="SELECT TOP 250 * FROM archief WHERE doel='v' ORDER BY ts DESC";
}elseif($z=="recent aangepast" and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT (*) as aantal FROM (SELECT TOP 500 * FROM archief)";
	$fp_sQry="SELECT TOP 500 * FROM archief ORDER BY tse DESC";
}elseif($z=="errarchnrs" and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE fout='x' OR dubbel='x' OR archiefnr='999999'";
	$fp_sQry="SELECT * FROM archief WHERE fout='x' OR dubbel='x' OR archiefnr='999999' ORDER BY archiefnr ASC";
}elseif(strpos($z,"NIEUWOBJECT")!==false and ($rechten=="mo" or $rechten=="sup")){
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM archief WHERE itemtitle like'%nieuwobject%'";
	$fp_sQry="SELECT * FROM archief WHERE itemtitle like'%nieuwobject%' ORDER BY ts DESC";
}elseif(strlen($somstuk)>0){
	$fp_sQryCount=$somstukcount;
	$fp_sQry=$somstuk.$sortstuk;
}

//Doe de query
if (strlen($fp_sQry)>0){	//SELECTIE GEMAAKT
	if ($vi=="li"){
		if ($rechten=="mo" or $rechten=="sup"){$pagesize=12;}else{$pagesize=20;}
	}else{
		$pagesize=48;
	}
	if	($rechten=="mo" or $rechten=="sup"){
		//Lees Soorten
		$fprs=odbc_exec($defConnect, "SELECT soortenb FROM soortenb ORDER BY soortenb ASC");
		while($fp_rs=odbc_fetch_array($fprs)){
			if(strlen($fp_rs["soortenb"])>0){ 
				$soortteller++;
				$soorten[$soortteller]=$fp_rs["soortenb"];
			}
		}
		unset($fprs);
	}
	
	$fprs=odbc_exec($objConnect,$fp_sQryCount);
	if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];}

	if ($aantalrecords>0){
		$RecordsExist=1;
		$fprs=odbc_exec($objConnect,$fp_sQry);
	}
	if($rechten!="mo" and $rechten!="sup" and (strlen($z)>0 or strlen($zw)>0 or $json)){
		// Update zoekwoordenlog
		$zinDate=date("Y-M-d");$zinTime=date("h.i.s");
		$logfile="log/scorsbpzoeklog.txt";
		$logzin=$zinDate." ".$zinTime." gezocht op: ".$z;
		if(strlen($zw)>0){$logzin.=", zonder de woorden: ".$zw;}
		$logzin.=", resultaat: ".strval($aantalrecords);
		if($json){$logzin.=" JSON";}
		$logzin.=chr(13).chr(10);
	//		error_reporting(0);
		$oTextFile = fopen($logfile, "a");
		fwrite($oTextFile,$logzin);
		fclose($oTextFile);		
	//		error_reporting(-1);
		if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
			$newname="log/scorsbpzoeklog ".$zinDate." ".$zinTime.".txt";
			echo "<br>Log recycled: ".$newname;
			rename ($logfile,$newname);
		}
	}
	//move to position
	$CurrentPage=$pg;
	$PageCount=intdiv($aantalrecords,$pagesize)-(($aantalrecords%$pagesize)==0)+1;
	if ($CurrentPage<1){$CurrentPage=1;}
	if ($CurrentPage>$PageCount){$CurrentPage=$PageCount;}
}

//Editor functies
if (($rechten=="mo" or $rechten=="sup") and $vi=="li" and $RecordsExist==1){ ?>
	<div id="selframes" class="combo2" align="left" style="background-color:#eeeeee;">
		<font size="1"><b>Update status</b></font><br><img src="<?php echo $basis; ?>images/green.png" id="ineditlog"><br>
		<iframe class="editresult randgeen" src="" id="fu0" name="fu0" width="125" height="150" scrolling="yes" onload="checkedit('0');"></iframe><br>
		<iframe class="editresult randgeen" src="" id="fu1" name="fu1" width="125" height="150" scrolling="yes" onload="checkedit('1');"></iframe><br>
		<iframe class="editresult randgeen" src="" id="fu2" name="fu2" width="125" height="150" scrolling="yes" onload="checkedit('2');"></iframe><br>
		<iframe class="editresult randgeen" src="" id="fouresult" name="fouresult" width="125" height="150" scrolling="yes" ></iframe>
	</div>
	<div style="display:none;">
		<iframe src="" id="fou1" name="fou1" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('1');"></iframe>
		<iframe src="" id="fou2" name="fou2" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('2');"></iframe>
		<iframe src="" id="fou3" name="fou3" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('3');"></iframe>
		<iframe src="" id="fou4" name="fou4" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('4');"></iframe>
		<iframe src="" id="fou5" name="fou5" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('5');"></iframe>
		<iframe src="" id="fou6" name="fou6" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('6');"></iframe>
		<iframe src="" id="fou7" name="fou7" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('7');"></iframe>
		<iframe src="" id="fou8" name="fou8" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('8');"></iframe>
		<iframe src="" id="fou9" name="fou9" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('9');"></iframe>
		<iframe src="" id="fou10" name="fou10" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('10');"></iframe>
		<iframe src="" id="fou11" name="fou11" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('11');"></iframe>
		<iframe src="" id="fou12" name="fou12" width=225 height=50 scrolling="yes" frameborder="0" onload="checkresult('12');"></iframe>
		<form id="edit0" name="edit0" action="<?php echo $basis; ?>bpadmin.php" target="fu0" method="POST" accept-charset="UTF-8">
			<input type="hidden" name="aktie" value="fieldupdate">
			<input type="hidden" name="Key" value="">
			<input type="hidden" name="realfield" value="">
			<input type="hidden" name="fieldcontent" value=""> 
			<input type="hidden" name="backup" value="">
		</form>
		<form id="edit1" name="edit1" action="<?php echo $basis; ?>bpadmin.php" target="fu1" method="POST" accept-charset="UTF-8">
			<input type="hidden" name="aktie" value="fieldupdate">
			<input type="hidden" name="Key" value="">
			<input type="hidden" name="realfield" value="">
			<input type="hidden" name="fieldcontent" value=""> 
			<input type="hidden" name="backup" value="">
		</form>
		<form id="edit2" name="edit2" action="<?php echo $basis; ?>bpadmin.php" target="fu2" method="POST" accept-charset="UTF-8">
			<input type="hidden" name="aktie" value="fieldupdate">
			<input type="hidden" name="Key" value="">
			<input type="hidden" name="realfield" value="">
			<input type="hidden" name="fieldcontent" value=""> 
			<input type="hidden" name="backup" value="">
		</form>
	</div>
<?php	
} ?>
<?php if ($json){
//********START JSON

//Construeer en echo JSON string
	if ($aantalrecords>0){
		$currentrecord=1;
		echo "{".chr(34)."aantalrecords".chr(34).":".chr(34).strval($aantalrecords).chr(34).",".chr(34)."records".chr(34).":[";
		while($row=odbc_fetch_array($fprs)){
			echo "{";
			echo chr(34)."archiefnummer".chr(34).":".chr(34).$row["archiefnr"].chr(34).",";
			echo chr(34)."titel".chr(34).":".chr(34).$row["itemtitle"].chr(34).",";
			echo chr(34)."beschrijving".chr(34).":".chr(34).str_replace(chr(34),"",$row["beschrijving"]).chr(34).",";
			echo chr(34).$veldwnaam.chr(34).":".chr(34).$row["straat"].chr(34).",";
			echo chr(34).$veldrnaam.chr(34).":".chr(34).$row["veldr1"].chr(34).",";
			echo chr(34)."soort".chr(34).":".chr(34).$row["soort1"].chr(34).",";
			echo chr(34)."geboortedatum".chr(34).":".chr(34).$row["jaar"].chr(34).",";
			echo chr(34)."overlijdensdatum".chr(34).":".chr(34).$row["jaar2"].chr(34).",";
			echo chr(34).$veldmnaam." (1)".chr(34).":".chr(34).$row["persoon"].chr(34).",";
			echo chr(34).$veldmnaam." (2)".chr(34).":".chr(34).$row["persoon2"].chr(34).",";
			echo chr(34).$veldunaam.chr(34).":".chr(34).$row["bron1"].chr(34).",";
			echo chr(34).$veldanaam.chr(34).":".chr(34).$row["auteur1"].chr(34).",";
			for ($i=1;$i<=12;$i++){
				echo chr(34)."foto".strval($i).chr(34).":".chr(34);
				if(strlen($row["foto".strval($i)])>0){
					$keydir=substr(strval($row["Key"]),0,3);
					echo $basis."BPD/".$keydir."/".$row["foto".strval($i)];
				}
				echo chr(34).",";
				echo chr(34)."thumb".strval($i).chr(34).":".chr(34);
				if(strlen($row["thumb".strval($i)])>0){
					$keydir=substr(strval($row["Key"]),0,3);
					echo $basis."BPT/".$keydir."/".$row["thumb".strval($i)];
				}
				echo chr(34).",";
			}
			echo chr(34)."objectURL".chr(34).":".chr(34).$basis."index.php?av=bp&archiefnr=".strval($row["archiefnr"]).chr(34);
			echo "}";
			if($currentrecord<$aantalrecords){echo ",";}
			$currentrecord++;
		}
		echo "]}";
	}else{
		echo "{".chr(34)."availablerecords".chr(34).":0,".chr(34)."records".chr(34).":[]}";
	}

//********EINDE JSON
}else{
//********START NIET-JSON
?>	
	<div id="top" style="margin:0px <?php echo $maxmarg; ?>px;" align="left"> <!-- Zoekblok DIV -->
	<br>
	<!-- ZOEKBLOK FORMSTART-->
	<input type="hidden" id="vi" name="vi" value="<?php echo $vi; ?>">
	<input type="hidden" id="uz" name="uz" value="<?php echo $uz; ?>">
	<input type="hidden" id="pg" name="pg" value="<?php echo $pg; ?>">
	<input type="hidden" id="aap" name="aap" value="<?php echo $p; ?>">
	<input type="hidden" id="archiefnr" name="archiefnr" value="<?php echo $archiefnr; ?>">

	<!-- ZOEKBLOK EENVOUDIG-->

	<div style="margin:3px 0px;" align="left">
			<button class="ggbutton" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&z=recent%20toegevoegd&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>');">Recent<br>toegevoegd</button>&nbsp;
			<?php if($rechten=="mo" or $rechten=="sup"){ ?>
				&nbsp;<button class="ggbutton" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&z=recent%20aangepast&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>');">Recent<br>aangepast</button>&nbsp;
			<?php
			} ?>
			<button class="ggbutton" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&uz=<?php if ($uz=="n"){ ?>j<?php }else{ ?>n<?php } ?>&vi=<?php echo $vi; ?>');">Ga naar<br><?php if ($uz=="n"){ ?>uitgebreid<?php }else{ ?>eenvoudig<?php } ?> zoeken</button>&nbsp;
			<?php if($fp_sQry<>""){ ?>
				<button class="ggbutton" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&vi=<?php echo $vi; ?>');">Terug naar<br>begin</button>&nbsp;
			<?php
			} ?>
	</div>

	<table border="0" class="bcollapse" cellspacing="0" cellpadding="0" width="842"><tr><td align="left">
	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="25">
			<a class="info deconone"><button class="qbutton"><b>?</b></button>
			<span><font class="aatekst2"><b>Zoektips voor &#39;Vrij zoeken&#39;</b>
			<ul>
			<li>In de zoekvelden kunnen geen letters met trema&#39;s, umlauten etc. worden gebruikt</li>
			<li>Laat algemene woorden als &#39;het&#39;, &#39;een&#39;, &#39;de&#39; etc. weg.</li>
			<li>Incomplete zoekwoorden zijn toegestaan. <b>Franc Jac</b> geeft 
			het zelfde resultaat als <b>Franciscus Jacobus</b>.</li>
			<li>Splits woorden, b.v. <b>oorlog&nbsp;&nbsp;slachtoffer</b> i.p.v. <b>oorlogslachtoffer</b>.</li>
			<li>Plaats uw zoekopdracht tussen aanhalingstekens om exact daarop te 
			zoeken, b.v. <b>&quot;pastoor Peters&quot;</b>.</li>
			<li>Het zoeken toont alleen resultaten die álle zoekwoorden bevatten.</li>
			<li>Bij een ingave van 3 of meer letters zal geprobeerd worden op
			basis daarvan al een aantal suggesties te tonen.</li>
			<li>Zoekwoord <b>&nbsp;*&nbsp;</b> geeft alle objecten weer.</li>
			<li>U kunt ook zoeken op archiefnummer.<?php if ($rechten=="mo" or $rechten=="sup"){ ?> Door de toevoeging van het woord <b>&quot;dbindex&quot;</b> wordt in de resultaten ook het record met dit als database-indexnummer weergegeven.<?php } ?></li>
			</ul></font></span></a>
		</td>
		<td align="left" width="130"><font class="aatekst2"><i>Vrij zoeken:</i></font></td>
		<?php $zwaarde=str_replace(chr(34),"&quot;",str_replace("'","&quot;",$zorig)); ?>
		<td width="250"><input onkeypress="keyPressListener(event);" id="z" name="z" value="<?php if ($toonalles==1){ ?>*<?php }else{echo $zwaarde;} ?>" class="invulz" onfocus="zetzoek('z');"></td>
		<td width="20"><img title="wis dit veld" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="25">
		<div <?php if($ocr==""){ ?>style="display:none;"<?php } ?>>
			<a class="info deconone"><button class="qbutton"><b>?</b></button>
			<span><font class="aatekst2">Vink het hokje aan om het zoeken ook te laten plaatsvinden in de tekst van de documenten zelf.<br>
			Er wordt alleen gezocht in PDF documenten met gedrukte tekst.<br>
			<i>Let op</i>: dit kan het zoekproces vertragen.
			</font></span></a>
			</div>
		</td>
		<td align="left" width="230" class="geenwrap">
			<div <?php if($ocr==""){ ?>style="display:none;"<?php } ?>>
			<i><font class="aatekst2">Zoek ook in de documenten zelf&nbsp;<input onclick="togglezid();zetzoek('zid');" type="checkbox" name="zid" id="zid" <?php if($zid=="j"){ echo " checked ";} ?> value="<?php if($zid=='j'){ echo 'j';} ?>">
			</div>
		</td>
		<td align="left" width="50">&nbsp;</td>
		<td width="120">
				<button class="aazoekbutton" onclick="aazoek();"><b><b>&nbsp;ZOEK&nbsp;</b></b></button><br>
		</td>
	</tr></table>

	<!-- ZOEKBLOK UITGEBREID-->
	<?php $hoogte=26; ?>
	<div id="uzblok" style="display:<?php if($uz=="n"){ ?>none<?php }else{ ?>block<?php } ?>;"> <!--UZblock DIV -->

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">
			<a class="info deconone"><button class="qbutton"><b>?</b></button>
			<span><font class="aatekst2">Resultaten die &eacute;&eacute;n of meer van de hier opgegeven woorden bevatten zullen worden uitgesloten.<br><br>
			Plaats combinaties van woorden tussen aanhalingstekens om die exacte combinatie uit te sluiten, b.v. <b>&quot;pastoor Peters&quot;</b>.
			</font></span></a>
		</td>
		<td align="left" width="130"><font class="aatekst2"><i>Bevat niet:</i></font></td>
		<?php if ($toonalles=="1"){$zwwaarde="";}else{$zwwaarde=str_replace(chr(34),"&quot;",str_replace("'","&quot;",$zworig));} ?>
		<td width="250"><input onkeypress="keyPressListener(event);" id="zw" name="zw" value="<?php echo $zwwaarde; ?>" class="invulz" onfocus="zetzoek('zw');"></td>
		<td width="20"><img title="wis dit veld" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('zw');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">&nbsp;
		</td>
		<td align="left" width="130"><font class="aatekst2"><i>Soort:</i></font></td>
		<td width="250">
			<div id="soptions">
			<select class="invulveld zoekinvul" id="aas" name="aas" onfocus="zetzoek('s');" onChange="zoekalloptions('s');"><option value=""></option>
				<?php
				echo selectstring($s,$a,$u,$m,$r,$s,$w,"s");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aas');zoekalloptions('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">
			<a class="info deconone"><button class="qbutton"><b>?</b></button>
			<span><font class="aatekst2"><b>Zoeken op jaartallen van geboorte en overlijden:</b><ul><li>Vul alleen het VANAF jaar in om 
				alle objecten te tonen vanaf dat jaar tot nu.</li>
			<li>Vul zowel het VANAF jaar als het T/M jaar in om alle objecten te tonen 
			uit de tussenliggende periode (incl. objecten uit de ingevulde jaartallen 
			zelf).</li>
			<li>Vul alleen het T/M jaar in om alle objecten te tonen tot en met dat 
			jaar en ouder.</li>
			</ul>
			</font></span></a>
		</td>
		<td align="left" width="150" class="nowrap"><font class="aatekst2"><i>Geboortejaar vanaf:</i></font></td>
		<td width="170" class="geenwrap" align="left">
			<font class="aatekst2"><i>
			<input onkeypress="keyPressListener(event);" class="invulj" id="j" name="j" value="<?php echo $j; ?>" maxlength="4" onfocus="zetzoek('j');" onblur="checknummer('j');">
			&nbsp;t/m:&nbsp;<input onkeypress="keyPressListener(event);" class="invulj" id="j2" name="j2" value="<?php echo $j2; ?>" maxlength="4" onfocus="zetzoek('j2');" onblur="checknummer('j2');">
			</i></font>
		</td>
		<td width="80" align="left"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('j');wiskeus('j2');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">&nbsp;
		</td>
		<td align="left" width="150" class="nowrap"><font class="aatekst2"><i>Overlijdensjaar vanaf:</i></font></td>
		<td width="170" class="geenwrap" align="left">
			<font class="aatekst2"><i>
			<input onkeypress="keyPressListener(event);" class="invulj" id="j3" name="j3" value="<?php echo $j3; ?>" maxlength="4" onfocus="zetzoek('j3');" onblur="checknummer('j3');">
			&nbsp;t/m:&nbsp;<input onkeypress="keyPressListener(event);" class="invulj" id="j4" name="j4" value="<?php echo $j4; ?>" maxlength="4" onfocus="zetzoek('j4');" onblur="checknummer('j4');">
			</i></font>
		</td>
		<td width="80" align="left"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('j3');wiskeus('j4');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="25" height="<?php echo $hoogte; ?>">&nbsp;</td>
		<td align="left" width="125"><font class="aatekst2"><i><?php echo $veldrnaam; ?>:</i></font></td>
		<td width="250">
			<div id="roptions">
			<select class="invulveld zoekinvul" id="aar" name="aar" onfocus="zetzoek('r');" onChange="zoekalloptions('r');"><option value=""></option>
				<?php
				echo selectstring($r,$a,$u,$m,$r,$s,$w,"r");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aar');zoekalloptions('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="25" height="<?php echo $hoogte; ?>">&nbsp;</td>
		<td align="left" width="125"><font class="aatekst2"><i><?php echo $veldwnaam; ?>:</i></font></td>
		<td width="250">
			<div id="woptions">
			<select class="invulveld zoekinvul" id="aaw" name="aaw" onfocus="zetzoek('w');" onChange="zoekalloptions('w');"><option value=""></option>
				<?php
				echo selectstring($w,$a,$u,$m,$r,$s,$w,"w");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aaw');zoekalloptions('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="25" height="<?php echo $hoogte; ?>">&nbsp;</td>
		<td align="left" width="125"><font class="aatekst2"><i><?php echo $veldmnaam; ?>:</i></font></td>
		<td width="250">
			<div id="moptions">
			<select class="invulveld zoekinvul" id="aam" name="aam" onfocus="zetzoek('m');" onChange="zoekalloptions('m');"><option value=""></option>
				<?php
				echo selectstring($m,$a,$u,$m,$r,$s,$w,"m");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aam');zoekalloptions('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="25" height="<?php echo $hoogte; ?>">&nbsp;</td>
		<td align="left" width="125"><font class="aatekst2"><i><?php echo $veldanaam; ?>:</i></font></td>
		<td width="250">
			<div id="aoptions">
			<select class="invulveld zoekinvul" id="aaa" name="aaa" onfocus="zetzoek('a');" onChange="zoekalloptions('a');"><option value=""></option>
				<?php
				echo selectstring($a,$a,$u,$m,$r,$s,$w,"a");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aaa');zoekalloptions('z');"></td>
	</tr></table>
		
	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">
			&nbsp;
		</td>
		<td align="left" width="130"><font class="aatekst2"><i><?php echo $veldunaam; ?>:</i></font></td>
		<td width="250">
			<div id="uoptions">
			<select class="invulveld zoekinvul" id="aau" name="aau" onfocus="zetzoek('u');" onChange="zoekalloptions('u');"><option value=""></option>
				<?php
				echo selectstring($u,$a,$u,$m,$r,$s,$w,"u");
				?>
			</select>
			</div>
		</td>
		<td width="20"><img title="wis deze selectie" class="handje" src="<?php echo $basis; ?>images/wis.png" onclick="wiskeus('aau');zoekalloptions('z');"></td>
	</tr></table>

	<table class="aac layoutfixed bgzoek dispinlineaa" width="420"><tr>
		<td width="20" height="<?php echo $hoogte; ?>">
			<?php if ($rechten=="mo" or $rechten=="sup"){ ?>
				<a class="info deconone"><button class="qbutton"><b>?</b></button>
				<span><font class="aatekst2"><b>Deze selectie heeft alleen effect indien ook andere zoekcriteria zijn ingegeven.<br>
				Combineer met zoekopdracht <b>*</b>  in <b>Vrij zoeken</b> om een volledige lijst van <b>Publiek</b>, <b>Leden</b> of <b>Prive</b> items te tonen.
				</font></span></a>
			<?php
			} ?>
		</td>
		<td width="250" align="left" class="geenwrap">
			<?php if ($rechten=="mo" or $rechten=="sup"){ ?>
				<table><tr><td>
					<font class="aatekst2"><i>Publiek</i></font>
				</td><td>
					<input onclick="togglep();zetzoek('vepv');" type="checkbox" name="vep" value="v" id="vepv" <?php if (substr($p,0,1)=="v"){echo " checked "; } ?>>
				</td><td>
					<font class="aatekst2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Leden</i></font>
				</td><td>
					<input onclick="togglep();zetzoek('vepe');" type="checkbox" name="vep" value="e" id="vepe" <?php if (substr($p,1,1)=="e"){echo " checked "; } ?>>
				</td><td>
					<font class="aatekst2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Prive</i></font>
				</td><td>
					<input onclick="togglep();zetzoek('vepp');" type="checkbox" name="vep" value="p" id="vepp" <?php if (substr($p,2,1)=="p"){echo " checked "; } ?>>
				</td></tr></table>
			<?php
			} ?>
		</td>
		<td width="150" align="right" class="geenwrap">
			<button class="aazoekbutton" onclick="wisuz('');">Wis&nbsp;alle&nbsp;invoer&nbsp;<img src="<?php echo $basis; ?>images/wis.png" height="16"></button>
		</td>
		<td width="20">&nbsp;</td>
	</tr></table>
	</td></tr></table>
	
	</div> <!--Einde UZblock DIV -->
	<!-- EINDE ZOEKBLOK -->
	<table class="aac" width="100%"><tr><td height="2"></td></tr></table>

	</div> <!-- Einde Zoekblok DIV -->
	<!-- ZOEKBLOK FORMEND-->

	<div class="wachtshow" align="center"><img src="<?php echo $basis; ?>images/wacht.gif"></div>
	<div class="emptyshow onzichtbaar"><img src="<?php echo $basis; ?>images/leeg.jpg"></div>
	<?php

	// ### MAIN BLOCK ###
	//Condities voor verdere verloop:
	//$fp_sQry gevuld: er is een zoekopdracht gemaakt
	//recordsExist=1: er zijn resultaten
	//$aantalrecords geeft het aantal records dat gevonden is
	//$vi is li of ga: Lijst of Gallerij weergave
	//logon is leeg: website bezoeker; ufa: lid die alles mag zien; mo: admin die mag editten
	//$googlewoord is true: het resultaat is gecorrigeerd met een phonetische Google search
	if (strlen($fp_sQry)>0){	// SELECTIE GEMAAKT
		if ($RecordsExist==0){	//Geen zoekresultaat
			?>
			<div align="center"><font class="tekst3"><br>Geen resultaat gevonden.<br><br></font></div>
			<?php
		}else{		//Wel zoekresultaat
			$navpos=1;
			if ($googlewoord){ ?>
				<div align="center">
				<font class="tekst3"><br>Geen resultaten gevonden voor: <b><i><?php echo $zorig; ?></i></b>. Resultaten getoond voor: <b><i><?php echo $z; ?></i></b>.</font><br>
				</div>
			<?php } ?>
			<br>
			
			<!-- Bovenste navigatie -->				
			<?php include 'bpdivnav.php'; ?>
			<div id="ruimte"><!-- Wel resultaat DIV -->
				<?php	 //RESULTAATBLOK -->
				if ($vi=="li"){  
					//LIJSTWEERGAVE
					$regelteller=0;
					while(true){
						$positieteller=($pagesize*($pg-1))+$regelteller+1;
						if ($regelteller>=$pagesize){break;}
						if($positieteller>$aantalrecords){break;}
						if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
						$Key=$fp_rs["Key"];
						$archiefnr=$fp_rs["archiefnr"];
						$dubbel=$fp_rs["dubbel"];$fout=$fp_rs["fout"];
						$errarchnr=false;
						if (strlen($dubbel)>0 or strlen($fout)>0 or $archiefnr=="999999"){$errarchnr=true;}
						$diffSeconds=$fp_rs["ts"];
						$opvoerdatum=date("d M Y",$diffSeconds);
						$ediffSeconds=$fp_rs["tse"];
						$wijzigdatum=date("d M Y",$ediffSeconds);
						$itemtitle=$fp_rs["itemtitle"];
						$persoon=$fp_rs["persoon"];
						$persoon2=$fp_rs["persoon2"];
						$soort1=$fp_rs["soort1"];
						if($soort1==""){$soort1=$soorten[0];}
						$bron1=$fp_rs["bron1"];$bron2=$fp_rs["bron2"];$bron3=$fp_rs["bron3"];
						$auteur1=$fp_rs["auteur1"];$auteur2=$fp_rs["auteur2"];$auteur3=$fp_rs["auteur3"];
						$veldr1=$fp_rs["veldr1"];$veldr2=$fp_rs["veldr2"];$veldr3=$fp_rs["veldr3"];$veldr4=$fp_rs["veldr4"];
						$jaar=$fp_rs["jaar"];
						$jaar2=$fp_rs["jaar2"];
						if($jaar=="X"){$jaar="";}
						if($jaar2=="X"){$jaar2="";}
						$maand="";$dag="";$maand2="";$dag2="";
						$leeftijd="";
						if (strlen($jaar.$jaar2)==0){
							$jaartekst="Onbekend";
						}else{ 
							if (strlen($jaar)>0){
								$jaarhulp=explode("-",$jaar);
								$jaar=$jaarhulp[0];
								if (count($jaarhulp)>1){$maand=$jaarhulp[1];}
								if (count($jaarhulp)>2){$dag=$jaarhulp[2];}
							}
							if (strlen($jaar2)>0){
								$jaarhulp=explode("-",$jaar2);
								$jaar2=$jaarhulp[0];
								if (count($jaarhulp)>1){$maand2=$jaarhulp[1];}
								if (count($jaarhulp)>2){$dag2=$jaarhulp[2];}
							}
							if($jaar<>""){
								$jaartekst=$jaar;
								if ($maand<>""){
									$jaartekst.="-".$maand;
									if ($dag<>""){$jaartekst.="-".$dag;}
								}
							}else{
								$jaartekst="?";
							}
							$jaartekst.=" / ";
							if($jaar2<>""){
								$jaartekst.=$jaar2;
								if ($maand2<>""){
									$jaartekst.="-".$maand2;
									if ($dag2<>""){$jaartekst.="-".$dag2;}
								}
							}else{
								$jaartekst.="?";
							}
							if($jaar!="" and $jaar2!="" and $maand!="" and $maand2!="" and $dag!="" and $dag2!=""){
								$dateTime1 = DateTime::createFromFormat('Ymd', $jaar.$maand.$dag);
								$dateTime2 = DateTime::createFromFormat('Ymd', $jaar2.$maand2.$dag2);
								$interval = $dateTime1->diff($dateTime2);
								$leeftijd = $interval->y;
							}
						}
						$beschrijving=$fp_rs["beschrijving"];
						if (strlen($beschrijving)>0){$beschrijving=str_replace(chr(13).chr(10),"<br>",$beschrijving);}
						$mapnr=$fp_rs["mapnr"];
						$straat=$fp_rs["straat"];
						$doel=$fp_rs["doel"];
						$fototitel=$itemtitle;
						if (strlen($bron1)>0){$fototitel=$fototitel."&nbsp;&#8226;&nbsp;Bron: ".$bron1;}
						if (strlen($auteur1)>0){$fototitel=$fototitel."&nbsp;&#8226;&nbsp;Auteur: ".$auteur1;}
						$fototitel=$fototitel."&nbsp;&#8226;&nbsp;Jaar: ".$jaartekst." &nbsp;&#8226;&nbsp;Arch.nr: ".$archiefnr;
//						$mapfprs=odbc_exec($defConnect,"SELECT mappen FROM mappen ORDER BY mappen ASC");
						?>
											
						<div style="display:hidden;margin:0px 50px;" id="recprev<?php echo $Key; ?>" align="center"></div>
						<div style="display:block;margin:0px <?php if($rechten=="mo" or $rechten=="sup"){echo "35";}else{echo "60";} ?>px;" id="rec<?php echo $Key; ?>" align="center">
						<table width="100%" cellpadding="0" cellspacing="0" class="bcollapse layoutfixed" style="user-select: text;">
						<tr>
							<td style="vertical-align: baseline;">
								<div id="ruimte<?php echo $Key; ?>">
								<?php
								$meerfotos=false;$hoogste=0;
								$fotofile=array_fill(0, 13, '');$isfoto=array_fill(0, 13, false);
								for ($i=1;$i<=12;$i++){
									$fotofile[$i]=$fp_rs["foto".strval($i)];
									if(strlen($fotofile[$i])>0){$isfoto[$i]=true;}
									if($isfoto[$i]){$hoogste=$i;}
								}
								$faantal=4;
								if ($hoogste>4){$faantal=8;}
								if ($hoogste>8 or $rechten=="mo" or $rechten=="sup"){$faantal=12;}
								for ($i=1;$i<=$faantal;$i++){
									$ocrfound=false;
									if($zid=="j"){
										$checkocr=odbc_exec($objConnect,"SELECT * FROM ".$tablename." WHERE kidx='".$fotofile[$i]."'");
										if($ocrresult=odbc_fetch_array($checkocr)){$ocrfound=true;}
										unset($checkocr);
									}
									$thumbfile=$fp_rs["thumb".strval($i)];
									$orgarch=$fp_rs["foto".strval($i)."arch"];
									$framestub="";$pdfviewer=false;$extensie="undefined";$ocred=false;
									if ($isfoto[$i]==true){
										$thumbspath=$thumbsmap."/".substr(strval($thumbfile),0,3)."/".$thumbfile."?".time()."orgarch".$orgarch;
										$extensie=substr($fotofile[$i],strpos($fotofile[$i],".")+1);
										$afbpath=$fotomap."/".substr(strval($fotofile[$i]),0,3)."/".$fotofile[$i]."?".time()."orgarch".$orgarch;
										if (strpos("jpg jpeg gif png webp",$extensie)===false){$framestub="iframe";}
										if(strpos("pdf",$extensie)!==false){$pdfviewer=true;}
									}else{
										$thumbspath=$basis."images/legefoto.gif";
										$afbpath=$basis."images/legefoto2.gif";
									}
									if (($rechten=="mo" or $rechten=="sup") and $i==9 and $hoogste<9){
										$meerfotos=true; ?>	<div class="meerfotos<?php echo $Key; ?>" style="display:none;">
									<?php }
									if (($rechten=="mo" or $rechten=="sup") or $isfoto[$i]){
									?>
									<TABLE width="188" class="layoutfixed dispinline"><TR> <!-- 1 foto -->
										<td height="3" width="2"></td>
										<td height="3" width="186" class="<?php if($ocrfound and $rechten!="mo" and $rechten!="sup"){ echo "fotobgocr";}else{ echo "fotobg";} ?>"></td>
										</tr><tr>
										<td width="2" height="<?php if ($rechten=="mo" or $rechten=="sup"){echo "225";}else{echo "188";} ?>"></td>
										<td width="186" class="vmidden <?php if($ocrfound and $rechten!="mo" and $rechten!="sup"){ echo "fotobgocr";}else{ echo "fotobg";} ?>">
										<div align="center">
										<?php
										if ($rechten=="mo" or $rechten=="sup"){ 
											$checkocr=odbc_exec($objConnect,"SELECT * FROM ocr WHERE kidx='".$fotofile[$i]."'");
											if($ocrchecked=odbc_fetch_array($checkocr)){$ocred=true;}
											unset($checkocr);
											?>
											<div class="uploadhide<?php echo $Key;echo $i; ?>">
												<div style="display:<?php if($errarchnr==true){echo "none";}else{echo "block";} ?>;" id="dragsrc<?php echo $i;echo $Key; ?>" class="uploadhide<?php echo $Key; ?>">
													<table border="0" class="bcollapse"><tr><td>
													<img src="<?php echo $basis; ?>images/sleep.png" title="Sleep het blauwe blokje om de foto te verplaatsen">
													</td><td>
													<div id="ocrdiv<?php echo $Key;echo $i; ?>" style="display:<?php if($ocr!=""){echo "block";}else{echo "none";} ?>">
														<?php
														if($ocr=="t"){$ocrextensies="pdf txt";}else{$ocrextensies="pdf jpg jpeg png gif txt webp";}
														if($ocred==false and strpos($ocrextensies,$extensie)!==false and $isfoto[$i]==true){?>
															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
															<input title="Start tekstherkenning (lees eerst de uitleg bij het ? onder de foto-sectie)" id="ocrknop<?php echo $Key;echo $i; ?>" type="button" class="edf" value="TXT" onclick="selframepos('framehook<?php echo $Key; ?>');ocradd('<?php echo $Key; ?>','<?php echo $i; ?>');">
														<?php
														}else{ ?>
															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
															<input disabled title="Tekstherkenning niet mogelijk, of al gedaan" id="ocrknop<?php echo $Key;echo $i; ?>" type="button" class="edf" value="---" onclick="">
														<?php	
														} ?>
													</div>
													</td></tr></table>
												</div> 
												<div id="dragdest<?php echo $i;echo $Key; ?>">
													<?php if($ios and $framestub=="iframe" and $pdfviewer==false){ ?>
														<a id="fb<?php echo $Key;echo $i; ?>" href="<?php echo $afbpath; ?>" target="_blank">
													<?php
													}else if($pdfviewer==true){ ?>
														<a id="fb<?php echo $Key;echo $i; ?>"  data-type="<?php echo $framestub; ?>" data-fancybox="<?php echo $Key; ?>" class="fancybox-open-tk" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $afbpath; ?>&search=<?php if($zid=="j"){echo $zoekwoord1;} ?>&zoom=page-fit" data-caption="<?php echo $fototitel; ?>" title="">
													<?php
													} else { ?>
														<a class="fancybox-open-tk" id="fb<?php echo $Key;echo $i; ?>" data-type="<?php echo $framestub; ?>" data-fancybox="<?php echo $Key; ?>" href="<?php echo $afbpath; ?>" data-caption="<?php echo $fototitel; ?>" title="">
													<?php
													} ?>
													<img border="0" id="fotoa<?php echo $i;echo $Key; ?>" src="<?php echo $thumbspath; ?>">
													</a>
												</div>
											<img style="display:none" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" onload="$('#dragsrc<?php echo $i;echo $Key; ?>').draggable({containment:'#ruimte',zIndex:3000,snap:false,snapTolerance:100,revert:true,revertDuration:0,start:function(){initwissel(<?php echo $i; ?>,<?php echo $Key; ?>)},stop:function(){execwissel()}});$('#dragdest<?php echo $i;echo $Key; ?>').droppable({over:function(ev,ui){wisseldestsleutel='<?php echo $Key; ?>';wisseldestnr='<?php echo $i; ?>';}});">
											</div>
											<div class="onzichtbaar uploadshow<?php echo $Key;echo $i; ?>">
												<img alt="" border="0" src="<?php echo $basis; ?>images/wacht.gif">
											</div>
										<?php
										}else{ ?>
											<?php
											if($ios and $framestub=="iframe" and $pdfviewer==false){ ?>
												<a id="fb<?php echo $Key;echo $i; ?>" href="<?php echo $afbpath; ?>" target="_blank">
											<?php
											}else if($pdfviewer==true){ ?>
												<a id="fb<?php echo $Key;echo $i; ?>" data-type="<?php echo $framestub; ?>" data-fancybox="blader" class="fancybox-open-tk" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $afbpath; ?>&search=<?php if($zid=="j"){echo $zoekwoord1;} ?>&zoom=page-fit<?php if ($pft){echo '&pft=j';} ?>" data-caption="<?php echo $fototitel; ?>" title="">
											<?php
											}else{ ?>
												<a id="fb<?php echo $Key;echo $i; ?>" data-type="<?php echo $framestub; ?>" class="fancybox-open-tk" data-fancybox="blader" href="<?php echo $afbpath; ?>" data-caption="<?php echo $fototitel; ?>" title="">
											<?php
											} ?>
											<img <?php if($rechten=="" and $pft){ ?>onclick="pft();"<?php } ?> border="0" id="fotoa<?php echo $i;echo $Key; ?>" src="<?php echo $thumbspath; ?>">
											</a>
										<?php
										}
										if ($rechten=="mo" or $rechten=="sup"){ ?>
											<div id="updel<?php echo $Key;echo $i; ?>" style="display:<?php if($errarchnr==true){echo "none";}else{echo "block";} ?>;" class="uploadhide<?php echo $Key; ?>">
											<form name="addfoto<?php echo $Key; ?>f<?php echo $i; ?>" action="<?php echo $basis; ?>bpful.php?sleutel=<?php echo $Key; ?>&nummer=<?php echo $i; ?>&t=<?php echo time(); ?>" target="fou<?php echo $i; ?>" method="POST" enctype="multipart/form-data">
												<?php if($ios){ ?>
													<input style="font-size:0px;color:#eeeeee;" type="file" class="edf uploadknop<?php echo $Key; ?>" id="fotoc<?php echo $i;echo $Key; ?>" name="orgfilename" size="1" onfocus="selframepos('framehook<?php echo $Key; ?>');" OnChange="wijzigfoto('<?php echo $i; ?>','<?php echo $Key; ?>');"/>
												<?php	
												}else{ ?>
												<label class="edf fileContainer">
													&nbsp;Upload&nbsp;<input type="file" class="uploadknop<?php echo $Key; ?>" id="fotoc<?php echo $i;echo $Key; ?>" name="orgfilename" size="1" onfocus="selframepos('framehook<?php echo $Key; ?>');" OnChange="wijzigfoto('<?php echo $i; ?>','<?php echo $Key; ?>');"/>
												</label>
												<?php
												} ?>
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												<input title="Verwijder dit item" id="fotodel<?php echo $Key; ?><?php echo $i; ?>" type="button" class="edf" value="del" OnClick="selframepos('framehook<?php echo $Key; ?>');verwijderfoto('<?php echo $i; ?>','<?php echo $Key; ?>');">
											</form>
											</div>
											<?php
										} ?>
										</div>
										</td>
										</tr><tr>
										<td height="2" width="2"></td>
										<td height="2" width="186"></td>
									</TR></TABLE> <!-- Einde 1 foto-->								
									<?php
									}
									if (($rechten=="mo" or $rechten=="sup") and $i==12){ ?>
										</div>
										<div align="right">
										<table class="bcollapse" border="0"><tr><td>
										<a class="linfo deconone"><button class="qbutton"><b>?</b></button>
										<span><font class="aatekst2">
										Ondersteunde formaten voor de upload zijn: jpg, jpeg, gif, png, webp, xls, xlsx, doc, docx, ppt, pptx, txt, rtf.<br><br>
										<b>Foto's slepen</b><br>
										Foto's kunnen worden verplaatst door het <img src=<?php echo $basis; ?>images/sleep.png> sleepblokje met de muis naar
										de nieuwe positie te  verplaatsen. Staat daar al een foto dan worden de beide foto's van plaats verwisseld. Foto's kunnen
										op deze manier ook naar een ander record worden verplaatst. Het oorspronkelijke archiefnummer wordt bewaard in de database.<br><br>
										Foto's kunnen pas worden toegevoegd nadat een geldig archiefnummer is ingevuld.<br><br>
										<?php if($ocr){ ?>
										<b>Tekstherkenning (OCR)</b><br>
										Met <input type=button value=TXT> wordt het document in een wachtrij geplaatst voor tekstherkenning. De knop wijzigt
										dan in <input type=button value="TXT bezig">. Zodra dit klaar is wijzigt de knop in <input type=button value="---"> (verversing
										van het scherm is nodig om dit te kunnen zien) en is de gevonden tekst ook doorzoekbaar.<br>N.B.: Tekstherkenning kan alleen
										ongedaan worden gemaakt door het oorspronkelijke document opnieuw te uploaden.<br><br>
										<b><i>Selectief gebruik van tekstherkenning</i></b><br>
										Van niet alle documenten is het zinvol om de tekst ervan doorzoekbaar te maken. Doe dit niet voor handgeschreven tekst
										of foto's. Beperk u tot getypte documenten waar informatie in staat die niet via de titel of de omschrijving gevonden kan worden.
										<?php } ?>
										<?php if($meerfotos){ ?>
											<p style="display:block" class="meerfotosbutton<?php echo $Key; ?>">
											<b>Extra foto's</b><br>
											Heeft u meer dan 8 foto's voor dit record? Klik dan op <button class=ggbutton>Meer foto's</button>. Er kunnen maximaal 12 foto's worden toegevoegd.
											</p>
										<?php } ?>
										</font></span></a>&nbsp;
										<?php if($meerfotos){ ?>
											</td><td>
											<button style="display:block;" class="meerfotosbutton<?php echo $Key; ?> ggbutton" onclick="$('.meerfotos<?php echo $Key; ?>').show();$('.meerfotosbutton<?php echo $Key; ?>').hide();">Meer foto's</button>
											</td><td>&nbsp;
										<?php } ?>
										</td></tr></table>
										</div>
									<?php
									}
								} ?>
								</div>
							</td>
							
							<td rowspan="2" width="<?php if ($rechten=="mo" or $rechten=="sup"){echo "230";}else{echo "180";} ?>" class="bgzoek" style="vertical-align:top;">
								<table style="padding:4px"><tr>
								<td>
									<?php
									if ($rechten=="mo" or $rechten=="sup"){ ?>
										&nbsp;
										<input type="button" value="copy" class="edf" title="Kopieer dit object" onclick="if (event.ctrlKey) {ctrltoets=true;};copyornew('bpadmin.php?aktie=copyrec&Key=<?php echo $Key; ?>');">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<input type="button" class="edf" value="del" title="Verwijder dit object" onclick="verwijderrecord('<?php echo $Key; ?>');">
									<?php
									} ?>
								</td>
								<td align="right">
									<?php if ($rechten=="mo" or $rechten=="sup"){ ?>
										<a class="einfo deconone"><button class="ggbutton"><b>?</b></button>&nbsp;&nbsp;&nbsp;
										<span><font class="aatekst2">
										<b>Algemeen:</b><br>
										<img src=<?php echo $basis; ?>images/red.png> geeft aan dat een wijziging in een veld nog niet is opgeslagen. Zodra men buiten het veld klikt wordt de wijziging opgeslagen.<br>
										Toegestane karakters in de velden zijn:&nbsp;&nbsp;<b>spatie a-z  A-Z 0-9 ! ? + -=. , / ( )</b><br>
										Overige karakters worden gefilterd bij het opslaan.<br>
										In het beschrijvingsveld (onder het titelveld) zijn alle karakters toegestaan.<br><br>
										
										<input type=button value=copy> kopieert alle velden behalve de foto's en het archiefnummer en maakt daarmee een nieuw object aan.<br>
										Nieuwe objecten krijgen standaard de titel <b>NIEUWOBJECT</b>, archiefnummer <b>999999</b> en status <b>Leden</b> (zie <b>Publiek/Leden/Prive</b> veld).<br><br>
										<input type=button value=del> verwijdert het gehele object. Uit veiligheidsoverwegingen kunnen alleen objecten zonder foto's of documenten worden verwijderd.<br><br>
										<b>Publiek/Leden/Prive</b> <input type=radio checked>: zichtbaarheid van item: <b>Publiek</b>=iedereen, <b>Leden</b>=ingelogde leden en editors/admin, <b>Prive</b>=alleen editors/admin.<br><br>
										<img src="images/fout.gif"> bij een archiefnummer geeft aan dat dit nummer dubbel is gebruikt, niet uit 6 cijfers bestaat of nog op 999999 staat. Corrigeer dit z.s.m.<br>
										</font></span></a>
										<a id="framehook<?php echo $Key; ?>" name="<?php echo $Key; ?>"></a>
									<?php } ?>
								</td>
								</tr><tr><td align="left" colspan="2">
								
								<?php
								if ($rechten=="mo" or $rechten=="sup"){
									//admin
									?>
									<table class="bcollapse"><tr><td height="3"></td></tr><tr>
									<td>
										<a class="linkKaderaa tekst2 handje" id="linkarchiefnr<?php echo $Key; ?>" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&archiefnr=<?php echo $archiefnr; ?>&vi=li&uz=j&topshift')">Archiefnr:</a>&nbsp;
										<?php if ($bidnum=="H"){ ?>
											<input type="text" class="edf" style="width:50px;" name="archiefnr<?php echo $Key; ?>" id="archiefnr<?php echo $Key; ?>" value="<?php echo chrkode($archiefnr); ?>" onfocus="selfocus('archiefnr','<?php echo $Key; ?>');" onblur="archiefnummer('<?php echo $Key; ?>');veldupdate('<?php echo $Key; ?>','archiefnr',0);relfocus();" maxlength="6">
										<?php
										}else{ ?>
											<input type="hidden" name="archiefnr<?php echo $Key; ?>" id="archiefnr<?php echo $Key; ?>" value="<?php echo chrkode($archiefnr); ?>">
											<?php echo chrkode($archiefnr);
										} ?>									
									</td>
									<td>
										<div id="fout<?php echo $Key; ?>" name="fout<?php echo $Key; ?>" style="display: <?php if ($errarchnr==true){ ?>block<?php }else{ ?>none<?php } ?>;"><img src="<?php echo $basis; ?>images/fout.gif" title="Dubbel of incorrect arhiefnummer!"></div>
									</td>
									<td>
										<font class="tekst2">
										&nbsp;&nbsp;
										<input type="radio" class="edf" name="doel<?php echo $Key; ?>" id="doel<?php echo $Key; ?>" <?php if ($doel=="v"){ ?>checked<?php } ?> value="<?php echo $doel; ?>" onchange="selfocus('doel','<?php echo $Key; ?>');toggledoel('<?php echo $Key; ?>');relfocus();veldupdate('<?php echo $Key; ?>','doel',0);">Publiek<br>
										&nbsp;&nbsp;
										<input type="radio" class="edf" name="doel<?php echo $Key; ?>" id="doel<?php echo $Key; ?>" <?php if ($doel=="e"){ ?>checked<?php } ?> value="<?php echo $doel; ?>" onchange="selfocus('doel','<?php echo $Key; ?>');toggledoel('<?php echo $Key; ?>');relfocus();veldupdate('<?php echo $Key; ?>','doel',0);">Leden<br>
										&nbsp;&nbsp;
										<input type="radio" class="edf" name="doel<?php echo $Key; ?>" id="doel<?php echo $Key; ?>" <?php if ($doel=="p"){ ?>checked<?php } ?> value="<?php echo $doel; ?>" onchange="selfocus('doel','<?php echo $Key; ?>');toggledoel('<?php echo $Key; ?>');relfocus();veldupdate('<?php echo $Key; ?>','doel',0);">Prive<br>
										</font>
									</td>
									</tr></table>

									<table class="bcollapse"><tr><td height="3"></td></tr><tr><td colspan="2">
										Geboren:
									</td><td colspan="2">
										Overleden:
									</td></tr><tr><td>
										<font class="tekst2">Jaar&nbsp;</font>
									</td><td>
										<input type="text" class="edf" style="width:35px;" name="jaar<?php echo $Key; ?>" id="jaar<?php echo $Key; ?>" value="<?php echo chrkode($jaar); ?>" onfocus="selfocus('jaar','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar',0);" maxlength="4">
										&nbsp;
									</td><td>
										<font class="tekst2">Jaar
									</td><td>
										<input type="text" class="edf" style="width:35px;" name="jaar2<?php echo $Key; ?>" id="jaar2<?php echo $Key; ?>" value="<?php echo chrkode($jaar2); ?>" onfocus="selfocus('jaar2','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar2',0);" maxlength="4">
										&nbsp;</font>
										<a class="dinfo deconone"><button class="qbutton"><b>?</b></button>
										<span><font class="aatekst2">
										<b>Archiefnummer</b>
										<ul>
										<li>Dient uit 6 cijfers te bestaan</li>
										<li>Moet tussen 100000 en 999999 liggen</li>
										<li>Moet uniek zijn</li></ul><br>
										<b>Datering:</b>
										<ul>
										<li><b>Geboortejaar Overlijdensjaar:</b> 4-cijferig jaartal, optioneel verfijnd in de <b>Maand</b> en <b>Dag</b> velden.<br>
										Laat men beide jaren leeg dan wordt het op de website aangeduid als <b>Onbekend</b>.</li>
										</ul>
										</font></span></a>
									</td></tr><tr><td>
										<font class="tekst2">Maand&nbsp;</font>
									</td><td>
										<input type="text" class="edf" style="width:25px;" name="maand<?php echo $Key; ?>" id="maand<?php echo $Key; ?>" value="<?php echo chrkode($maand); ?>" onfocus="selfocus('maand','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar',0);" maxlength="2">&nbsp;
									</td><td>
										<font class="tekst2">Maand&nbsp;</font>
									</td><td>
										<input type="text" class="edf" style="width:25px;" name="maand2<?php echo $Key; ?>" id="maand2<?php echo $Key; ?>" value="<?php echo chrkode($maand2); ?>" onfocus="selfocus('maand2','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar2',0);" maxlength="2">&nbsp;
									</td></tr><tr><td>
										<font class="tekst2">Dag&nbsp;</font>
									</td><td>
										<input type="text" class="edf" style="width:25px;" name="dag<?php echo $Key; ?>" id="dag<?php echo $Key; ?>" value="<?php echo chrkode($dag); ?>" onfocus="selfocus('dag','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar',0);" maxlength="2">
									</td><td>
										<font class="tekst2">Dag&nbsp;</font>
									</td><td>
										<input type="text" class="edf" style="width:25px;" name="dag2<?php echo $Key; ?>" id="dag2<?php echo $Key; ?>" value="<?php echo chrkode($dag2); ?>" onfocus="selfocus('dag2','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','jaar2',0);" maxlength="2">
									</td></tr></table>
									
									<table class="bcollapse"><tr><td height="3">
									</td></tr><tr><td>
										<font class="tekst2"><?php echo $veldrnaam; ?>:&nbsp</font>
										<a class="oinfo deconone"><button class="qbutton"><b>?</b></button>
										<span><font class="aatekst2">
										Kies bij onderstaande invulvelden bij voorkeur uit de bestaande lijst.<br>
										Bij ingave van een paar letters zal automatisch een lijst met suggesties uit de bestaande keuzes worden getoond.<br><br>
										Een lijst van alle bestaande keuzes kan worden getoond door op de 'down' toets te drukken in een <b>leeg veld</b>.<br><br>
										</font></span></a>
										<input type="text" maxsize="100" class="onderwerp edf editlijst" name="veldr1<?php echo $Key; ?>" id="veldr1<?php echo $Key; ?>" value="<?php echo chrkode($veldr1); ?>" onfocus="selfocus('veldr1','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','veldr1',1);"><br>
									</td></tr><tr><td>
										<font class="tekst2"><?php echo $veldwnaam; ?>:&nbsp;</font>
										<input type="text" maxsize="100" class="straat edf editlijst" name="straat<?php echo $Key; ?>" id="straat<?php echo $Key; ?>" value="<?php echo chrkode($straat); ?>" onfocus="selfocus('straat','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','straat',1);">
									</td></tr><tr><td>
										<font class="tekst2"><?php echo $veldmnaam; ?>:&nbsp;</font>
										<input type="text" maxsize="100" class="persoon edf editlijst" name="persoon<?php echo $Key; ?>" id="persoon<?php echo $Key; ?>" value="<?php echo chrkode($persoon); ?>" onfocus="selfocus('persoon','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','persoon',1);"><br>
										<input type="text" maxsize="100" class="persoon edf editlijst" name="persoon2<?php echo $Key; ?>" id="persoon2<?php echo $Key; ?>" value="<?php echo chrkode($persoon2); ?>" onfocus="selfocus('persoon2','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','persoon2',1);">
									</td></tr><tr><td>
										<font class="tekst2"><?php echo $veldunaam; ?>:&nbsp;</font>
										<input type="text" maxsize="100" class="bron edf editlijst" name="bron1<?php echo $Key; ?>" id="bron1<?php echo $Key; ?>" value="<?php echo chrkode($bron1); ?>" onfocus="selfocus('bron1','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','bron1',1);"><br>
									</td></tr><tr><td>
										<font class="tekst2"><?php echo $veldanaam; ?>:</font>&nbsp;
										<input type="text" maxsize="100" class="auteur edf editlijst" name="auteur1<?php echo $Key; ?>" id="auteur1<?php echo $Key; ?>" value="<?php echo chrkode($auteur1); ?>" onfocus="selfocus('auteur1','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','auteur1',1);"><br>
									</td></tr><tr><td>
										<font class="tekst2">Soort:
										<select class="edf selectlijstlang" name="soort1<?php echo $Key; ?>" id="soort1<?php echo $Key; ?>" onfocus="selfocus('soort1','<?php echo $Key; ?>');" onblur="relfocus();veldupdate('<?php echo $Key; ?>','soort1',0);">
											<?php
											for ($si=1;$si<=4;$si++){
												if ($soort1==$soorten[$si]){$setoptionselected="selected";}else{$setoptionselected="";} ?>
												<option <?php echo $setoptionselected; ?> value="<?php echo $soorten[$si]; ?>"><?php echo $soorten[$si]; ?></option>
												<?php
											} ?>
										</select>
									</td></tr></table>
									<br>

									<table class="bcollapse"><tr><td height="2"></td></tr><tr><td>
										&nbsp;<input class="edf" type="button" value="preview" id="wisselpreview<?php echo $Key; ?>" onclick="preview('<?php echo $Key; ?>');" title="Wissel tussen editor en preview">&nbsp;
									</td><td align="left">
										<div id="wisseleditor<?php echo $Key; ?>">
										<input class="edf" type="button" value="html" onclick="onderwater('<?php echo $Key; ?>');" id="owknop<?php echo $Key; ?>" title="Wissel tussen tekst- en HTML editor">&nbsp;
										<input id="cleanknop<?php echo $Key; ?>" class="edf" type="button" value="clean" onclick="selfocus('beschrijving','<?php echo $Key; ?>');opschonen('<?php echo $Key; ?>');relfocus();" title="Verwijder opmaak en verborgen codering uit de omschrijving">
										&nbsp;
										<a class="linfo deconone"><button class="qbutton"><b>?</b></button>
										<span><font class="aatekst2">
										<input type=button value=preview> toont de titel en beschrijving zoals deze er voor de bezoekers uit ziet inclusief de opmaak.<br>
										<input type=button value=html> wisselt tussen de tekst-editor en de HTML-editor.<br>
										<input type=button value=clean> verwijdert alle opmaak, inclusief HTML code, uit de beschrijving.<br><br>
										Het 6-cijferige Database-Indexnr #xxxxxx wordt automatisch gegenereerd bij het maken van een nieuw object en staat los van het archiefnummer.
										</font></span></a>
										</div>
									</td></tr></table>
									<?php
										$toevoeger=$fp_rs["toevoeger"];$toevoeger=explode("@",$toevoeger)[0];
										if($toevoeger!=""){$toevoeger=" (".$toevoeger.")";}
										$aanpasser=$fp_rs["aanpasser"];$aanpasser=explode("@",$aanpasser)[0];
										if($aanpasser!=""){$aanpasser=" (".$aanpasser.")";}
									?>								
									<br>
									<table width="100%" border="0" class="bcollapse"><tr><td class="geenwrap">
										<font class="tekst1">
										<i>Database-indexnr:</i>&nbsp;#<?php echo markeerzoekwoorden($Key,0); ?><br>
										<i>Toegevoegd</i>&nbsp;<?php echo $opvoerdatum.$toevoeger; ?><br>
										<?php if($ediffSeconds<>$diffSeconds and $ediffSeconds>0){ ?>
											<i>Aangepast</i>&nbsp;<?php echo $wijzigdatum.$aanpasser; ?>
										<?php }
										?>
										</font>
									</td></tr><tr><td align="right">
										
									</td></tr></table>
									
									<input type="hidden" id="togglestat<?php echo $Key; ?>" name="togglestat<?php echo $Key; ?>" value="">
									<input type="hidden" id="previewstat<?php echo $Key; ?>" name="previewstat<?php echo $Key; ?>" value="uit">
									<?php
								}else{
									//geen editor
									?>
									<font class="aatekst2">
									<?php if($jaartekst!=""){ ?>
										<i>Geboren-overleden:&nbsp;</i><br><?php echo $jaartekst; ?>
									<?php
									}
									if($leeftijd!=""){ ?>
										<br><i>Leeftijd:&nbsp;</i><br><?php echo $leeftijd."&nbsp;jaar"; ?>
									<?php
									}
									
									if ($veldr1.$veldr2.$veldr3.$veldr4<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldrnaam; ?>:</i><?php }
									if ($veldr1<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&r=<?php echo $veldr1; ?>&vi=<?php echo $vi; ?>&uz=<?php echo $uz; ?>&topshift')"><?php echo markeerzoekwoorden($veldr1,0); ?></a><?php }
									
									if ($straat<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldwnaam; ?>: </i> <?php }
									if ($straat<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&w=<?php echo $straat; ?>&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>&topshift')"><?php echo markeerzoekwoorden($straat,0); ?></a><?php }
									
									if ($persoon.$persoon2<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldmnaam; ?>: </i> <?php }
									if ($persoon<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&m=<?php echo $persoon; ?>&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>&topshift')"><?php echo markeerzoekwoorden($persoon,0); ?></a><?php }
									if ($persoon2<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&m=<?php echo $persoon2; ?>&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>&topshift')"><?php echo markeerzoekwoorden($persoon2,0); ?></a><?php }

									if ($bron1.$bron2.$bron3<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldunaam; ?>:</i><?php }
									if ($bron1<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&u=<?php echo $bron1; ?>&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>&topshift')"><?php echo markeerzoekwoorden($bron1,0); ?></a><?php }
									
									if ($auteur1.$auteur2.$auteur3<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldanaam; ?>:</i><?php }
									if ($auteur1<>""){ ?><br><a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&a=<?php echo $auteur1; ?>&uz=<?php echo $uz; ?>&vi=<?php echo $vi; ?>&topshift')"><?php echo markeerzoekwoorden($auteur1,0); ?></a><?php }
									
									if ($soort1<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i>Soort:<br></i><?php echo markeerzoekwoorden($soort1,0); ?><?php } ?>
									
									<br><br><i>Archiefgegevens:</i>
									<font class="tekst2"><br>Archiefnr&nbsp;<font class="tekst2">
									<a class="linkKaderaa handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&archiefnr=<?php echo $archiefnr; ?>&uz=j&vi=li&topshift')"><?php echo markeerzoekwoorden($archiefnr,0); ?></a></font>
									
									<br><font class="tekst2">Toegevoegd&nbsp;op&nbsp;<?php echo $opvoerdatum; ?><br>
									<table style="padding:4px;" class="layoutfixed" width="100%"><tr><td width="105">
									<div id="meldstart<?php echo $Key; ?>" style="display:block;">
										<button class="ggbutton" onclick="$('#meldresultaat<?php echo $Key; ?>').hide();$('#meldform<?php echo $Key; ?>').show();$('#meldstart<?php echo $Key; ?>').hide();">Meld&nbsp;aanvulling</button>
									</div>
									</td><td>
									</td></tr></table>
									<?php
								} ?>
								</td></tr></table>
							</td>

						</tr><tr>	

							<td class="vtop" style="padding:3px;">
								<?php
								if ($rechten<>"mo" and $rechten<>"sup"){
									//geen editor
									?>
									<font class="itemtitle"><?php echo markeerzoekwoorden($itemtitle,1); ?></font>
									<font class="aatekst2"><br>
									<?php
									if (strlen($beschrijving)>0){
										while(strpos($beschrijving,"[[")!==false and strpos($beschrijving,"]]")!==false){
												$hulptekst=explode("[[",$beschrijving)[1];$anummer=explode("]]",$hulptekst)[0];
												if(strlen($anummer)==6 and strval($anummer)>=100000 and strval($anummer)<999999){
													$beschrijving=str_replace_first('[[','<u><a class=handje onclick="if (event.ctrlKey){ctrltoets=true;};getcontainer(xqx?av=bp&archiefnr='.$anummer.'&vi=li&topshiftxqx);">',$beschrijving);
												}else{
													$beschrijving=str_replace_first('[[','<u><a href="'.$anummer.'">',$beschrijving);
												}
												$beschrijving=str_replace_first(']]','</a></u>',$beschrijving);
										}
										$beschrijving=str_replace("xqx",chr(39),$beschrijving);
										echo markeerzoekwoorden(chrkode($beschrijving),0);
									} ?>
									</font>
								<?php	
								}else{
									//editor
									?>
									<div style="display:block" id="toggletitle<?php echo $Key; ?>">
										<font class="tekst2">Titel:<br></font>
										<textarea maxlength="185" style="width:80%;height:35px" class="edf" name="itemtitle<?php echo $Key; ?>" id="itemtitle<?php echo $Key; ?>" onfocus="selfocus('itemtitle','<?php echo $Key; ?>');" onblur="relfocus(); veldupdate( '<?php echo $Key; ?>' , 'itemtitle' , 1);"><?php echo chrkode($itemtitle); ?></textarea>
										<a class="linfo deconone"><button style="vertical-align:top;" class="qbutton"><b>?</b></button>
										<span><font class="aatekst2">
										Het titelveld bevat voor bidprentjes de volledige naam, inclusief doopnamen. Het titelveld is maximaal 185 karakters lang.<br><br>
										In het omschrijvingsveld kan uitgebreidere informatie worden opgenomen. Maximum 50.000 karakters.<br><br>
										Hou er rekening mee dat bezoekers in de galerij weergave de colofon niet zien en ook de beschrijving niet (tenzij men men de muis over het item beweegt) en daarom met alleen de informatie in het titelveld het item goed moeten kunnen interpreteren.<br><br>
										Ben voorzichtig met het direct kopieren vanuit andere bronnen naar het omschrijvingsveld. Er kan verborgen code in zitten, welke is te zien in de HTML editor (<input type=button value=html>)<br><br>
										Hyperlinks naar andere archiefnummers kunnen worden opgenomen in de omschrijving door het doelnummer tussen dubbele vierkante haken te plaatsen, b.v.:<br><b>Zie ook archief nr. [[124662]]</b>.<br>
										Ook links naar externe websites kunnen op deze wijze worden opgenomen, b.v.:<br><b>Onze eigen website is [[https://www.onzeeigenwebsite.nl]]</b>.
										</font></span></a>
										<br>
									</div>
									
									<div style="display:block" id="togglejqte<?php echo $Key; ?>">
										<table border="0" cellpadding="0" cellspacing="0" class="bcollapse"><tr>
										<td>
											<form name="addfoto<?php echo $Key; ?>f0" action="<?php echo $basis; ?>aaful.php?sleutel=<?php echo $Key; ?>&nummer=0&t=<?php echo time(); ?>" target="fou1" method="POST" enctype="multipart/form-data">
											<?php if($ios){ ?>
												<input accept="text/plain" style="font-size:0px;color:#eeeeee;" type="file" class="edf uploadknop<?php echo $Key; ?>" id="fotoc0<?php echo $Key; ?>" name="orgfilename" size="1" onfocus="selframepos('framehook<?php echo $Key; ?>');" OnChange="wijzigfoto('<?php echo $i; ?>','<?php echo $Key; ?>');"/>
											<?php	
											}else{ ?>
											<label class="edf fileContainer">
												&nbsp;Upload&nbsp;<input accept="text/plain" type="file" class="uploadknop<?php echo $Key; ?>" id="fotoc0<?php echo $Key; ?>" name="orgfilename" size="1" onfocus="selframepos('framehook<?php echo $Key; ?>');" OnChange="wijzigfoto('0','<?php echo $Key; ?>');"/>
											</label>
											<?php
											} ?>
											</form>
										</td>
										<td width="35" align="left">
											<a class="info deconone"><button style="vertical-align:top;" class="qbutton"><b>?</b></button>
											<span><font class="aatekst2">Voeg tekst uit een .TXT bestand toe aan de omschrijving met de upload knop of schrijf zelf tekst in het tekstveld hieronder</font></span></a>
										</td>
										<td align="left">
											<font class="tekst2">Omschrijving:</font>
										</td>
										</tr></table>
										<textarea sleutel="<?php echo $Key; ?>" id="beschrijving<?php echo $Key; ?>" name="beschrijving<?php echo $Key; ?>" onchange="relfocus();veldupdateraw('<?php echo $Key; ?>');"><?php if (strlen($beschrijving)>0){echo chrkode($beschrijving);} ?></textarea>
									</div>
									<img style="display:none;" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" onload="$('#beschrijving<?php echo $Key; ?>').jqte({rule:false,outdent:false,left:false,right:false,indent:false,fsize:false,center:false,format:false,strike:false,source:false,p:false,color:false,remove:false,strike:false,link:false,unlink:false,focus:function(){selfocus('beschrijving','<?php echo $Key; ?>');},blur:function(){relfocus();veldupdate(<?php echo $Key; ?>,'beschrijving',1);}});">
									<div style="display:none;" id="toggleraw<?php echo $Key; ?>">
										<font class="tekst2">Omschrijving:<br></font>
										<textarea style="width:99%;" id="beschrijvingraw<?php echo $Key; ?>" name="beschrijvingraw<?php echo $Key; ?>" onfocus="selfocus('beschrijvingraw','<?php echo $Key; ?>');" onblur="relfocus();veldupdateraw('<?php echo $Key; ?>');" rows="10">
											&nbsp;
										</textarea>
									</div>
									<?php
								} ?>						
							</td>

						</tr><tr>
						
							<td style="padding-left:4px;padding-right:4px;padding:bottom:6px;">
								<div id="meldform<?php echo $Key; ?>" style="display:none;">
								<hr style="padding:0px;">
								<table><tr>
								<td>
									<i>Heeft u extra informatie, dan kunt u dat<br>hier aan ons doorgeven. Alvast dank!</i><br>
									Uw naam:<br><input maxlength="100" type="text" id="uwnaam<?php echo $Key; ?>"><br>
									Uw email adres:<br><input  maxlength="100" type="text" id="uwemail<?php echo $Key; ?>"><br>
									Uw aanvulling:<br>
								</td><td>
									<button class="ggbutton" onclick="$('#meldform<?php echo $Key; ?>').hide();$('#meldstart<?php echo $Key; ?>').show();">Sluit</button><br><br>
									<button class="ggbutton" onclick="sct(<?php echo $Key; ?>,'<?php echo $itemtitle; ?>','<?php echo $archiefnr; ?>');">Verstuur</button>
								</td></tr><tr><td colspan="2">
									<textarea style="width:400px;height:120px;" id="uwtip<?php echo $Key; ?>"></textarea>
								</td>
								</tr></table>
								</div>
								<div id="meldresultaat<?php echo $Key; ?>" style="display:none;">
								</div>
							</td>
							<td class="bgzoek">
							</td>

						</tr><tr>

							<td colspan="2" height="15"  style="background-image: url('<?php echo $basis; ?>images/lijn.png');"></td>

						</tr></table>
						</div>
						<?php
						 $regelteller=$regelteller+1;
					}	//next record
					//EINDE LIJSTWEERGAVE
				}else{ 
					//GALLERIJWEERGAVE
					$afbpathG=array_fill(0, 12, '');
					$thumbspathG=array_fill(0, 12, '');
					$framestubG=array_fill(0, 12, '');
					$pdfviewerG=array_fill(0, 12, '');
					$ocrfoundG=array_fill(0, 12, false);
					$regelteller=0; ?>

					<div style="margin:0px <?php echo $maxmarg; ?>px;">
					<table class="bcollapse" width="100%"><tr>
					<td class="vtop">
					
					<?php
					while(true){
						$positieteller=($pagesize*($pg-1))+$regelteller+1;
						if ($regelteller >= $pagesize){break;}
						if($positieteller>$aantalrecords){break;}
						if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
						$Key=$fp_rs["Key"];
						$itemtitle=$fp_rs["itemtitle"];
						$auteur1=$fp_rs["auteur1"];
						$archiefnr=$fp_rs["archiefnr"];
						$bron1=$fp_rs["bron1"];
						$soort1=$fp_rs["soort1"];
						$jaar=$fp_rs["jaar"];
						$jaar2=$fp_rs["jaar2"];
						if($jaar=="X"){$jaar="";}
						if($jaar2=="X"){$jaar2="";}
						if (strlen($jaar.$jaar2)==0){
							$jaartekst="Onbekend";
						}else{
							if (strlen($jaar)>0){
								$jaarhulp=explode("-",$jaar);
								$jaartekst=$jaarhulp[0];
							}else{
								$jaartekst="?";
							}
							$jaartekst=$jaartekst."-";
							if (strlen($jaar2)>0){
								$jaarhulp=explode("-",$jaar2);
								$jaartekst=$jaartekst.$jaarhulp[0];
							}else{
								$jaartekst=$jaartekst."?";
							}
						}
						$beschrijving=$fp_rs["beschrijving"];
						for ($ti=1;$ti<=12;$ti++){
							$pdfviewerG[$ti]=false;
							$afbpathG[$ti]="";
							$thumbspathG[$ti]="";
							$framestubG[$ti]="";
							$orgarch=$fp_rs["foto".strval($ti)."arch"];
							$fotofile=$fp_rs["foto".strval($ti)];
							$thumbfile=$fp_rs["thumb".strval($ti)];
							if (strlen($fotofile)>0){
								$faantal=$ti;
								$thumbspathG[$ti]=$thumbsmap."/".substr($thumbfile,0,3)."/".$thumbfile."?".time()."orgarch".$orgarch;
								$afbpathG[$ti]=$fotomap."/".substr($fotofile,0,3)."/".$fotofile."?".time()."orgarch".$orgarch;
								$extensie=substr($fotofile,strpos($fotofile,".")+1);
								if (strpos("jpg jpeg gif png webp",$extensie)===false){$framestubG[$ti]="iframe";}
								if (strpos("pdf",$extensie)!==false){$pdfviewerG[$ti]=true;}
								$ocrfoundG[$ti]=false;
								if($zid=="j"){
										$checkocr=odbc_exec($objConnect,"SELECT * FROM ".$tablename." WHERE kidx='".$fotofile."'");
										if($ocrresult=odbc_fetch_array($checkocr)){$ocrfoundG[$ti]=true;}
								}
								unset ($checkocr);
							}
						}
						$fototitel=$itemtitle;
						if (strlen($bron1)>0){$fototitel=$fototitel."&nbsp;&#8226;&nbsp;Bron:&nbsp;".$bron1;}
						if (strlen($auteur1)>0){$fototitel=$fototitel."&nbsp;&#8226;&nbsp;Auteur:&nbsp;".$auteur1;}
						$fototitel=$fototitel."&nbsp;&#8226;&nbsp;*+jaar: ".$jaartekst."&nbsp;&#8226;&nbsp;Arch.nr: ".$archiefnr;
						?>					
						
						<TABLE class="aac layoutfixed dispinline"><TR> <!-- 1 foto -->
						
							<td width="188">
								<table class="layoutfixed bcollapse" border="0" width="188"><tr>
								<td align="center" width="188" height="188" colspan="3" class="vmidden fotobg">
									<div align="center">
									<?php
									for ($ti=1;$ti<=$faantal;$ti++){ ?>
										<div align="center" id="thumbgal<?php echo $Key.$ti; ?>" class="<?php if ($ti>1){echo "onzichtbaar";} ?><?php if($ocrfoundG[$ti]){ echo " fotobgocr";} ?>">
										<table cellpadding="0" cellspacing="0" border="0" class="bcollapse"><tr><td align="center" height="188" width="188" class="vmidden">
											<div align="center">
											<?php if($ios and $framestubG[$ti]=="iframe"){ ?>
												<a id="fbg<?php echo $Key.$ti; ?>" class="info2 deconone" href="<?php echo $afbpathG[$ti]; ?>" target="_blank">
											<?php
											}else if($pdfviewerG[$ti]==true){ ?>
												<a id="fbg<?php echo $Key.$ti; ?>" data-type="<?php echo $framestubG[$ti]; ?>" data-fancybox="blader" class="info2 deconone fancybox-open-tk" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $afbpathG[$ti]; ?>&search=<?php if($zid=="j"){echo $zoekwoord1;} ?>&zoom=page-fit<?php if ($pft){echo '&pft=j';} ?>" data-caption="<?php echo $fototitel; ?>" title="">
											<?php
											}else{ ?>
												<a id="fbg<?php echo $Key.$ti; ?>" data-type="<?php echo $framestubG[$ti]; ?>" data-fancybox="blader" class="fancybox-open-tk  info2 deconone" href="<?php echo $afbpathG[$ti]; ?>" data-caption="<?php echo $fototitel; ?>" title="">
											<?php
											} ?>
											<img <?php if($rechten=="" and $pft){ ?>onclick="pft();"<?php } ?> border="0" src="<?php echo $thumbspathG[$ti]; ?>"><span><font class="aatekst2"><b><?php echo $itemtitle; ?></b><br><?php echo markeerzoekwoorden(filtercode($beschrijving),2); ?></font></span>
											</a>
											</div>
										</td></tr></table>
										</div>
										<?php
									} ?>		
									<input type="hidden" name="thumbgalteller<?php echo $Key; ?>" id="thumbgalteller<?php echo $Key; ?>" value="1">
									</div>
								</td>
								</tr><tr>
								<td width="80" height="27" class="geenwrap bgzoek" >
									<div align="left" style="margin:0px 3px;">
									<b><font class="tekst2"><?php echo $jaartekst; ?></font></b>
									</div>
								</td>
								<td width="73" height="27" class="geenwrap bgzoek">
									<div align="left" style="margin:0px 0px;"><font class="tekst1">&nbsp;</font>
									<?php
									if ($faantal>1){ ?>
										<img class="thumbaac" title="vorige van <?php echo $faantal; ?>" alt="" border="0" src="<?php echo $basis; ?>images/pijl-links-aa.png" width="20" height="21" align="middle" onclick="wijzigthumb('<?php echo $Key; ?>',-1,<?php echo $faantal; ?>);">
										<img class="thumbaac" title="volgende van <?php echo $faantal; ?>" alt="" border="0" src="<?php echo $basis; ?>images/pijl-rechts-aa.png" width="20" height="21" align="middle" onclick="wijzigthumb('<?php echo $Key; ?>',1,<?php echo $faantal; ?>);">
										<font class="tekst1"><b>(<?php echo $faantal; ?>)</b></font>
										<?php
									} ?>	
									</div>
								</td>
								<td width="34" height="27" class="bgzoek">
									<div  align="left" style="margin-left:15px;">
									<a title="open dit item in lijstweergave" class="deconone handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&archiefnr=<?php echo $archiefnr; ?>&uz=j&vi=li&topshift')"><font class="tekst1"><?php echo $archiefnr; ?></font></a>
									</div>
								</td>
								</tr><tr>
								<td class="fotobg vtop" height="128" colspan="3" style="user-select: text;">
									<div style="margin:3px;">
									<font class="tekstgridtitel"><?php echo markeerzoekwoorden($itemtitle,1); ?></font>
								</div>
								</td></tr><tr><td height="10" colspan="3">
								</td>
								</tr></table>
							</td>
							<td width="10"></td>				
						
						</TR></TABLE> <!-- Eind 1 foto -->
						
						<?php
						$regelteller=$regelteller+1;
					}//next record ?>
					<td width="8"></td>
					</tr></table>
					</div>
					<?php
					// EINDE GALLERIJWEERGAVE
				}
				//EINDE RESULTAATBLOK
				$navpos=2;
				?>
				
				<!-- Onderste navigatie -->				
				<?php include 'bpdivnav.php';	?>	
				<br>
				
			</div> <!-- EINDE Wel Resultaat DIV -->
			<?php
		}
		//Free resouces
		unset($fprs);
		//EINDE SELECTIE GEMAAKT
	}else{
		//GEEN SELECTIE GEMAAKT
		//THUMBS VAN MEEST RECENTE TOEVOEGINGEN TONEN EN ALFABET
		?>
		<div style="margin: 0px <?php echo $maxmarg; ?>px;">
			<TABLE border="0" width="100%">
			<TR><TD align="left" class="vtop">
				<?php
				if($rechten=="ufa"){$recentstub="WHERE doel<>'p'";}
				elseif($rechten=="mo" or $rechten=="sup"){$recentstub="";}
				else{$recentstub="WHERE doel='v'";}
				$fp_sQryCount="SELECT COUNT (*) as aantal FROM (SELECT TOP 5 * FROM archief ".$recentstub.")";
				$fp_sQry="SELECT TOP 5 * FROM archief ".$recentstub." ORDER BY ts DESC";
				$recentaantal=0;
				$fprs=odbc_exec($objConnect,$fp_sQryCount);
				while($row=odbc_fetch_array($fprs)){$recentaantal=$row["aantal"];}
				if($recentaantal>0){ ?>
					<table class="layoutfixed dispinline" border="0" width="100%"><tr>
					<td class="vtop"><br><br>Meest recente<br>toevoegingen:&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td class="vtop">
						<?php
						$fprs=odbc_exec($objConnect,$fp_sQry);
						while($row=odbc_fetch_array($fprs)){ ?>
						<table cellpadding="0" cellspacing="0" border="0" class="layoutfixed dispinline"><tr>
							<td width="15"></td>				
							<td align="center" height="110" width="110" class="vmidden">
							<a class="handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&archiefnr=<?php echo $row["archiefnr"]; ?>&vi=li&uz=j&topshift')">
								<?php
								if(strlen($row["foto1"])>0){ ?>
									<img src="<?php echo $basis; ?>BPT/<?php echo substr($row["Key"],0,3)."/".$row["thumb1"]; ?>" width="110" title="<?php echo $row["itemtitle"]; ?>">
								<?php } else { ?>
									<img src="<?php echo $basis; ?>images/legefoto.gif" width="110" title="<?php echo $row["itemtitle"]; ?>">
								<?php } ?>
							</a>
							</td>
						</tr></table>
						<?php
						} ?>
					</td>						
					</tr></table>
				<?php
				} ?>
			</TD>
			</TR><TR>
			<TD align="left">
				<div id="alfabetdiv" name="alfabetdiv" align="left">
					<b><font class="tekst4 deconone">
					<?php
					$alfabet=array("<u>A</u>","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
					foreach($alfabet as $letter){ ?>
						<a class="handje" onclick="namenlijst('<?php echo $letter; ?>');"><?php echo $letter; ?></a>&nbsp;&nbsp;
					<?php
					}
					?>
					</font></b><br><br>
					<div style="column-width:195px;" align="left">
					<?php
					//Lees familienamen beginnend met $letter
					$letter="A";
					$doelstub="doel='v' AND";
					if ($rechten=="ufa"){$doelstub= "doel<>'p' AND";}
					if ($rechten=="mo" or $rechten=="sup"){$doelstub="";}
					$erzijnnamen=0;
					$fprs=odbc_exec($objConnect, "SELECT DISTINCT personen FROM plist WHERE ".$doelstub." UCASE(personen) LIKE '".$letter."%' ORDER BY personen ASC");
					while($fp_rs=odbc_fetch_array($fprs)){
						$erzijnnamen++;
						$familienaam=$fp_rs["personen"]; ?>
						<a class="linkOndw handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?av=bp&m=<?php echo $familienaam; ?>&uz=j&vi=<?php echo $vi; ?>&topshift');"><?php echo $familienaam; ?></a>
						<br>
						<?php
					}
					odbc_free_result($fprs); ?>
					</div>
					<?php
					if($erzijnnamen==0){echo "Geen familienamen beginnend met de letter ".$letter." gevonden"; }
					?>
				</div>
				<br>
			</TD></TR></TABLE>
		</div> 
	<?php	
	} 
	//EINDE WEL OF GEEN SELECTIE GEMAAKT

	// ###EINDE MAIN BLOCK###
	if($totaalstukocr==true){odbc_exec($objConnect,"DROP TABLE ".$tablename);}
	odbc_close($objConnect);
	odbc_close($defConnect);
	unset($objConnect);
	unset($defConnect);
?>
<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td>
	<br>
	<div align="right"><font class="copynotice">SCORS&nbsp;v3.0&nbsp;<?php if ($rechten=="mo" or $rechten=="sup"){echo "Administratie&nbsp;";} ?>&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font></div>
</td></tr></table>
<?php
//*******EINDE NIET JSON
} ?>
