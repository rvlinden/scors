// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

var scrollnu=0;startloop=true;aantalloaded=0;
function delcheck(sleutel,naam){
	var answer=confirm("Weet U zeker dat u dit tijdschrift "+naam+" wilt verwijderen?");
	if (answer){
		var d=new Date().getTime();
		xmltrein("ttadmin.php?&aktie=del&Key="+sleutel+"&naam="+naam+"&t="+d);location.reload();}
	return;}
function getcontainer(urlquery){
	startloop=true;var d=new Date().getTime();
	if(urlquery==''){urlquery='?t='+d;}else{if(urlquery.indexOf('t=1')<0){urlquery=urlquery+'&t='+d;}}
	if (backforwardused==false){history.pushState(null,null,location.href);history.replaceState(null,null,urlquery);}
	backforwardused=false;
	if (ctrltoets==true){ctrltoets=false;window.open(urlquery);window.focus();}
	else{
		urlquery=vlinden+"ttdiv.php"+urlquery+'t='+d;
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET",urlquery,false);
		xmlhttp.setRequestHeader("vm",$('#vm').val());
		xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
		document.getElementById('ttcontainer').innerHTML=xmlhttp.responseText;
	    var bounding = document.getElementById("top").getBoundingClientRect();
		if (scrollnu==1 || bounding.top < 0){$("body,html").animate({scrollTop: $("#top").offset().top},200);}
		scrollnu=scrollnu+1;
	}
	return;}
function xmltrein(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	return;}
function keyPressListener(e) {
	if (e.keyCode == 13) {ttzoek($("#zsr").val());}
	return;}
function ttzoek(soort){
	getcontainer('?zsr='+$('#zsr').val()+'&jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&av=tt&zsr='+soort+'&sort='+$('#sort:checked').val()+'&zoek='+$('#zoek').val()+'&znaamtt='+$("#znaamtt").find(":selected").val());
	return;}
function checkresult(){
	if (startloop==false){getcontainer('?zsr='+$('#zsr').val()+'&jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&av=tt&sort='+$('#sort').val()+'&zoek='+$('#zoek').val()+'&pg='+$('#pg').val()+'&znaamtt='+$("#znaamtt").val());}
	else{aantalloaded++;if(aantalloaded>0){startloop=false;}}
return;}
function checknummer(nummerveld){ //Controleer of velden uit cjfers bestaan
	var echtnummer=$('#'+nummerveld).val().replace(/[^0-9]/g, '0');$('#'+nummerveld).val(echtnummer);
	return;}
function wachtimage(){
	document.getElementById('wachtdiv').style.display='block';
	document.forms("ttform").submit();
return;}
function vulnamen(){
	$('.naamtt').autocomplete({source:'ttadmin.php?aktie=vulnamen',minLength: 0});
return;}
function getsearch(){
	var sortering=$('#sort').find(":selected").val();
	getcontainer('?av=tt&jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&zsr='+$('#zsr').val()+'&sort='+sortering+'&zoek='+$('#zoek').val()+'&znaamtt='+$("#znaamtt").find(":selected").val());
return;}
	
$.fancybox.defaults.hash = false;
var backforwardused=false;var ctrltoets=false;
window.onpopstate=function(event){backforwardused=true;getcontainer('?'+window.location.search.substring(1));return;};
if(window.location.search.substring(1)==''){getcontainer('')}else{getcontainer('?'+window.location.search.substring(1))};
