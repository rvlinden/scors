<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//redirect HTTP naar HTTPS
if (! isset($_SERVER['HTTPS']) or $_SERVER['HTTPS'] == 'off') {
    $redirect_url = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url");
    exit();
}
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");

$rechten="";$user="";
//check of is ingelogd en haal rechten op
if(isset($_COOKIE['user'])){$user=$_COOKIE['user'];}
if(strlen($user)>0){ //haal rechten op en sla deze op in de cookie
	$fprs=odbc_exec($defConnect,"SELECT rechten from users WHERE user='".$user."'");
	while($row = odbc_fetch_array($fprs)){$rechten=$row["rechten"];}
	odbc_free_result($fprs);
	setcookie("logon", $rechten);
}

$av="aa";
if(isset($_REQUEST['av'])){$av=$_REQUEST['av'];}
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row=odbc_fetch_array($fprs);
$sitenaam=$row["sitenaam"];
$toonav=false;$allowav=$row["allowav"];
if($allowav=="on"){$toonav=true;}
$toonbb=false;$allowbb=$row["allowbb"];
if($allowbb=="on"){$toonbb=true;}
$toonbp=false;$allowbp=$row["allowbp"];
if($allowbp=="on"){$toonbp=true;}
$toontt=false;$allowtt=$row["allowtt"];
if($allowtt=="on"){$toontt=true;}
unset($fprs);
odbc_close($defConnect);
unset($defConnect);

$user_agent="standard";
if(isset($_SERVER['HTTP_USER_AGENT'])){$user_agent = $_SERVER['HTTP_USER_AGENT'];}
if (strpos($user_agent, 'Mobile') !== false || strpos($user_agent, 'Android') !== false || strpos($user_agent, 'iPhone') !== false) {
    // User is likely using a mobile device
	$maxbreed="768";$maxmarg="20";
} else {   // User is likely not using a mobile device
	$maxbreed="1055";$maxmarg="75";
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="UTF-8">
<meta name="author" content="Rob van Linden, R.F.J. van Linden">
<title><?php echo $sitenaam; ?></title>
<script src="jquery/jquery-3.7.0.min.js"></script>
<link rel="stylesheet" href="jquery/jqte.css" type="text/css">
<script src="jquery/jquery-te-1.4.0.js" charset="UTF-8"></script>
<link rel="stylesheet" href="jquery/jquery.fancybox.css">
<script src="jquery/jquery.fancybox.min.js"></script>
<link rel="stylesheet" href="jquery/jquery-ui.css" type="text/css">
<script src="jquery/jquery-ui.min.js"></script>
</head>

<body class="archiefbody">

<br><br>
<div style="max-width:<?php echo $maxbreed; ?>px;margin:auto;background-color:#FFFFFF; border-color:#afafaf;border-left-width:0px; border-right-width:0px; border-top-style:solid; border-top-width:2px; border-bottom-width:0px;">

<!-- KOP EN NAVIGATIE-->

	<table border="0" class="bcollapse" cellpadding="0" cellspacing="0" width="100%"><tr>
		<td width="125" align="right">
			<img src="images/logoscors.png" valign="top" height="25">
		</td><td align="left">
			<H3>&nbsp;&nbsp;<i><?php echo $sitenaam; ?></i>&nbsp;&nbsp;</H3>
		</td>
	</td><td align="left">
		<?php if (strlen($rechten)>0) { ?>
		<div class="dropdown"><b>
			<?php
				if($rechten=="sup"){echo "Admin&nbsp;".$user;}
				if($rechten=="mo"){echo "Editor&nbsp;".$user;}
				if($rechten=="ufa"){echo "Lid&nbsp;".$user;
			} ?>
			</b>&nbsp;&nbsp;
			<div class="dropdown-content">
				<a href="logon.php?lu=lo">&nbsp;Uitloggen&nbsp;</a>
				<a href="logon.php?lu=cww">&nbsp;Wachtwoord&nbsp;wijzigen&nbsp;</a>
			</div>
		</div>
		<?php }else{ ?>
			<a href="logon.php?lu=li" class="geendeco"><b>Inloggen</b></a>&nbsp;&nbsp;
		<?php } ?>
	</td><td align="right">
		<a href="info.php" class="geendeco"><b>Info</b></a>&nbsp;&nbsp;
	</td><td align="right">
		<?php if($rechten=="sup"){ ?>
			<a href="setup.php"><img height="20" title="Systeembeheer" src="images/setup.png"></a>&nbsp;&nbsp;
		<?php } ?>
	</td>
	</tr></table>
	
	<table border="0" class="bcollapse bgzoek" cellpadding="0" cellspacing="0" width="100%"><tr>
	<td width="20">&nbsp;
	</td><td>
	<H3><a class="menuscors <?php if ($av=='aa'){echo 'bright';} ?>" href="index.php">Hoofdcollectie</a>&nbsp;&nbsp;
	<?php if($toonav){ ?>
		<a class="menuscors <?php if ($av=='av'){echo 'bright';} ?>" href="index.php?av=av">Audio-Video</a>&nbsp;&nbsp;
	<?php } ?>
	<?php if($toonbb){ ?>
		<a class="menuscors <?php if ($av=='bb'){echo 'bright';} ?>" href="index.php?av=bb">Boeken</a>&nbsp;&nbsp;
	<?php } ?>
	<?php if($toontt){ ?>
		<a class="menuscors <?php if ($av=='tt'){echo 'bright';} ?>" href="index.php?av=tt">Tijdschriften</a>&nbsp;&nbsp;
	<?php } ?>
	<?php if($toonbp){ ?>
		<a class="menuscors <?php if ($av=='bp'){echo 'bright';} ?>" href="index.php?av=bp">Bidprentjes</a>&nbsp;&nbsp;
	<?php } ?>
	</td></tr></table>
	
	<div style="margin:0px 75px;max-width:1055px;">
		<br><br>
		<span style="color: var(--basiskleur2);font-size:26px;"><b><?php if($av=="aa"){echo "Hoofdcollectie";}else if($av=="bp"){echo "Bidprentjescollectie";}else if($av=="bb"){echo "Boekencollectie";}else if($av=="tt"){echo "Tijdschriftencollectie";}else{echo "Audio-Videocollectie";} ?></b></span>
	</div>

<!-- CONTAINER DIV -->		

	<div id="<?php echo $av; ?>container" style="display:block;" align="center"></div>
	<div id="<?php echo $av; ?>script"></div>
	<script src="<?php echo $av; ?>load.js"></script>
	<script>$('#buttonteksten').attr("color","black");</script>

</div>	
<br><br><br>
</body></html>