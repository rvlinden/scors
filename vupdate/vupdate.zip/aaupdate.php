<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

//Check of gebruiker is ingelogd
if ($rechten!="mo" and $rechten!="sup"){exit();}

// Lees de gevraagde aktie in. Akties zijn:
// 1: selectblok: update de lookup-velden van de edit-mode en de selectievelden die bij uitgebreid zoeken worden getoond
// 2: suggesties: update de woordenlijst van suggesties zie bij vrij zoeken wordt getoond
// 3: ocr cleanup: opschonen van ocr teksten indien de oorspronkelijke bijbehorende records zijn verwijderd
// 4: blacklist: update de database met IP adressen die geblokkeerd worden. Deze database wordt gedownload van http://www.myip.ms
// ocrimport: tekstherkenning op een bestand uit de queue (naam in query parameter kidx)
// Als de aktie leeg is worden akties 1 t/m 4 achtereenvolgens uitgevoerd

$aktie="";
if(isset($_REQUEST['aktie'])){$aktie=$_REQUEST['aktie'];}
if(isset($_REQUEST['lijst'])){$lijst=$_REQUEST['lijst'];}else{$lijst="all";}
$objarchief=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");

if($aktie==""){
?>
	<html><head>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

	</head><body>

<div id="tekst">Update gestart. Wachten a.u.b....<br><br></div>

	<script type=text/javascript>
	var tekst='Update gestart. Wachten a.u.b....<br><br>';var antwoord='';var uteller=0;
	function xmltrein(urlzin){	
		var xmlA=new XMLHttpRequest();xmlA.open('GET',urlzin+'&t='+new Date().getTime(), false);xmlA.send();
		var countS=0;while (xmlA.readystate<4){setTimeout(function(){countS++},50);}
		antwoord=xmlA.responseText;
		return;}
	function tekstupdate(){tekst=tekst+antwoord+'<br>';document.getElementById('tekst').innerHTML=tekst;return;}
	
	// Feitelijke update functie die achtereenvolgens de verschillende updates uitvoert
	function updater(){
		uteller++;
		if(uteller==1){xmltrein('aaupdate.php?aktie=selectblok');if (antwoord.length>0){tekstupdate()};updater();}
		else if(uteller==2){xmltrein('aaupdate.php?aktie=suggesties');if (antwoord.length>0){tekstupdate()};updater();}
		else if(uteller==3){xmltrein('aaupdate.php?aktie=ocrclean');if (antwoord.length>0){tekstupdate()};updater();}
		else if(uteller==4){
			xmltrein('aaupdate.php?aktie=blacklist');if (antwoord.length>0){tekstupdate();}
		}
		return;}
	$(document).ready(function($){updater()});
	</script>

	</body></html>

<?php
//	Selecteer lijsten van unieke straten, personen, bronnen, onderwerpen, soorten, auteurs, mapnummers.
//	Schrijf het resultaat weg in de respectievelijke tabellen wlist, plist, ulist, rlist, slist, alist, mlist, vlist
//  Deze worden gebruikt in edit-mode voor de lookup lijsten
}elseif($aktie=="selectblok"){
	
	if($lijst=="str" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM wlist");
		$fprs=odbc_exec($objarchief,"INSERT INTO wlist (straten,doel) SELECT DISTINCT straat,doel FROM archief where len(straat)>0");
	}
	if($lijst=="per" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM plist");
		$fprs=odbc_exec($objarchief,"INSERT INTO plist (personen,doel) select persoon,doel FROM  (SELECT persoon,doel FROM archief where len(persoon)>0 union SELECT persoon2,doel FROM archief where len(persoon2)>0)");
	}
	if($lijst=="bro" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM ulist");
		$fprs=odbc_exec($objarchief,"INSERT INTO ulist (bronnen,doel) select bron1,doel FROM (select bron1,doel from archief where len(bron1)>0 union select bron2,doel FROM archief where len(bron2)>0 union select bron3,doel FROM archief where len(bron3)>0)");
	}
	if($lijst=="ond" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM rlist");
		$fprs=odbc_exec($objarchief,"INSERT INTO rlist (onderwerpen,doel) select onderwerp1,doel FROM (select onderwerp1,doel from archief where len(onderwerp1)>0 union select onderwerp2,doel FROM archief where len(onderwerp2)>0 union select onderwerp3,doel FROM archief where len(onderwerp3)>0 union select onderwerp4,doel FROM archief where len(onderwerp4)>0)");
		$fprs=odbc_exec($objarchief,"DELETE * FROM raantal");
		$fprs=odbc_exec($objarchief,"INSERT INTO raantal (onderwerpen) select onderwerp1 FROM (select onderwerp1 from archief where len(onderwerp1)>0 union select onderwerp2 FROM archief where len(onderwerp2)>0 union select onderwerp3 FROM archief where len(onderwerp3)>0 union select onderwerp4 FROM archief where len(onderwerp4)>0)");
		$fprs=odbc_exec($objarchief,"SELECT * FROM raantal");
		while($fp_rs=odbc_fetch_array($fprs)){
			$onderwerp=$fp_rs["onderwerpen"];$aantal=0;

			$aantalstub=" AND (doel='v')";
			$sql="SELECT COUNT(*) AS raantal FROM archief WHERE (onderwerp1='".$onderwerp."' OR onderwerp2='".$onderwerp."' OR onderwerp3='".$onderwerp."' OR onderwerp4='".$onderwerp."') ";
			$fprs_count=odbc_exec($objarchief,$sql.$aantalstub);
			$fprsaantal=odbc_fetch_array($fprs_count);
			$aantal=$fprsaantal["raantal"];
			$fprs_count=odbc_exec($objarchief,"UPDATE raantal SET vaantal=".strval($aantal)." WHERE onderwerpen='".$onderwerp."'");

			$aantalstub=" AND (doel='e')";
			$sql="SELECT COUNT(*) AS raantal FROM archief WHERE (onderwerp1='".$onderwerp."' OR onderwerp2='".$onderwerp."' OR onderwerp3='".$onderwerp."' OR onderwerp4='".$onderwerp."') ";
			$fprs_count=odbc_exec($objarchief,$sql.$aantalstub);
			$fprsaantal=odbc_fetch_array($fprs_count);
			$aantal=$aantal+$fprsaantal["raantal"];
			$fprs_count=odbc_exec($objarchief,"UPDATE raantal SET eaantal=".strval($aantal)." WHERE onderwerpen='".$onderwerp."'");
			
			$aantalstub=" AND (doel='p')";
			$sql="SELECT COUNT(*) AS raantal FROM archief WHERE (onderwerp1='".$onderwerp."' OR onderwerp2='".$onderwerp."' OR onderwerp3='".$onderwerp."' OR onderwerp4='".$onderwerp."') ";
			$fprs_count=odbc_exec($objarchief,$sql.$aantalstub);
			$fprsaantal=odbc_fetch_array($fprs_count);
			$aantal=$aantal+$fprsaantal["raantal"];
			$fprs_count=odbc_exec($objarchief,"UPDATE raantal SET paantal=".strval($aantal)." WHERE onderwerpen='".$onderwerp."'");
		}
	}
	if($lijst=="aut" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM alist");
		$fprs=odbc_exec($objarchief,"INSERT INTO alist (auteurs,doel) select auteur1,doel FROM (select auteur1,doel from archief where len(auteur1)>0 union select auteur2,doel FROM archief where len(auteur2)>0 union select auteur3,doel FROM archief where len(auteur3)>0)");
	}
	if($lijst=="map" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM mlist");
		$fprs=odbc_exec($objarchief,"INSERT INTO mlist (mapnrs,doel) SELECT DISTINCT mapnr,doel FROM archief where len(mapnr)>0");
	}
	if($lijst=="soo" or $lijst=="all"){
		$fprs=odbc_exec($objarchief,"DELETE * FROM slist");
		$fprs=odbc_exec($objarchief,"INSERT INTO slist (soorten,doel) SELECT DISTINCT soort1,doel FROM archief  where len(soort1)>0");
	}
	if($lijst=="all"){
		// Creeer een set van alle unieke combinaties van onderwerpen, auteurs, soorten, straten en bronnen en schrijf het resultaat weg in de tabel lijst
		// Deze wordt gebruikt voor het maken van voorselecties in de andere zoekvelden zodra een waarde in 1 van de zoekvelden is geselecteerd
		$fprs=odbc_exec($objarchief,"DELETE * FROM lijst");
		$fprs=odbc_exec($objarchief,"INSERT INTO lijst (straat,persoon,persoon2,onderwerp1,onderwerp2,onderwerp3,onderwerp4,soort1,bron1,bron2,bron3,auteur1,auteur2,auteur3,doel) select distinct straat,persoon,persoon2,onderwerp1,onderwerp2,onderwerp3,onderwerp4,soort1,bron1,bron2,bron3,auteur1,auteur2,auteur3,doel FROM archief");
	}
	
	echo "Update lookup lijsten voor edit-velden klaar<br>";

	odbc_free_result($fprs);
	unset($fprs);

}elseif($aktie=="suggesties"){

	// Maak lijsten van alle unieke straten, bronnen, soorten, onderwerpen en auteurs
	// Deze worden gebruikt als suggestie bij de vrije zoekfunctie
	$fprs=odbc_exec($objarchief,"DELETE * FROM suggesties");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT straten,doel FROM wlist");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT personen,doel FROM plist");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT bronnen,doel FROM ulist");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT soorten,doel FROM slist");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT onderwerpen,doel FROM rlist");
	$fprs=odbc_exec($objarchief,"INSERT INTO suggesties (woord,doel) SELECT DISTINCT auteurs,doel FROM alist");
	
	echo "Update suggesties voor vrije zoekfunctie klaar<br>";

	odbc_free_result($fprs);
//	odbc_free_result($fprsout);
	unset($fprs);
//	unset($fprsout);

}elseif($aktie=="blacklist"){

	// Download de nieuwste blacklist
	$zwartelijst=explode(chr(10),file_get_contents("http://www.myip.ms/files/blacklist/csf/latest_blacklist.txt"));

	// Clear de oude ip database behalve voor de permanente adressen (P)
	$objblacklist=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/blacklist.mdb","","");
	$fprs=odbc_exec($objblacklist,"DELETE * FROM blackip WHERE NOT fix='P'");
	
	// Update de database aan de hand van de nieuwe download
	foreach ($zwartelijst as $adres){
		//Skip regels die karakters ; of # bevatten (commentaar regels in lijst)
		if(strlen($adres)>0 and strpos($adres, "#")===false and strpos($adres,":")===false){
			$fprs=odbc_exec($objblacklist,"INSERT INTO blackip (ipadres,fix) VALUES ('".$adres."', '')");
		}
	}
	odbc_close($objblacklist);
	unset($objblacklist);
	
	echo "Update spammer/hacker IP blacklist klaar<br><br>Einde<br>Ververs nu uw scherm.";
	
	unset($fprs);

}elseif($aktie=="ocrclean"){

	// Verwijder orphaned OCR records
	//$fprs=odbc_exec($objarchief,"DELETE FROM ocr WHERE LEFT(kidx,6) NOT IN (SELECT Key FROM archief)");
	echo "Cleanup OCR records klaar<br>";
	//odbc_free_result($fprs);
	//unset($fprs);

}elseif($aktie=="ocrimport" and isset($_REQUEST['kidx'])){
	$extensie=$_REQUEST['extensie'];
	$kidx=$_REQUEST['kidx'];
	if($extensie=="txt"){$kidx=substr($kidx,4);}
	$kidx=substr($kidx,0,13); // kidx is filenaam in map in/out zonder extensie
	$filenaam="ocr/out/".$kidx.".txt";
	//lees de inhoud van de .txt
	$tekst=file_get_contents ($filenaam);
	$tekst=str_replace(chr(10)," ",$tekst);
	$tekst=str_replace(chr(13),"",$tekst);
	$tekst=str_replace("ü","u",$tekst);
	$tekst=str_replace("é","e",$tekst);
	$tekst=str_replace("ä","a",$tekst);
	$tekst=str_replace("à","a",$tekst);
	$tekst=str_replace("ê","e",$tekst);
	$tekst=str_replace("ë","e",$tekst);
	$tekst=str_replace("è","e",$tekst);
	$tekst=str_replace("ï","i",$tekst);
	$tekst=str_replace("î","i",$tekst);
	$tekst=str_replace("ì","i",$tekst);
	$tekst=str_replace("ô","o",$tekst);
	$tekst=str_replace("ö","o",$tekst);
	$tekst=str_replace("ò","o",$tekst);
	$tekst=str_replace("û","u",$tekst);
	$tekst=str_replace("ù","u",$tekst);
	$tekst=str_replace("ÿ","y",$tekst);
	$tekst=str_replace("á","a",$tekst);
	$tekst=str_replace("í","i",$tekst);
	$tekst=str_replace("ó","o",$tekst);
	$tekst=str_replace("ú","u",$tekst);
	$tekst=str_replace("ñ","n",$tekst);
	$tekst=str_replace("”","",$tekst);
	$tekst=str_replace("“","",$tekst);
	$tekst=str_replace("~","",$tekst);
	$tekst=str_replace("^","",$tekst);
	$tekst=str_replace("^","",$tekst);
	$tekst=str_replace("`","",$tekst);
	
	$karyes=" abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-+=()@:;/?!,.";
	$strippedtekst="";
	for ($strip=0;$strip<strlen($tekst);$strip++){
		$eenkar=substr($tekst,$strip,1);
		if(!empty($eenkar)){
			if(strpos( $karyes,$eenkar)!==false){$strippedtekst=$strippedtekst.$eenkar;}
		}
	}
	$tekst=$strippedtekst;
	while(strpos($tekst,"  ")!==false){$tekst=str_replace("  "," ",$tekst);}
	while(strpos($tekst,"..")!==false){$tekst=str_replace("..",".",$tekst);}
	while(strpos($tekst,"--")!==false){$tekst=str_replace("--","-",$tekst);}
//	echo $tekst;
	//Maak nieuwe records van elk max 64KB aan in database en vul velden
	//zoek het record waar kidx nu in zit
	$delcheck=odbc_exec($objarchief,"SELECT * FROM archief WHERE foto1&' '&foto2&' '&foto3&' '&foto4&' '&foto5&' '&foto6&' '&foto7&' '&foto8&' '&foto9&' '&foto10&' '&foto11&' '&foto12 like '%".$kidx."%'");
	$eristekst=false;
	while($row=odbc_fetch_array($delcheck)){ //foto kan intussen verwijderd zijn
		$volgnummer=1;
		while (strlen($tekst)>0){
			$eristekst=true;
			if (strlen($tekst)>64000){	$tekstdeel=substr($tekst,0,64000);$tekst=substr($tekst,64000);}
			else{$tekstdeel=$tekst;$tekst="";}
			$fprs=odbc_exec($objarchief,"INSERT INTO ocr (kidx,tekstdeel, volgnummer) VALUES ('".$kidx."','".$tekstdeel."',".strval($volgnummer) .")");
			$volgnummer++;
		}
		if($eristekst and $extensie=="pdf"){
			//wijzig de bestandsnaam in het originele record in .pdf en maak een nieuwe thumbnail
			$Key=$row["Key"];
			//vind het fotonummer
			for($i=1;$i<=12;$i++){
				$fotonaam=$row["foto".strval($i)];
				$thumbnaam=$row["thumb".strval($i)];
				if(strpos($fotonaam,$kidx)!==false){
					$fprs=odbc_exec($objarchief,"UPDATE archief set foto".strval($i)."='".$kidx.".pdf' WHERE Key=".strval($Key));
					// maak nieuwe thumbnail
					$thumbsmap="./AAT/".substr($fotonaam,0,3) . "/";
					$thumbfile=$thumbsmap.$thumbnaam;
					$im = new imagick();
					$im->setResolution( 300, 300);
					$im->readImage($thumbfile.'[0]');
					$im->setImageFormat('jpg');
					$draw = new ImagickDraw();
					$draw->setFillColor('red');
					$draw->setFont('Arial');
					$draw->setFontSize( 18 );
					$im->annotateImage($draw, 4, $im->getImageHeight()-4, 0, 'PDF');
					unlink($thumbfile);
					$im->writeImage($thumbfile);
					unset ($im);
					break;
				}
			}
			//kopieer de PDF naar AAD
			copy("ocr/out/".$kidx.".pdf", "AAD/".substr($kidx,0,3)."/".$kidx.".pdf");
		}
	}
	//verwijder tekstfile en pdffile uit queue
	if($extensie=="pdf"){unlink("ocr/out/".$kidx.".pdf");}
	unlink("ocr/out/".$kidx.".txt");
	
	// Update logfile
	$zinDate=date("Y-M-d");
	$zinTime=date("h.i.s");
	$logfile="log/scorsocrlog.txt";
	if($eristekst){$logzin=" OCR tekst toegevoegd voor document #".$kidx;}
	else{$logzin=$zinTime." OCR scan heeft geen tekst gevonden in document #".$kidx;}
	$logzin=$zinDate." ".$zinTime." ip:".$_SERVER["REMOTE_ADDR"]." user:".$_COOKIE['logon']." ".$logzin.chr(13).chr(10);
	//		error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	fwrite($oTextFile,$logzin);
	fclose($oTextFile);
	//		error_reporting(-1);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsocrlog_".$zinDate."_".$zinTime.".txt";
		rename ($logfile,$newname);
	}

}
$fprs=odbc_exec($objarchief,"UPDATE delta SET delta=''");
unset($fprs);
odbc_close($objarchief);
unset($objarchief);
?>