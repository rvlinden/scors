<table border="0" class="aac layoutfixed" width="90%"><tr><td>
	<table border="0" class="dispinline layoutfixed"><tr>
		<td width="30">
		<?php if ($PageCount>1){
			if ($CurrentPage>1){ ?>
				<a class="handje geendeco" href="setup.php?wijzig=users&pg=<?php echo strval(($CurrentPage-1)); ?>">
				<img class="vmidden" alt="" border="0" src="images/pijl-links-aa.png" width="20" height="21"></a>
				<?php
			}else{ ?>
				<img class="vmidden" alt="" src="images/pijl-links-grijs-aa.png" width="20" height="21">
				<?php
			} ?>
			&nbsp;
		</td><td style="max-width:450px;">
			<?php for ($i=1; $i<=$PageCount;$i++){ ?>
				<a class="geendeco handje" href="setup.php?wijzig=users&pg=<?php echo strval($i); ?>">
				<span class="aapagetellerpas"><font class="nullen">0</font><?php if ($i<100 and $PageCount>=100){ ?><font class="nullen">0</font><?php }if ($i<10 and $PageCount>=10){ ?><font class="nullen">0</font><?php }if ($i==$CurrentPage){ ?><span class="aapagetelleract"><b><?php echo $i; ?></b></span><?php }else{echo $i;} ?></span>
				</a>
				<?php
			} ?>
		</td><td width="30">
			&nbsp;
			<?php if ($CurrentPage<$PageCount){ ?>
				<a class="handje" href="setup.php?wijzig=users&pg=<?php echo strval(($CurrentPage+1)); ?>">
				<img class="vmidden" alt="" border="0" src="images/pijl-rechts-aa.png" width="20" height="21"></a>
				<?php
			}else{ ?>
				<img class="vmidden" alt="" src="images/pijl-rechts-grijs-aa.png" width="20" height="21">
				<?php
			}
		} ?>
		</td>
	</tr></table>
</td></tr></table>

