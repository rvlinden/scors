// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

uploadstatus='OK';Fsleutel='';
var startloop=true;var scrollnu=0;

function wijzigfoto(sleutel) {
	$('#wachtimg'+sleutel).show();
	Fsleutel=sleutel;var uploadfout=false;
	if (uploadstatus=='NOK'){alert('Vorige upload nog niet klaar. Probeer opnieuw zodra deze klaar is.\nVervers het scherm met Shift-F5 als de fout niet verdwijnt.');uploadfout=true;}
	if (uploadfout==false){uploadstatus='NOK';document.forms['addfoto'+sleutel].submit();}
	return;}
function editboek(sleutel,veldnaam){
	xmltrein('bbadmin.php?aktie=editboek&Key='+sleutel+'&veldnaam='+veldnaam+'&veldinhoud='+$('#v'+sleutel+veldnaam).val());
return;}
function bestelbaar(sleutel){
	var bestelbaar;
	bestelbaarveld=document.getElementById('bestelbaar'+sleutel);
	if (bestelbaarveld.checked){bestelbaar='X';}else{bestelbaar='';};
	xmltrein('bbadmin.php?aktie=bestelbaar&Key='+sleutel+'&veldinhoud='+bestelbaar);
return;}
function delregel(sleutel){
	var answer=confirm("Weet U zeker dat U dit boek uit de lijst wilt verwijderen?");
	if (answer){xmltrein('bbadmin.php?aktie=delboek&Key='+sleutel);location.reload();}
return;}
function nieuw(){
	var url='bbadmin.php?aktie=nieuwboek';window.location=url;
return;}
function checkresult(){
	if (startloop==false){
		$('#wachtimg'+Fsleutel).hide();
		var innerDoc=document.getElementById('fou').contentDocument || document.getElementById('fou').contentWindow.document; 
		var resultaat=innerDoc.getElementById('resultaat').value;
		switch(resultaat) {
			case 'JPG':
    			// update fotothumb en href
				if(uploadstatus=='NOK'){
					var d=new Date().getTime();
					document.getElementById('fotoa'+Fsleutel).src='BB/'+Fsleutel+'ga.jpg?t='+d;
					$("#fb"+Fsleutel).prop("href", 'BB/'+Fsleutel+'JPG.jpg?t='+d);
					$("#fb"+Fsleutel).prop("data-type", "");
					$("#fb"+Fsleutel).fancybox({preload:false});
					uploadstatus='OK';
				}
    			break;
			case 'PDF':
    			// update fotothumb en href
				if(uploadstatus=='NOK'){
					var d=new Date().getTime();
					document.getElementById('fotoa'+Fsleutel).src='BB/'+Fsleutel+'ga.jpg?t='+d;
					$("#fb"+Fsleutel).prop("href", 'BB/'+Fsleutel+'.pdf?t='+d);
					$("#fb"+Fsleutel).prop("data-type", "iframe");
					$("#fb"+Fsleutel).fancybox({preload:false});
					uploadstatus='OK';
				}
    			break;
  			case 'NOPDF':
  				alert('Uploadbestand moet .PDF, .JPG of .JPEG zijn');uploadstatus="OK";break;
			default:
				alert('Aktie mislukt. Ververs het scherm en probeer opnieuw.');uploadstatus="OK";break;
		} 
	}
	else {startloop=false;}
return;}
function getcontainer(sort,zoek,vi,pg){
	startloop=true;var d=new Date().getTime();
	var url=vlinden+'bbdiv.php?sort='+sort+'&zoek='+zoek+'&pg='+pg+'&vi='+vi+'&t='+d;
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	document.getElementById('bbcontainer').innerHTML=xmlhttp.responseText;
    var bounding = document.getElementById("top").getBoundingClientRect();
	if (scrollnu==1 || bounding.top < 0){$("body,html").animate({scrollTop: $("#top").offset().top},200);}
	scrollnu=scrollnu+1;
	$('.bbauteur').autocomplete({source:'bbadmin.php?aktie=vulnamen&veld=auteur',minLength: 0});
	$('.bbuitgever').autocomplete({source:'bbadmin.php?aktie=vulnamen&veld=uitgever',minLength: 0});
return;}
function xmltrein(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
return;}
function keyPressListener(e) {
	if (e.keyCode == 13) {getcontainer($('#sort').val(),$('#zoek').val(),'');}
return;}


getcontainer('','','',1);
