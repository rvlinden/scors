<div style="margin:0px 75px;" align="left">
<table class="layoutfixed aac" width="90%"><tr><td>
	<table class="dispinline layoutfixed" style="float:left;"><tr>
	<td  width="80" class="geenwrap" height="28">
		<a class="handje" title="Lijst weergave" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('<?php echo $paramstring."&amp;vi=li"; ?>')">
		<img border="0" alt="" src="<?php echo $basis; ?>images/lijstview.gif" align="middle" width="20" height="20" vspace="2" class="vmidden <?php if ($vi=="li"){ ?>viak<?php }else{ ?>vipa<?php } ?>"></a>&nbsp;
		<a class="handje" title="Galerij weergave" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('<?php echo $paramstring."&amp;vi=ga"; ?>')">
		<img border="0" alt="" src="<?php echo $basis; ?>images/gallerij.gif" align="middle" width="20" height="20" vspace="2" class="vmidden <?php if ($vi=="ga"){ ?>viak<?php }else{ ?>vipa<?php } ?>"></a>
	</td>
	</tr></table>
	<table class="dispinline layoutfixed"><tr>
		<td width="30">
		<?php if ($PageCount>1){
			if ($CurrentPage>1){ ?>
				<a class="handje geendeco" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('<?php echo $paramstring."&vi=".$vi."&amp;pg=".strval(($CurrentPage-1)); ?>')">
				<img class="vmidden" alt="" border="0" src="<?php echo $basis; ?>images/pijl-links-aa.png" width="20" height="21"></a>
				<?php
			}else{ ?>
				<img class="vmidden" alt="" src="<?php echo $basis; ?>images/pijl-links-grijs-aa.png" width="20" height="21">
				<?php
			} ?>
			&nbsp;
		</td><td style="max-width:450px;">
			<?php for ($i=1; $i<=$PageCount;$i++){ ?>
				<a class="geendeco handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('<?php echo $paramstring."&vi=".$vi."&amp;pg=".strval($i); ?>')">
				<span class="<?php if($toonalles==1){echo "small";} ?>aapagetellerpas"><font class="nullen">0</font><?php if ($i<100 and $PageCount>=100){ ?><font class="nullen">0</font><?php }if ($i<10 and $PageCount>=10){ ?><font class="nullen">0</font><?php }if ($i==$CurrentPage){ ?><span class="<?php if($toonalles==1){echo "small";} ?>aapagetelleract"><b><?php echo $i; ?></b></span><?php }else{echo $i;} ?></span>
				</a>
				<?php
			} ?>
		</td><td width="30">
			&nbsp;
			<?php if ($CurrentPage<$PageCount){ ?>
				<a class="handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('<?php echo $paramstring."&vi=".$vi."&amp;pg=".strval(($CurrentPage+1)); ?>')">
				<img class="vmidden" alt="" border="0" src="<?php echo $basis; ?>images/pijl-rechts-aa.png" width="20" height="21"></a>
				<?php
			}else{ ?>
				<img class="vmidden" alt="" src="<?php echo $basis; ?>images/pijl-rechts-grijs-aa.png" width="20" height="21">
				<?php
			}
		} ?>
		</td>
	</tr></table>
	<table class="dispinline layoutfixed" style="float:right;"><tr>
	<td width="10"></td>
	<td height="28">
	<?php
	if($navpos==1){ ?>
	<font class="tekst4">
	<?php
	$lijn=0;
	if (strlen($archiefnr)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $archiefnr;
	}
	if (strlen($mapnr)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $mapnr;
	}
	if (strlen($r)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $r;
	}
	if (strlen($m)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $m;
	}
	if (strlen($w)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $w;
	}
	if (strlen($a)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $a; if ($a=="Onbekend"){echo " (Auteur)";}
	}
	if (strlen($u)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $u; if ($u=="Onbekend"){echo " (Bron)";}
	}
	if (strlen($s)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		echo $s;
	}
	if (strlen($j)>0 or strlen($j2)>0 or strlen($j3)>0 or strlen($j4)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		if (strlen($j)>0 and strlen($j2)==0){
			echo "* vanaf&nbsp;".$j;
		}elseif (strlen($j)>0 and strlen($j2)>0){
			echo $j."&nbsp;t/m&nbsp".$j2;
		}else{
			echo "t/m&nbsp".$j2."&nbsp;";
		}
		if (strlen($j3)>0 and strlen($j4)==0){
			echo "+ vanaf&nbsp;".$j3;
		}elseif (strlen($j3)>0 and strlen($j4)>0){
			echo $j3."&nbsp;t/m&nbsp".$j4;
		}else{
			echo "t/m&nbsp".$j4;
		}
	}
	if (strlen($z)>0){
		if ($lijn==1){ ?>&nbsp;&#8226;&nbsp;<?php }else{$lijn=1;}
		if ($googlewoord==false){echo $zorig;}else{echo $z;}
	} ?>
	&nbsp;[<?php echo $aantalrecords; ?>]</font>
	<?php
	}
	else { ?>
		<button class="ggbutton" title="Ga naar het begin van de resultaat lijst" onclick="$('body,html').animate({scrollTop: $('#top').offset().top},400);">TOP</button>&nbsp;
	<?php
	}
	?>
	</td>
	</tr></table>
</td></tr></table>
</div>

