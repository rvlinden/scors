<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";
//check of is ingelogd
if ($rechten!="mo" and $rechten!="sup"){exit();}

$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsboeklog.txt";
$Key="";$zin="";$veld="";
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/boeken.mdb","","");

function diak($inputString) {
    // Replace diacritical characters for single-byte characters
    $replaceTable = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
        'Å'=>'A', 'Æ'=>'Ae', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
        'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
        'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O',
        'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'Th',
        'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
        'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e',
        'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i',
        'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n', 'ò'=>'o',
        'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o',
        'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y',
        'þ'=>'th', 'ÿ'=>'y', '"'=>'', "'"=>''
    );
    $inputString=strtr($inputString, $replaceTable);
	iconv('UTF-8', 'ASCII//TRANSLIT', $inputString);
	// verwijder ongeldige karakters in de inputstring
	$karyes="_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?+-1234567890#.,/()= :";
	for ($i=0;$i<strlen($inputString);$i++){
		$hulp=substr($inputString,$i,1);
		if (strpos($karyes, $hulp)===false){
			$inputString=str_replace($hulp," ",$inputString);
		}
	}
	$inputString=trim(str_replace("  "," ",$inputString));
    return $inputString;
}

// Lees de aktie die moet worden uitgevoerd: 
// editboek,delboek,nieuwboek: update gegevens van boekenlijst
$aktie=$_REQUEST["aktie"];
// Lees het record dat moet worden aangepast
if(isset($_REQUEST["Key"])){
	$Key=strval($_REQUEST["Key"]);
	$fprs=odbc_exec($objConnect,"SELECT * FROM boeken WHERE Key = ".$Key);
	$row = odbc_fetch_array($fprs);
	$titel=$row["Titel"];
}
if(isset($_REQUEST["veld"])){$veld=strval($_REQUEST["veld"]);}
if(isset($_REQUEST["term"])){$term=$_REQUEST["term"];}

if($aktie!=="vulnamen"){ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>
<font style="font-size:9pt;">
<?php }


// Voer de gevraagde aktie uit en maak een zin voor de logfile
if ($aktie=="editboek"){
	$veldnaam=$_REQUEST["veldnaam"];
	$fieldcontent=diak($_REQUEST["veldinhoud"]);
	$fprs=odbc_exec($objConnect,"UPDATE boeken SET tse=".strval($diffSeconds).",aanpasser='".$user."',".$veldnaam."='".$fieldcontent."' WHERE Key = ".$Key);
	$zin="Boek indexnr ".$Key.", titel ".$titel.", ".$veldnaam." aangepast naar ".$fieldcontent;
	odbc_free_result($fprs);
}else if ($aktie=="delboek"){
	$fprs=odbc_exec($objConnect,"DELETE FROM boeken WHERE Key = ".$Key);
	error_reporting(0);
	$naamfile="BB/".strval($Key).".jpg";unlink($naamfile);
	$naamfile="BB/".strval($Key).".pdf";unlink($naamfile);
	$naamfile="BB/".strval($Key)."ga.jpg";unlink($naamfile);
	error_reporting(-1);
	$zin="Boek indexnr ".$Key.", titel ".$titel.", verwijderd";
	odbc_free_result($fprs);
}else if ($aktie=="nieuwboek"){
	$fprs=odbc_exec($objConnect,"INSERT INTO boeken (titel,auteur,uitgever,jaar,opm,toevoeger,ts,tse) VALUES ('___nieuw___','','','','','".$user."',".strval($diffSeconds).",".strval($diffSeconds).")");
	odbc_free_result($fprs);
	$zin="Nieuw boek toegevoegd";
}else if ($aktie=="vulnamen"){
	$fprs=odbc_exec($objConnect, "SELECT DISTINCT ".$veld." FROM boeken WHERE ".$veld." like '%".$term."%' ORDER BY ".$veld." ASC");
	//Retourneer het resultaat in de vorm ["<resultaat1>","<resultaat2>","<enz.>"]
	$i=0;
	echo "[";
	while($row = odbc_fetch_array($fprs)){
	    if($i==1){echo ",";}
		echo chr(34).$row[$veld].chr(34);
		$i = 1;
	}
	echo "]";
}
// Close connection
unset($fprs);
odbc_close($objConnect);
unset($objConnect);

if($aktie!=="vulnamen"){
	// Update logfile
	//		error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	$zin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$_COOKIE["user"]." ".$zin.chr(13).chr(10);
	fwrite($oTextFile,$zin);
	fclose($oTextFile);
	//		error_reporting(-1);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsboeklog_".$zinDate."_".$zinTime.".txt";
		echo "<br>Log recycled: ".$newname;
		rename ($logfile,$newname);
	}
}
if ($aktie=="nieuwboek"){ 
// Roep index.php aan (toont het nieuw aangemaakte record bovenaan)
?>
	<script language="JavaScript">location.href="index.php?av=bb";</script>
<?php
}
if($aktie!=="vulnamen"){ ?>
<input type="hidden" id="resultaat" value="OK">
</body></html>
<?php
} ?>
