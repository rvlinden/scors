<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

if(isset($_REQUEST["aktie"])){$aktie=$_REQUEST["aktie"];}

//Haal alternatieve veldnamen op
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
$fprs=odbc_exec($defConnect,"SELECT * FROM velden ORDER BY Key ASC");
$veldalt=array_fill(0,5,"");
$veldorg=array_fill(0,5,"");
while($row=odbc_fetch_array($fprs)){$veldalt[$row["Key"]]=$row["veldalt"];$veldorg[$row["Key"]]=$row["velden"];}
if(strlen($veldalt[1])>0){$veldrnaam=$veldalt[1];}else{$veldrnaam=$veldorg[1];}
if(strlen($veldalt[2])>0){$veldwnaam=$veldalt[2];}else{$veldwnaam=$veldorg[2];}
if(strlen($veldalt[3])>0){$veldmnaam=$veldalt[3];}else{$veldmnaam=$veldorg[3];}
if(strlen($veldalt[4])>0){$veldunaam=$veldalt[4];}else{$veldunaam=$veldorg[4];}
if(strlen($veldalt[5])>0){$veldanaam=$veldalt[5];}else{$veldanaam=$veldorg[5];}
unset($fprs);
odbc_close($defConnect);
unset($defConnect);

if (($rechten=="mo" or $rechten=="sup") and $aktie!=="sct"){ 
	if ($aktie=="preview"){
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
		if(isset($_REQUEST["Key"])){$Key=strval($_REQUEST["Key"]);}
		$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key=".$Key);
		$fp_rs=odbc_fetch_array($fprs);
		$thumbsmap="AAT";
		$archiefnr=$fp_rs["archiefnr"];
		$diffSeconds=$fp_rs["ts"];
		$opvoerdatum=date("d M Y",$diffSeconds);
		$ediffSeconds=$fp_rs["tse"];
		$wijzigdatum=date("d M Y",$ediffSeconds);
		$itemtitle=$fp_rs["itemtitle"];
		$persoon=$fp_rs["persoon"];
		$persoon2=$fp_rs["persoon2"];
		$soort1=$fp_rs["soort1"];
		$bron1=$fp_rs["bron1"];$bron2=$fp_rs["bron2"];$bron3=$fp_rs["bron3"];
		$auteur1=$fp_rs["auteur1"];$auteur2=$fp_rs["auteur2"];$auteur3=$fp_rs["auteur3"];
		$onderwerp1=$fp_rs["onderwerp1"];$onderwerp2=$fp_rs["onderwerp2"];$onderwerp3=$fp_rs["onderwerp3"];$onderwerp4=$fp_rs["onderwerp4"];
		$jaar=$fp_rs["jaar"];
		if($jaar=="X"){$jaar="";}
		$jaarmarge=$fp_rs["jaarmarge"];
		$maand="";$dag="";
		if (strlen($jaar)>0){
			$jaarhulp=explode("-",$jaar);
			$jaar=$jaarhulp[0];
			if (count($jaarhulp)>1){$maand=$jaarhulp[1];}
			if (count($jaarhulp)>2){$dag=$jaarhulp[2];}
		}
		$jaartekst=$jaar;$jaarmargetekst="";
		if (strlen($jaarmarge)>0){
			$jaarmargetekst="&nbsp;(+/- ".$jaarmarge." jr)";
			$maand="";$dag="";
		}elseif (strlen($jaar)==0){$jaartekst="Onbekend";} 
		$beschrijving=$fp_rs["beschrijving"];
		if (strlen($beschrijving)>0){$beschrijving=str_replace(chr(13).chr(10),"<br>",$beschrijving);}
		$mapnr=$fp_rs["mapnr"];
		$straat=$fp_rs["straat"];
		?>
												
		<table width="100%" style="border-color: red;" border="2" cellpadding="5" cellspacing="0" class="bcollapse layoutfixed" style="user-select: text;"><tr><td>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0" class="bcollapse layoutfixed" style="user-select: text;">
				<tr><td class="vtop">
					<?php
					$fotofile=array_fill(0, 13, '');$isfoto=array_fill(0, 13, false);
					for ($i=1;$i<=12;$i++){
						$fotofile[$i]=$fp_rs["foto".strval($i)];
						if(strlen($fotofile[$i])>0){$isfoto[$i]=true;}
					}
					for ($i=1;$i<=12;$i++){
						$thumbfile=$fp_rs["thumb".strval($i)];
						if ($isfoto[$i]){$thumbspath=$thumbsmap."/".substr(strval($thumbfile),0,3)."/".$thumbfile;} 
						if ($isfoto[$i]){ ?>
						<TABLE width="188" class="layoutfixed dispinline"><TR>
							<td height="3" width="2"></td>
							<td height="3" width="186" class="fotobg"></td>
							</tr><tr><td width="2" height="186"></td>
							<td width="186" class="vmidden fotobg">
							<div align="center">
								<img border="0" src="<?php echo $thumbspath; ?>">
							</div>
							</td></tr><tr><td height="2" width="2"></td><td height="2" width="186"></td>
						</TR></TABLE>							
						<?php
						}
					} ?>
				</td>
								
				<td rowspan="2" width="180" class="bgzoek" style="vertical-align:top;">
					<table style="padding:4px">
						<tr><td></td><td align="right"></td></tr><tr><td align="left" colspan="2">
						
							<font class="aatekst2">
							<?php if($jaartekst!==""){ ?><i>Datering:&nbsp;</i><br><?php } ?>
							<?php
							echo $jaartekst;
							if ($jaarmargetekst<>""){echo " ".$jaarmargetekst;}
							if ($maand<>""){ echo "-".$maand;}
							if ($dag<>""){ echo "-".$dag;}
							
							if ($onderwerp1.$onderwerp2.$onderwerp3.$onderwerp4<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldrnaam; ?>:</i><?php }
							if ($onderwerp1<>""){ ?><br><?php echo $onderwerp1; ?><?php }
							if ($onderwerp2<>""){ ?><br><?php echo $onderwerp2; ?><?php }
							if ($onderwerp3<>""){ ?><br><?php echo $onderwerp3; ?><?php }
							if ($onderwerp4<>""){ ?><br><?php echo $onderwerp4; ?><?php }
							
							if ($straat<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldwnaam; ?>: </i>
							<br><?php echo $straat; ?><?php }
							
							if ($persoon.$persoon2<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldmnaam; ?>: </i> <?php }
							if ($persoon<>""){ ?><br><?php echo $persoon; ?><?php }
							if ($persoon2<>""){ ?><br><?php echo $persoon2; ?><?php }

							if ($bron1.$bron2.$bron3<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldunaam; ?>:</i><?php }
							if ($bron1<>""){ ?><br><?php echo $bron1; ?><?php }
							if ($bron2<>""){ ?><br><?php echo $bron2; ?><?php }
							if ($bron3<>""){ ?><br><?php echo $bron3; ?><?php }
							
							if ($auteur1.$auteur2.$auteur3<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i><?php echo $veldanaam; ?>:</i><?php }
							if ($auteur1<>""){ ?><br><?php echo $auteur1; ?><?php }
							if ($auteur2<>""){ ?><br><?php echo $auteur2; ?><?php }
							if ($auteur3<>""){ ?><br><?php echo $auteur3; ?><?php }
							
							if ($soort1<>""){ ?><font class="aatekst0">&nbsp;<br><font class="aatekst2"><i>Soort:<br></i><?php echo $soort1; ?><?php } ?>
							
							<br><br><i>Archiefgegevens:</i>
							<font class="tekst2"><br>Archiefnr&nbsp;<font class="tekst2"><?php echo $archiefnr; ?></font><?php
							if ($mapnr<>""){ ?><br><font class="tekst2">Archiefmap&nbsp;<font class="tekst2"><?php echo $mapnr;} ?>
							<br><font class="tekst2">Toegevoegd&nbsp;op&nbsp;<?php echo $opvoerdatum; ?><br>
							
						</td></tr>
					</table>

					&nbsp;<input class="edf" type="button" value="editor" id="wisselpreview<?php echo $Key; ?>" onclick="preview('<?php echo $Key; ?>');" title="Wissel tussen editor en preview">&nbsp;<br><br>

				</td></tr><tr><td class="vtop" style="padding:3px;">
				
					<font class="itemtitle"><?php echo $itemtitle; ?></font>
					<font class="aatekst2"><br>
					<?php
					if (strlen($beschrijving)>0){
						while(strpos($beschrijving,"[[")!==false and strpos($beschrijving,"]]")!==false){
							$hulptekst=explode("[[",$beschrijving)[1];$anummer=explode("]]",$hulptekst)[0];
							if(strlen($anummer)==6 and strval($anummer)>100000 and strval($anummer)<999999){
								$beschrijving=str_replace('[[','<a class=handje onclick="if (event.ctrlKey){ctrltoets=true;};getcontainer(xqx?archiefnr='.$anummer.'&vi=li&topshiftxqx);">',$beschrijving);
							}else{
								$beschrijving=str_replace('[[','<a href="'.$anummer.'">',$beschrijving);
							}
							$beschrijving=str_replace(']]','</a>',$beschrijving);
						}
						$beschrijving=str_replace("xqx",chr(39),$beschrijving);
						echo $beschrijving;
					} ?>
					</font>
				
				</td></tr><tr>
					<td colspan="2" height="15"  style="background-image: url('images/lijn.png');"></td>
				</tr>
			</table>
		</td></tr></table>
	<?php
	}else if($aktie=="verwerkaanvul"){
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/aanvulling.mdb","","");
		$Key=$_REQUEST["Key"];
		$verwerkt=$_REQUEST["verwerkt"];
		$fprs=odbc_exec($objConnect,"UPDATE aanvul SET verwerkt='".$verwerkt."' WHERE Key=".$Key);
	}else if($aktie=="verwijderaanvul"){
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/aanvulling.mdb","","");
		$Key=$_REQUEST["Key"];
		$fprs=odbc_exec($objConnect,"DELETE FROM aanvul WHERE Key=".$Key);
	}else if($aktie=="ocrqueue"){
		$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
		echo "Tekstherkennings wachtrij:<br>";
		$bestanden=scandir("./ocr/");$aantal=0;
		foreach($bestanden as $bestand){
			if($bestand!=="." and $bestand!==".." and $bestand!=="out"){
				$bestandstype=strtolower(pathinfo($bestand,PATHINFO_EXTENSION));
				if (strpos("jpg pdf txt",$bestandstype)!==false){
					$aantal++;$rapport=$bestand;
					if(strpos($bestand,"-Jrg-")===false){
						$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE foto1&' '&foto2&' '&foto3&' '&foto4&' '&foto5&' '&foto6&' '&foto7&' '&foto8&' '&foto9&' '&foto10&' '&foto11&' '&foto12 like '%".$bestand."%'");
						$row=odbc_fetch_array($fprs);
						$rapport.=" (".$row["itemtitle"].")";
					}
					echo $rapport."<br>";
				}
			}
		}
		if($aantal==0){echo "Leeg";}
	}else{ ?>

		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
		<html><head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="author" content="Rob van Linden, R.F.J. van Linden">
		<title>Aanvullingen van bezoekers</title>
		<link rel="stylesheet" type="text/css" href="scors.css" /> 
		</head>

		<body>
		<div style="margin:20px 20px;"align="center" id="top">

			<?php
			//construeer de SQL string
			$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/aanvulling.mdb","","");
			$fp_sQry="SELECT * FROM aanvul ORDER BY Key DESC";
			$fp_sQryCount="SELECT COUNT(*) as aantal FROM aanvul";
			$kleur = "#ffffff";
			//Doe de query
			$fprs=odbc_exec($objConnect,$fp_sQryCount);
			$aantalrecords=0;
			if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];}
			if ($aantalrecords>0){ ?>
				Vink het 'verwerkt' hokje aan als de aanvulling is verwerkt bij het archiefitem. gebruik de <b>Del</b> knop om spam te verwijderen.
				<table id="bblijst" width="100%" class="bgzoek bcollapse" bordercolor="lightgrey" border="1" align="center" style="user-select: text;">
				
					<tr>
						<?php
						$kopjes =array("Nr","Verwerkt","Datum","Naam","Email","Archiefnr","Aanvulling","");
						foreach ($kopjes as $kopje){ ?>
							<td style="padding:4px;" bgcolor="#000000" class="geenwrap"><font color="#ffffff" ><?php echo $kopje; ?></font></td>
						<?php
						} ?>
					</tr>

					<?php
					$fprs=odbc_exec($objConnect,$fp_sQry);
					while($fp_rs=odbc_fetch_array($fprs)){ 
						$Key=$fp_rs["Key"];
						$verwerkt=$fp_rs["verwerkt"];
						$aanvulling=str_replace(chr(10),"",str_replace(chr(13)," ",$fp_rs["aanvulling"]));
						?>
						<tr class="regel<?php echo $Key; ?>">
							<td class="vmidden"  style="background-color:<?php echo $kleur; ?>;" align="left"><?php echo $Key; ?></td>
							<td class="vmidden  align="center" style="background-color:<?php echo $kleur; ?>;"><input type="checkbox" id="verwerkt<?php echo $Key; ?>" onclick="toggleverwerk('<?php echo $Key; ?>');" <?php if($verwerkt=="j"){echo " checked "; } ?>></td>
							<?php foreach (array("datum","naam","email","archiefnr") as &$veldnaam){ ?>
								<td class="vmidden"  style="background-color:<?php echo $kleur; ?>;" align="left"><?php echo $fp_rs[$veldnaam]; ?></td>								
							<?php
							} ?>
							<td class="vmidden"  style="background-color:<?php echo $kleur; ?>;" align="left"><?php echo $aanvulling; ?></td>
							<td align="center" style="background-color:<?php echo $kleur; ?>;" align="right"><input type="button" class="edf" value="del" title="Verwijder deze aanvulling" onclick="verwijderaanvul('<?php echo $Key; ?>','<?php echo $fp_rs["email"]; ?>');"></td>
						</tr>
						<?php
						if ($kleur=="#ffffff"){$kleur="#c9e3e8";}else{$kleur="#ffffff";}
					} ?>
					
				</table>
				<br>
				<div align="right"><button class="ggbutton" onclick="$('body,html').animate({scrollTop: $('#top').offset().top},400);">TOP</button></div>

			<?php
			}else{ ?>
				<br><br>Geen resultaten gevonden
			<?php
			} ?>
			<br><br>
			
		</div>
		</body>
		<script type="text/Javascript">
		function toggleverwerk(sleutel){
			doel=document.getElementById('verwerkt'+sleutel);
			var verwerkt='n';
			if (doel.checked){verwerkt='j';}else{verwerkt='n';}
			var url='aashowstatus.php?aktie=verwerkaanvul&Key='+sleutel+'&verwerkt='+verwerkt;
			var xmlhttp=new XMLHttpRequest();
			xmlhttp.open("GET",url,false);
			xmlhttp.send();
			var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
			return;}
		function verwijderaanvul(sleutel,tekst){
			var answer=confirm("Weet U zeker dat U aanvulling "+sleutel+" van "+tekst+" wilt verwijderen?");
			if (answer){
				var url='aashowstatus.php?aktie=verwijderaanvul&Key='+sleutel;
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.open("GET",url,false);
				xmlhttp.send();
				var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
				document.getElementsByClassName('regel'+sleutel)[0].style.display='none';
			}
			return;}
		</script>
		</html>
		<?php
	}

}else if($aktie=="sct"){
	
	//Verwijder niet toegestane karakters uit de input parameters
	//3 levels van strengheid
	function cleaninput($ipar, $level){
		$bloklijst1=array("'","<",">",";","]","[","{","}","%","-1");
		$bloklijst2=array("(",")",",");
		$bloklijst3=array(".","-","=");
		$acx=$ipar;
		foreach ($bloklijst1 as $letter){
			$hulp=strpos($acx,$letter);
			if ($hulp>0){$acx=substr($acx,0,$hulp-1);}
		}
		return $acx;
	}
	?>
	<hr>
	<table width="100%" border="0" cellpadding="10" cellspacing="0" class="bcollapse"><tr><td align="left">

	<?php
	$mailnaam=cleaninput($_REQUEST["mailnaam"],0);
	$mailfrom=cleaninput($_REQUEST["mailfrom"],0);
	$mailbody=cleaninput($_REQUEST["mailbody"],0);
	$archiefnr=cleaninput($_REQUEST["archiefnr"],0);
	$Key=cleaninput($_REQUEST["Key"],0);

	$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/aanvulling.mdb","","");
	$fprs=odbc_exec($objConnect,"INSERT INTO aanvul (naam,email,archiefnr,dbindex,datum,aanvulling,verwerkt) VALUES ('".$mailnaam."','".$mailfrom."','".$archiefnr."',".strval($Key).",'".$zinDate." ".$zinTime."','".$mailbody."','n')");
	unset($fprs);
	odbc_close($objConnect);
	unset($objConnect);

	//	Update textfile scorsaanvullog.txt
	$zinDate=date("Y-M-d");
	$zinTime=date("h.i.s");
	$zin=$zinDate." ".$zinTime." ip:".$_SERVER["REMOTE_ADDR"];
	$zin=$zin." Naam:".$mailnaam." Email:".$mailfrom." Archiefnr:".$archiefnr." DB-index:".$Key.chr(13).chr(10);
	//	error_reporting(0);
	error_clear_last();
	$oTextFile = fopen("log/scorsaanvullog.txt", "a");
	fwrite($oTextFile,$zin);
	fwrite($oTextFile,"Aanvulling: ".$mailbody.chr(13).chr(10));
	fwrite($oTextFile,"=======================/======================".chr(13).chr(10));
	fclose($oTextFile);
	//	error_reporting(-1);
	$e=error_get_last();
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsaanvullog ".$zinDate." ".$zinTime.".txt";
		rename ($logfile,$newname);
	}

	if($e==NULL){ ?>
		<font size="3"><b><i>Uw aanvulling is verstuurd en zal zo spoedig mogelijk worden verwerkt. Hartelijk dank!</i></b></font>
		<?php
	}else{ ?>
		Er is een fout opgetreden tijdens het versturen. Probeer het later opnieuw. Excuses voor het ongemak.
	<?php
	} ?>
	</td><td align="left">
		&nbsp;&nbsp;<button class="ggbutton" onclick="$('#meldresultaat<?php echo $Key; ?>').hide();$('#meldstart<?php echo $Key; ?>').show();">Sluit</button>
	</td></tr></table>
	
<?php
}
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
 ?>


