<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//redirect HTTP naar HTTPS
if (! isset($_SERVER['HTTPS']) or $_SERVER['HTTPS'] == 'off') {
    $redirect_url = "https://" . $_SERVER['HTTP_HOST'] . "/". $_SERVER['REQUEST_URI'];
    header("Location: $redirect_url");
    exit();
}
include_once('PHPMailer/src/PHPMailer.php');
include_once('PHPMailer/src/SMTP.php');
include_once('PHPMailer/src/Exception.php');

$lu="";$user="";$pass="";$onthoud="";$rechten="";$token="";$oww="";$nww1="";$fww=false;$resultaat="NOK";;

//lees parameters
if(isset($_COOKIE['logon'])){$rechten=$_COOKIE['logon'];}
if(isset($_COOKIE['user'])){$user=urldecode($_COOKIE['user']);}
IF(isset($_COOKIE['loginerror'])){$loginerror=$_COOKIE["loginerror"];}else{$loginerror=0;}
if(isset($_REQUEST["lu"])){$lu=$_REQUEST['lu'];}
if(isset($_REQUEST["user"])){$user=strtolower($_REQUEST["user"]);}
if(isset($_REQUEST["pass"])){$pass=$_REQUEST["pass"];}
if(isset($_REQUEST["onthoud"])){$onthoud=$_REQUEST["onthoud"];}
if(isset($_REQUEST["token"])){$token=$_REQUEST["token"];}
if(isset($_REQUEST["oww"])){$oww=$_REQUEST["oww"];}
if(isset($_REQUEST["nww1"])){$nww1=$_REQUEST["nww1"];}
if(isset($_REQUEST["fww"])){$fww=true;}

$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$sitenaam=$row["sitenaam"];
$basiskleur1=$row["basiskleur1"];
$basiskleur2=$row["basiskleur2"];
odbc_free_result($fprs);

if($lu=="lo"){ //Uitloggen

	setcookie('logon', null, 1, '/');
	setcookie('user', null, 1, '/');
	?>
	<script type="text/Javascript">location.href="index.php";</script>
	<?php

}else if ($lu=="aacww"){

	if(strlen($user)>0 and strlen($oww)>0 and strlen($nww1)>0){ //wijzig wachtwoord voor al ingelogde user
		$fprs=odbc_exec($defConnect,"SELECT * from users WHERE user='".$user."' ");
		$row = odbc_fetch_array($fprs);$hpw=$row['pass'];
		odbc_free_result($fprs);
		if (password_verify($oww,$hpw)){
			$hpw=password_hash($nww1,PASSWORD_DEFAULT);
			$fprs=odbc_exec($defConnect,"UPDATE users SET pass='".$hpw."' WHERE user='".$user."' ");
			$resultaat="OK";
			odbc_free_result($fprs);
		}		
	}else if(strlen($user)>0 and strlen($token)>0 and strlen($nww1)>0){ //zet wachtwoord voor user via link vanuit email voor vergeten password
		$fprs=odbc_exec($defConnect,"SELECT * from users WHERE user='".$user."' ");
		while($row = odbc_fetch_array($fprs)){
			$tokencheck=$row['token'];
			$ts=$row['ts'];
		}
		odbc_free_result($fprs);
		$now = new DateTime( 'NOW' );$tsnow = $now->getTimestamp();
		if($token!=$tokencheck or strlen($token)==0){$resultaat="Token-verificatie mislukt. Token is niet geldig.";}
		else if($token==$tokencheck and ($tsnow-$ts>=3600)){$resultaat="Token-verificatie mislukt. Token is meer dan 1 uur oud.";}
		else if($token==$tokencheck and ($tsnow-$ts<3600)){
			$hpw=password_hash($nww1,PASSWORD_DEFAULT);
			$fprs=odbc_exec($defConnect,"UPDATE users SET pass='".$hpw."' WHERE user='".$user."' ");
			$resultaat="OK";
			odbc_free_result($fprs);
		}
	}else if(strlen($user)>0 and $fww){ //stuur mail vanuit vergeten-wachtwoord-form
		if (filter_var($user, FILTER_VALIDATE_EMAIL)) {
			$fprs=odbc_exec($defConnect,"SELECT * from users WHERE user='".$user."' ");
			while ($row = odbc_fetch_array($fprs)){ //wordt alleen uitgevoerd als user bestaat
				$token = substr(md5(uniqid(rand(),1)),3,10);
				$now = new DateTime( 'NOW' );$ts = $now->getTimestamp();
				$fprs2=odbc_exec($defConnect,"UPDATE users SET token= '" . $token . "', ts=".$ts."  WHERE user = '" . $user. "' ");
				$fprs2=odbc_exec($defConnect,"SELECT * from settings");
				$settings=odbc_fetch_array($fprs2);
				$body='Er is een verzoek ontvangen om uw wachtwoord in te stellen voor '.$sitenaam.' (Wachtwoord vergeten).<br>';
				$body.='Indien u dit verzoek niet zelf heeft gedaan, negeer dan deze email. Uw wachtwoord wordt dan niet gewijzigd.<br><br>';
				$body.='Klik anders op onderstaande link om uw wachtwoord in te stellen:<br><br>';
				$body.='<a href="https://' . $_SERVER['HTTP_HOST'].'/logon.php?lu=fww&token='.$token.'&user='.$user.'">Wachtwoord instellen</a><br><br>';
				$mail = new PHPMailer\PHPMailer\PHPMailer();
				$mail->IsSMTP();
				$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
				$mail->Host = $settings["mailerHOST"];
				if($settings["mailerAUTH"]=="on"){$hulp="true";}else{$hulp="false";}
				$mail->SMTPAuth = $hulp;
				$mail->SMTPSecure = $settings["mailerSEC"];
				$mail->Username = $settings["mailerloginUID"];
				$mail->Password = $settings["mailerloginPASS"];
				$mail->Port = $settings["mailerPORT"];
				$mail->IsHTML(true);
				$mail->From = $settings["mailerFROM"];
				$mail->FromName = $settings["mailerFROMNAME"];
				$mail->Subject = "Wachtwoord opnieuw instellen voor " . $sitenaam;
				$mail->Body = $body;
				$mail->AddAddress($user);
				$mail->Send();
				$resultaat="(vergeten) ".$mail->ErrorInfo;
				odbc_free_result($fprs2);
			}
			odbc_free_result($fprs);
		}
	}
	echo $resultaat;
	if(strlen($token)>0 and !$fww){$resultaat.=" (vergeten)";}
	// Schrijf het event weg naar de logfile
	error_reporting(0);
	$oTextFile = fopen("log/scorslogonlog.txt", "a");
	fwrite($oTextFile,date("Y/M/d")." ".date("h:i:s")." ip:".$_SERVER["REMOTE_ADDR"]." user:".$user." wachtwoord aanpassen: ".$resultaat.chr(13).chr(10));
	fclose($oTextFile);
	error_reporting(-1);

	// Close connection
	odbc_close($defConnect);
	exit();

}else if (strlen($user)>0 and strlen($pass)>0){ //loginpoging

	$fprs=odbc_exec($defConnect,"SELECT * from users WHERE user='".$user."' ");
	$useris=false;$passis=false;
	while ($row = odbc_fetch_array($fprs)){
		$useris=true;
		if (password_verify($pass,$row['pass'])){ //inloggen gelukt
			$passis=true;
			$rechten=$row['rechten'];
			setcookie("logon", $rechten);
			if($onthoud=="X"){setcookie("user", $user,time()+60*60*24*365*10);}
			else{setcookie("user", $user);}
			setcookie("loginerror",0);
			// Schrijf het inlog-event weg naar de logfile
			error_reporting(0);
			$oTextFile = fopen("log/scorslogonlog.txt", "a");
			fwrite($oTextFile,date("Y/M/d")." ".date("h:i:s")." ip:".$_SERVER["REMOTE_ADDR"]." user:".$user.chr(13).chr(10));
			fclose($oTextFile);
			error_reporting(-1);
			?>
			<script type="text/Javascript">location.href="index.php";</script>
			<?php
		}
	}
	if (!$useris or !$passis){
		$loginerror=$loginerror+1;$lu="li";
		setcookie("loginerror", $loginerror, time()+300);  /* expire in 5 minutes */
		// Schrijf het inlog-event weg naar de logfile
		error_reporting(0);
		$oTextFile = fopen("log/scorslogonlog.txt", "a");
		fwrite($oTextFile,date("Y/M/d")." ".date("h:i:s")." ip:".$_SERVER["REMOTE_ADDR"]." user:".$user." loginerror".chr(13).chr(10));
		fclose($oTextFile);
		error_reporting(-1);
	}
	odbc_free_result($fprs);
	
}

odbc_close($defConnect);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="author" content="Rob van Linden, R.F.J. van Linden">
<title><?php echo $sitenaam; ?></title>
<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
<link rel="stylesheet" type="text/css" href="scors.css" /> 
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
</head>

<body class="archiefbody">

<?php
if(strlen($lu)>0){ ?>
	<br><br>
	<div style="max-width:1055px;margin:auto;background-color:#FFFFFF; border-color:#afafaf;border-left-width:0px; border-right-width:0px; border-top-style:solid; border-top-width:2px; border-bottom-width:0px;">

		<!-- KOP EN NAVIGATIE-->

		<table border="0" class="bcollapse" cellpadding="0" cellspacing="0" width="100%"><tr><td width="125" align="right">
		<img src="images/logoscors.png" valign="top" height="25">
		</td><td align="left"><H3>&nbsp;&nbsp;<i><?php echo $sitenaam; ?></i>&nbsp;&nbsp;</H3>
		</td></tr></table>

		<!-- LOGON BLOK -->
	
		<?php
		if($lu=="cww" and strlen($rechten)>0){ //Wachtwoord aanpassen
			
			?>
			<div align="center">
				<p>&nbsp;</p><p>&nbsp;</p>
				<table><tr>
					<td>
						<img src="images/aanmelden.jpg" alt="" width="65" height="45" align="center">
					</td><td>
						<h1><span style="color: var(--basiskleur2);">Wachtwoord wijzigen voor <?php echo $user; ?></span></h1>
					</td>
				</tr></table>
				<p>&nbsp;</p>
				<form action="logon.php?lu=cww" method="post" id="cww">
				<input type="hidden" value="<?php echo $user; ?>" name="user" id="user">
				<table cellspacing="7" cellpadding="7" style="border-collapse: collapse" width="534">
				<tr>
					<td align="right" class="geenwrap">
					  <font face="Arial">Oud wachtwoord:&nbsp;&nbsp;</font>
					</td><td>
					  <input type="password" name="oww" id="oww" class="pass" value="">
					</td><td width="150" align="right">
					  <input class="ggbutton" type="button" value="OK" onclick="checknewpassword();"><br><br>
					</td>
				</tr><tr>
					<td align="right" class="geenwrap">
					  <font face="Arial">Nieuw wachtwoord:&nbsp;&nbsp;</font>
					</td><td>
					  <input type="password" name="nww1" id="nww1" class="pass" value="">
					</td><td align="right">
					</td>
				</tr><tr>
					<td align="right" class="geenwrap">
					  <font face="Arial">Herhaal nieuw wachtwoord:&nbsp;&nbsp;</font>
					</td><td class="geenwrap">
					  <input type="password" name="nww2" id="nww2" class="pass" value="">&nbsp;<img id="spw" src="images/spw.png" onclick="showpw();" class="vmidden" style="margin:0px 0px 5px 0px;">
					</td><td align="right">
					  <input type="button" class="ggbutton" value="Afbreken" onclick="location.href='index.php';";>
					</td>
				</tr></table>
					<div id="wwsucces" name="wwsucces" style="display:none;"><b>Wachtwoord succesvol aangepast. U kunt nu <a href="logon.php?lu=li">inloggen</a></b></div
				</form>
			</div>
			<p>&nbsp;</p><p>&nbsp;</p>
			<?php
			
		}else if($lu=="li"){
			
			if ($loginerror<7){ //inloggen 
			?>
				<div align="center">
					<p>&nbsp;</p><p>&nbsp;</p>
					<table><tr><td>
						<img src="images/aanmelden.jpg" alt="" width="65" height="45" align="center">
					</td><td>
						<h1><span style="color: var(--basiskleur2);">Inloggen</span></h1>
					</td></tr></table>
					<p>&nbsp;</p>
					<form action="logon.php?lu=li" method="post">
					<table cellspacing="7" cellpadding="7" style="border-collapse: collapse" width="534">
					<tr><td align="right">
						  <font face="Arial">Gebruikersnaam:&nbsp;&nbsp;</font>
						</td><td>
						  <input type="text" name="user" value="">
						</td><td width="150" align="right">
						  <input class="ggbutton" type="submit" name="cmdLogin" value="Inloggen"><br><br>
					</td></tr><tr><td align="right">
						  <font face="Arial">Wachtwoord:&nbsp;&nbsp;</font>
						</td><td>
						  <input type="password" name="pass" id="pass" class="pass" value="">&nbsp;
						  <img id="spw" src="images/spw.png" onclick="showpw();" class="vmidden" style="margin:0px 0px 5px 0px;">
						</td><td align="right">
							<input type="button" class="ggbutton" value="Afbreken" onclick="location.href='index.php';";>
					</td></tr><tr><td align="right">
						  <font face="Arial">Onthoud&nbsp;</font>
						</td><td  colspan="2">
						  <input type="checkbox" name="onthoud" value="X">
					</td></tr><tr><td align="center"  colspan="3">
						  <a class="geendeco linkfooter" href="logon.php?lu=fww"><font face="Arial">Wachtwoord vergeten?</font></a>
					</td></tr>
					</table>
					</form>
					<?php
					if($loginerror>0){
						echo "<br><br>Inloggen mislukt. Probeer opnieuw (nog ".strval(7-$loginerror)." pogingen over)<br><br>";
					}else{
						echo "<p>&nbsp;</p><p>&nbsp;</p>";
					} ?>
				</div>
				<?php
			} else if ($loginerror>=7){ //teveel mislukte inlogpogingen
				?>
				<div align="center">
					<p>&nbsp;</p><p>&nbsp;</p>
					<table><tr><td>
						<img src="images/aanmeldenblocked.jpg" alt="" width="65" height="45" align="center">
					</td><td>
						<h1><span style="color: var(--basiskleur2);">Inloggen geblokkeerd gedurerende 5 minuten</span></h1>
					</td></tr></table>
					<p>&nbsp;</p>
				</div>
			<?php
			}
			
		}else if ($lu=="fww"){ //wachtwoord vergeten
		
			if ($token==""){ //vanuit login scherm
			?>
				<div align="center">
					<p>&nbsp;</p><p>&nbsp;</p>
					<table><tr><td>
						<img src="images/aanmelden.jpg" alt="" width="65" height="45" align="center">
					</td><td>
						<h1><span style="color: var(--basiskleur2);">Wachtwoord vergeten</span></h1>
					</td></tr></table>
					<p>&nbsp;</p>
					<table cellspacing="7" cellpadding="7" style="border-collapse: collapse" width="534"><tr><td align="right" class="geenwrap">
					  <font face="Arial">Email adres:&nbsp;&nbsp;</font>
					</td><td>
					  <input type="text" name="fwwuser" id="fwwuser" value="">
					</td><td width="150" align="right">
					  <input class="ggbutton" type="button" value="OK" onclick="checkemail();">&nbsp;&nbsp;
					  <input type="button" class="ggbutton" value="Afbreken" onclick="location.href='index.php';";>
					</td></tr></table>
					<br><br>
					<div id="fwwsucces" name="fwwsucces" style="display:none;"><b>Als dit email adres bekend is heeft u een mail ontvangen met een link waarmee u uw wachtwoord kunt instellen</b></div>
				</div>
				<p>&nbsp;</p><p>&nbsp;</p>
			<?php
			}else if(strlen($token)>0){ //vanuit email geklikt op wachtwwoord-vergeten-link
			?>
				<div align="center">
					<p>&nbsp;</p><p>&nbsp;</p>
					<table><tr><td>
						<img src="images/aanmelden.jpg" alt="" width="65" height="45" align="center">
					</td><td>
						<h1><span style="color: var(--basiskleur2);">Wachtwoord instellen voor <?php echo $user; ?></span></h1>
					</td></tr></table>
					<p>&nbsp;</p>
					<input type="hidden" value="<?php echo $user; ?>" name="user" id="user">
					<input type="hidden" value="<?php echo $token; ?>" name="token" id="token">
					<table cellspacing="7" cellpadding="7" style="border-collapse: collapse" width="534"><tr><td align="right" class="geenwrap">
					  <font face="Arial">Nieuw wachtwoord:&nbsp;&nbsp;</font>
					</td><td>
					  <input type="password" name="nww1" id="nww1" class="pass" value="">
					<td rowspan="2" width="150" align="right">
					  <input class="ggbutton" type="button" value="OK" onclick="checkinitpassword();"><br><br>
					</td></tr><tr><td align="right" class="geenwrap">
					  <font face="Arial">Herhaal nieuw wachtwoord:&nbsp;&nbsp;</font>
					</td><td class="geenwrap">
					  <input type="password" name="nww2" id="nww2" class="pass" value="">&nbsp;<img id="spw" src="images/spw.png" onclick="showpw();" class="vmidden" style="margin:0px 0px 5px 0px;">
					</td></tr></table>
					<div id="iwwsucces" name="iwwsucces" style="display:none;"><b>Wachtwoord succesvol aangepast. U kunt nu <a href="logon.php?lu=li">inloggen</a>.</b></div>
				</div>
				<p>&nbsp;</p><p>&nbsp;</p>
			<?php
			}
		} ?>
	
		<!-- FOOTER -->		
				
		<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td>
			<br>
			<div align="right"><font size="1">SCORS Authenticatie&nbsp;&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font></div>
		</td></tr></table>
	</div>

<?php
} ?>
		
<script type="text/Javascript">
function showpw() { 
	var x = document.getElementsByClassName("pass");
	var ximg=document.getElementById("spw");
	for(i=0;i<x.length;i++){
		if (x[i].type === "password") {x[i].type = "text";ximg.src="images/spwnot.png";} else {x[i].type = "password";ximg.src="images/spw.png";}
	}
	return;} 
function checknewpassword(){
		var oww=$('#oww').val();var nww1=$('#nww1').val();var nww2=$('#nww2').val();var user=$('#user').val();
		if(nww1!=nww2){alert("Nieuwe wachtwoorden niet gelijk aan elkaar");return;}
		if(nww1==nww2){
			var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET","logon.php?lu=aacww&user="+user+"&oww="+oww+"&nww1="+nww1,false);xmlhttp.send();
			var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
			var resultaat=xmlhttp.responseText;
			if(resultaat=="OK"){$('#wwsucces').show();}
			else if(resultaat=="NOK" || resultaat==""){alert("Ongeldig oud wachtwoord");}
		}
	return;}
function checkinitpassword(){
		var token=$('#token').val();var nww1=$('#nww1').val();var nww2=$('#nww2').val();var user=$('#user').val();
		if(nww1!=nww2){alert("Nieuwe wachtwoorden niet gelijk aan elkaar");return;}
		if(nww1==nww2){
			var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET","logon.php?lu=aacww&user="+user+"&token="+token+"&nww1="+nww1,false);xmlhttp.send();
			var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
			var resultaat=xmlhttp.responseText;
			if(resultaat=="OK"){$('#iwwsucces').show();}
			else {alert(resultaat);}
		}
	return;}
function checkemail(){
		var fwwuser=$('#fwwuser').val();
		if(fwwuser.indexOf("@")==-1 || fwwuser.indexOf(".")==-1){alert("Ongeldig email adres");return;}
		else{
			var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET","logon.php?lu=aacww&user="+fwwuser+"&fww=1",false);xmlhttp.send();
			var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
			$('#fwwsucces').show();
		}
	return;}
</script>

</body></html>