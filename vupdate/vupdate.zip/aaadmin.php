<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$aktie=$_REQUEST["aktie"];
$kidx="";if(isset($_REQUEST["kidx"])){$kidx=$_REQUEST["kidx"];}
if ($rechten!=="mo" and $rechten!=="sup" and $aktie!=="ocrimport"){exit();}

$dirslash="/";
$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsbeeldlog.txt";
$Key="";$zin="";$logzin="";
$correctedresult="";$ongeldig="";$archiefnr="";
$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Check handmatige of automatische archiefnummering
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$hoofdnum=$row["hoofdnum"];

function diak($inputString) {
	global $ongeldig;
	$onthou=$inputString;
    // Replace diacritical characters for single-byte characters
    $replaceTable = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
        'Å'=>'A', 'Æ'=>'Ae', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
        'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
        'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O',
        'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'Th',
        'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
        'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e',
        'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i',
        'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n', 'ò'=>'o',
        'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o',
        'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y',
        'þ'=>'th', 'ÿ'=>'y', '"'=>'', "'"=>''
    );
    $inputString=strtr($inputString, $replaceTable);
	iconv('UTF-8', 'ASCII//TRANSLIT', $inputString);
	// verwijder ongeldige karakters in de inputstring
	$karyes="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?+-1234567890#.,/()= :";
	for ($i=0;$i<strlen($inputString);$i++){
		$hulp=substr($inputString,$i,1);
		if (strpos($karyes, $hulp)===false){
			$inputString=str_replace($hulp," ",$inputString);
		}
	}
	if($onthou!=$inputString){$ongeldig=true;}
	$inputString=trim(str_replace("  "," ",$inputString));
    return $inputString;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>
<font style="font-size:9pt;">
<?php
// Lees de aktie die moet worden uitgevoerd: 
// delfile: verwijder een foto
// delrec: verwijder een compleet record
// fieldupdate: wijzig de inhoud van een recordveld in de database; bij deze aktie wordt de veldnaam (realfield) en de nieuwe inhoud (fieldcontent) ook als parameter meegegeven
// ruil: verwissel twee foto's van plaats; bij deze aktie wordt het sourcelocatienummer en sleutel (srcnr, Key) en destinationlocatienummer en sleutel (destnr, Keydest) ook als parameter meegegeven
// newrec: maak een nieuw leeg record aan
// copyrec: maak een nieuw record aan op basis van een kopie van een bestaand record
// ocradd: ocr jpg, pdf of txt

// Lees het record dat moet worden aangepast
if(isset($_REQUEST["Key"])){$Key=strval($_REQUEST["Key"]);}
if ($Key<>""){
	$keydir=substr($Key,0,3);
	$afbdir="AAD".$dirslash.$keydir.$dirslash;
	$thumbsdir="AAT".$dirslash.$keydir.$dirslash;
	$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key=".strval($Key));
	$row = odbc_fetch_array($fprs);
	if($row){$archiefnr=$row["archiefnr"];}
}

// Pas veldinhoud in record aan
function veldupdate($veldnaam,$veldinhoud,$sleutelnr){
	global $objConnect;
	$fprs=odbc_exec($objConnect,"UPDATE archief SET " . $veldnaam . " = '" . $veldinhoud . "'  WHERE Key = " . $sleutelnr);
	$lijst=substr($veldnaam,0,3);
	if($lijst=="str"){
		$fprs=odbc_exec($objConnect,"DELETE FROM wlist WHERE straten='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO wlist (straten,doel) VALUES ('".$veldinhoud."','e')");
	}
	else if($lijst=="per"){
		$fprs=odbc_exec($objConnect,"DELETE FROM plist WHERE personen='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO plist (personen,doel) VALUES ('".$veldinhoud."','e')");
	}
	else if($lijst=="bro"){
		$fprs=odbc_exec($objConnect,"DELETE FROM ulist WHERE bronnen='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO ulist (bronnen,doel) VALUES ('".$veldinhoud."','e')");
	}
	else if($lijst=="ond"){
		$fprs=odbc_exec($objConnect,"DELETE FROM rlist WHERE onderwerpen='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO rlist (onderwerpen,doel) VALUES ('".$veldinhoud."','e')");
	}
	else if($lijst=="aut"){
		$fprs=odbc_exec($objConnect,"DELETE FROM alist WHERE auteurs='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO alist (auteurs,doel) VALUES ('".$veldinhoud."','e')");
	}
	else if($lijst=="map"){
		$fprs=odbc_exec($objConnect,"DELETE FROM mlist WHERE mapnrs='".$veldinhoud."'");
		$fprs=odbc_exec($objConnect,"INSERT INTO mlist (mapnrs,doel) VALUES ('".$veldinhoud."','e')");
	}
}

function zoekmappen($naamvanfile){
	global $afbdir,$keydir,$dirslash,$thumbsdir;
	$keydir=substr($naamvanfile,0,3);
	$afbdir="AAD".$dirslash.$keydir.$dirslash;
	$thumbsdir="AAT".$dirslash.$keydir.$dirslash;
}

$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();
$erisdelta=false;

// Voer de gevraagde aktie uit en maak een zin voor de logfile
if ($aktie=="checknr"){
	$fprs=odbc_exec($objConnect,"SELECT COUNT(*) as aantal FROM archief WHERE Key<>".$Key." AND archiefnr='" . strval($_REQUEST["archiefnr"]) . "' ");
	$row = odbc_fetch_array($fprs);
	if ($row['aantal']==0){echo "OK";}
	odbc_free_result($fprs);
}elseif ($aktie=="ocradd"){
	$filenummer=strval($_REQUEST["nr"]);
	$veldnaamfile=$row['foto'.$filenummer];zoekmappen($veldnaamfile);
	//plaats de Key/nr/filenaam combinatie in de OCR-queue
	copy ($afbdir.$veldnaamfile,"ocr/".$veldnaamfile);
	$zin="Foto/document ".$Key." nr ". $filenummer." in OCR queue geplaatst";
	$logzin=$zin;
}elseif ($aktie=="copyrec" or $aktie=="newrec"){
	$erisdelta=true;
	$archiefnr="";
	if($hoofdnum=="A"){ //vind een vrij archiefnummer
		// Lees alle archiefnummers
		$sql="SELECT archiefnr FROM archief UNION SELECT foto1arch FROM archief UNION SELECT foto2arch FROM archief UNION SELECT foto3arch FROM archief UNION SELECT foto4arch FROM archief UNION SELECT foto5arch FROM archief UNION SELECT foto6arch FROM archief UNION SELECT foto7arch FROM archief UNION SELECT foto8arch FROM archief UNION SELECT foto9arch FROM archief UNION SELECT foto10arch FROM archief UNION SELECT foto11arch FROM archief UNION SELECT foto12arch FROM archief ORDER BY archiefnr ASC";
		$fprs=odbc_exec($objConnect,$sql);
		// Zoek een vrij archiefnummer
		$gevonden=false;
		$vorignummer=99999;
		while ($gevonden==false and $row = odbc_fetch_array($fprs)){
			$testnummer=intval($row['archiefnr']);
			if ($testnummer-$vorignummer>1 and $vorignummer>0) {	
				$gevonden=true;
			}else{
				$vorignummer=$testnummer;
			}
		}
		$archiefnr=strval($vorignummer+1);
		odbc_free_result($fprs);
	}
	// Lees alle Indexnummers in
	$fprs=odbc_exec($objConnect,"SELECT Key FROM archief ORDER BY Key ASC");
	// Zoek een vrij Indexnummer
	$gevonden=false;
	$vorignummer=99999;
	while ($gevonden==false and $row = odbc_fetch_array($fprs)){
		$testnummer=intval($row['Key']);
		if ($testnummer-$vorignummer>1 and $vorignummer>0) {	
			$gevonden=true;
		}else{
			$vorignummer=$testnummer;
		}
	}
	$vrijnummer=$vorignummer+1;
	odbc_free_result($fprs);
	// Maak een nieuw record aan en vul de velden met de waardes van het ingelezen record (copy) of vaste waarden (new)
	// Initieel blijft het nieuwe record hidden voor bezoekers en krijgt het de titel NIEUWOBJECT
	$veldnamen="Key,ts,tse,archiefnr";
	$veldwaarden=strval($vrijnummer).",".strval($diffSeconds).",".strval($diffSeconds).",'".$archiefnr."'";
	if ($aktie=="copyrec"){
		$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key = " . $Key);
		$row=odbc_fetch_array($fprs);
		$veldnamen.=",persoon,persoon2,soort1,bron1,bron2,bron3,onderwerp1,onderwerp2,onderwerp3,onderwerp4,auteur1,auteur2,auteur3,jaar,jaarmarge,datsort,straat,mapnr";
		$veldwaarden.=",'".$row['persoon']."','".$row['persoon2']."','".$row['soort1']."','".$row['bron1']."','".$row['bron2']."','".$row['bron3']."','".$row['onderwerp1']."','".$row['onderwerp2']."','".$row['onderwerp3']."','".$row['onderwerp4']."','".$row['auteur1']."','".$row['auteur2']."','".$row['auteur3']."','".$row['jaar']."','".$row['jaarmarge']."','".$row['datsort']."','".$row['straat']."','".$row['mapnr']."'";
		odbc_free_result($fprs);
	}else{
		$veldnamen.=",jaar,mapnr,soort1";
		$veldwaarden.=",'X','n.v.t.','Document'";
	}
	$sql="INSERT INTO archief (".$veldnamen.") VALUES (".$veldwaarden.")";
	$fprs2=odbc_exec($objConnect,$sql);
	$zin="Nieuw object aangemaakt. Database index #".strval($vrijnummer);
	$logzin=$zin;
}elseif ($aktie=="delfile"){
	$filenummer=strval($_REQUEST["nr"]);
	// Lees de bestandsnamen van het record en Key in
	error_reporting(0);
	$veldnaamfile=$row['foto'.$filenummer];zoekmappen($veldnaamfile);
	$naamfile=$afbdir.$veldnaamfile;
	unlink($naamfile);
	$veldnaamthumb=$row['thumb'.$filenummer];zoekmappen($veldnaamthumb);
	$naamfile=$thumbsdir.$veldnaamthumb;
	unlink($naamfile);
	error_reporting(-1);
	$kidx=substr($veldnaamfile,0,13);
	$fprs=odbc_exec($objConnect,"DELETE FROM ocr WHERE kidx='".$kidx."'"); 
	odbc_free_result($fprs);
	veldupdate("foto".$filenummer , "" , $Key);
	veldupdate ("thumb".$filenummer , "" , $Key);
	veldupdate("foto".$filenummer."arch" , "" , $Key);
	$zin=" File ".$filenummer." verwijderd van #".($Key);
	$logzin=$zin;
}elseif ($aktie=="delrec"){
	$erisdelta=true;
	error_reporting(0);
	$oudarchiefnr=$row["archiefnr"];
	for($i==1;$i<=12;$i++){
		$veldnaamfile=$row['foto'.$filenummer];zoekmappen($veldnaamfile);
		$naamfile=$afbdir.$veldnaamfile;
		unlink($naamfile);
		$veldnaamthumb=$row['thumb'.$filenummer];zoekmappen($veldnaamthumb);
		$naamfile=$thumbsdir.$veldnaamthumb;
		unlink($naamfile);
	}
	error_reporting(-1);
	$fprs=odbc_exec($objConnect,"DELETE FROM archief WHERE Key = ".$Key);
	odbc_free_result($fprs);
	// reset Dubbel-veld indien van toepassing
	$fprs=odbc_exec($objConnect,"SELECT COUNT(*) AS aantal FROM archief WHERE archiefnr='".strval($oudarchiefnr)."'");
	if (array_key_exists("aantal",$row)){
		if ($row['aantal']<2) { //geen dubbele meer
			$fprs=odbc_exec($objConnect,"UPDATE archief SET dubbel='' WHERE archiefnr='".strval($oudarchiefnr."'"));
		}
	}
	odbc_free_result($fprs);	
	//verwijder eventuele OCR teksten
	$fprs=odbc_exec($objConnect,"DELETE FROM ocr WHERE kidx like '".strval($Key)."%'");
	$zin="Object verwijderd (database index #".$Key.")";
	$logzin=$zin;
}elseif ($aktie=="ruil"){
	$srcnr=strval($_GET["srcnr"]);
	$destnr=strval($_GET["destnr"]);
	$Keydest=strval($_GET["Keydest"]);
	// Lees de te verwissselen bestandsnamen van het record in
	$fprssrc=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key = ".$Key);
	$fprsdest=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key = ".$Keydest);
	$rowsrc = odbc_fetch_array($fprssrc);
	$rowdest = odbc_fetch_array($fprsdest);
	$sourcethumb=$rowsrc["thumb".$srcnr];
	$sourcefoto=$rowsrc["foto".$srcnr];
	$sourcearch=$rowsrc["foto".$srcnr."arch"];
	$destthumb=$rowdest["thumb".$destnr];
	$destfoto=$rowdest["foto".$destnr];
	$destarch=$rowsrc["foto".$destnr."arch"];
	odbc_free_result($fprssrc);
	odbc_free_result($fprsdest);
	// wissel velden
	veldupdate("foto".$destnr , $sourcefoto , $Keydest);
	veldupdate("thumb".$destnr , $sourcethumb , $Keydest);
	veldupdate("foto".$destnr."arch" , $sourcearch , $Keydest);
	veldupdate("foto".$srcnr , $destfoto , $Key);
	veldupdate("thumb".$srcnr , $destthumb , $Key);
	veldupdate("foto".$srcnr."arch" , $destarch , $Key);
	$zin=" File ".$srcnr." in#".$Key." verwisseld met file ".$destnr." in#".$Keydest;
	$logzin=$zin;
}elseif ($aktie=="fieldupdate") {
	// Lees de veldinhoud en de backupinhoud (indien van toepassing)
	$fieldcontent=$_REQUEST["fieldcontent"];
	// Lees de veldnaam (indien van toepassing)
	$field_to_update=$_REQUEST["realfield"];
	$backupcontent=$_REQUEST["backup"];
	if($fieldcontent<>$backupcontent or $field_to_update=="archiefnr"){
		$erisdelta=true;
		// Definieer de toegestane karakters in de veldinhoud
		$ongeldig=false;
		if ($field_to_update=="archiefnr") {
		// reset Fout-veld
			veldupdate ("fout","",$Key,$objConnect);
			if (intval($fieldcontent)<100000 or intval($fieldcontent)>999999) {veldupdate("fout","x",$Key);}
		// reset Dubbel-veld
	//		$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key=".$Key);
	//		$row = odbc_fetch_array($fprs);
			$oudarchiefnr=$row["archiefnr"];
			odbc_free_result($fprs);
			$fprs=odbc_exec($objConnect,"UPDATE archief SET dubbel='' WHERE archiefnr='".strval($oudarchiefnr."'"));
			$dubbel=false;
			$fprs=odbc_exec($objConnect,"SELECT COUNT(*) AS aantal FROM archief WHERE Key<>".$Key." AND archiefnr='".strval($fieldcontent)."'");
			$row = odbc_fetch_array($fprs);
			if ($row['aantal']>=1) {$dubbel=true;}
			veldupdate("archiefnr", $fieldcontent, $Key);
			if ($dubbel){$fprs=odbc_exec($objConnect,"UPDATE archief SET dubbel='x' WHERE archiefnr='".strval($fieldcontent)."'");}
			odbc_free_result($fprs);	
		}elseif ($field_to_update=="beschrijving"){
			$fieldcontent=str_replace("'","&#39;",$fieldcontent);
			// Wijzig quotes in de tekst in html-quotes behalve in html-code in de tekst
			$negeer=false;
			for ($i=0; $i<strlen($fieldcontent);$i++){
				$hulp=substr($fieldcontent,$i,1);
				if($hulp=="<"){
					$negeer=true;
				}elseif ($hulp==">"){
					$negeer=false;
				}elseif ($hulp==chr(34) and $negeer==false){
					//verander quotes in karakter ^
					$fieldcontent=substr($fieldcontent,0,$i)."^".substr($fieldcontent,$i+1);
				}
			}
			$fieldcontent=str_replace("^","&quot;",$fieldcontent);
			// Voor opslaan in de database worden eerst alle html-newlines gewijzigd in standaard CRLF's
			$fieldcontent=str_replace("<br>", chr(13).chr(10),$fieldcontent);
			$fieldcontent=str_replace("<br/>", chr(13).chr(10),$fieldcontent);
			veldupdate("beschrijving", $fieldcontent, $Key);
		}else{
			$fieldcontent=trim(diak($fieldcontent));
			$correctedresult="";
			if($ongeldig){$correctedresult=$fieldcontent;}
			if($field_to_update=="jaar" and $fieldcontent==""){$fieldcontent="X";}
			veldupdate ($field_to_update , $fieldcontent , $Key);
			if ($field_to_update=="itemtitle"){
				$titelsamen=strtolower(str_replace(" ", "",str_replace("-", "",str_replace("'","",$fieldcontent))));
				veldupdate("titelsamen", $titelsamen, $Key);
			}
		}
		if (strlen($backupcontent)==0){$backupcontent="leeg";}
		if($field_to_update=='jaar' or $field_to_update=='maand' or $field_to_update=='dag' or $field_to_update=='jaarmarge'){
			$zin=" checked/updated datering in#".$Key." Was: ".$backupcontent;
			$logzin=" checked/updated datering in#".$Key." (".$fieldcontent.") Was: ".$backupcontent;
		}else  if($field_to_update=="beschrijving" or $field_to_update=="archiefnr"){
			$zin=" checked/updated ".$field_to_update." in#".$Key." Was: ".$backupcontent;
			$logzin=" checked/updated ".$field_to_update." in#".$Key." (".$fieldcontent.") Was: ".$backupcontent;
		}else{
			$zin=" ".$field_to_update." aangepast. in#".$Key." Was: ".$backupcontent;
			$logzin=" ".$field_to_update." aangepast (".$fieldcontent.") Was: ".$backupcontent;
		}
		if ($ongeldig){$zin="<font color=red>Ongeldige karakters aangepast of verwijderd</font> ".$zin;}
	}else{$zin="Geen wijziging";$logzin="";}
}

if($erisdelta){$fprs=odbc_exec($objConnect,"UPDATE delta SET delta='X'");}

if ($aktie!=="checknr"){
	if($aktie!=="newrec" and $aktie!=="copyrec" and $aktie!=="delrec" and $user!=="ocrimport"){
		echo $zin;
		if(strlen($logzin)>0){
			$fprs=odbc_exec($objConnect,"UPDATE archief SET tse=" . $diffSeconds. ",aanpasser='".$user."'  WHERE Key = " . $Key);
			if($aktie=="ruil"){
				$fprs=odbc_exec($objConnect,"UPDATE archief SET tse=" . $diffSeconds. ",aanpasser='".$user."'  WHERE Key = " . $Keydest);
			}
		}
	}
	else if($aktie=="newrec" or $aktie=="copyrec"){
		$fprs=odbc_exec($objConnect,"UPDATE archief SET toevoeger='".$user."'  WHERE Key = " . strval($vrijnummer));
	}
	$zin=$zinDate." ".$zinTime." ".$zin.chr(13).chr(10);
// Schrijf het resultaat weg in de return tekst
	?>
	<?php
	if($aktie=="newrec" or $aktie=="copyrec"){
		echo "vrijnummer".$vrijnummer."vrijnummer";
	}else{ ?>
		</font><input type="hidden" id="resultaat" name="resultaat" value="OK">
		<input type="hidden" id="correctedresult" name="correctedresult" value="<?php echo $correctedresult; ?>">
		<input type="hidden" id="ongeldig" name="ongeldig" value="<?php echo $ongeldig; ?>">
	<?php
	}
	// Update logfile
	if(strlen($logzin)>0){
		$logzin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$user.": ".$logzin.chr(13).chr(10);
		//		error_reporting(0);
		$oTextFile = fopen($logfile, "a");
		fwrite($oTextFile,$logzin);
		fclose($oTextFile);
		//		error_reporting(-1);
	}
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname=$logfile." ".$zinDate." ".$zinTime.".txt";
		echo "<br>Log recycled: ".$newname;
		rename ($logfile,$newname);
	}
}
// Close connection
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
odbc_close($defConnect);
unset($defConnect);
?>
</body></html>
