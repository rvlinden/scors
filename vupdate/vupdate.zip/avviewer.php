<html><head></head><body style="background-color: #000000;">
<?php
//Lees de input parameters
$viewer="";$filepath="";
if (isset($_REQUEST["filepath"])){$filepath=$_REQUEST["filepath"]."?rel=0&modestbranding=1";}
if (isset($_REQUEST["viewer"])){$viewer=$_REQUEST["viewer"];}
if ($viewer=="mp4") { ?>
	<div align="center">
	<video width="100%" height="100%" controls >
	<source src="<?php echo $filepath; ?>" type="video/mp4">
	Your browser does not support the video tag.
	</video>
	</div>
<?php
}else if ($viewer=="mp3") { ?>
	<div align="center">
	<img src="images/audio.png"><br><br><br>
	<audio width="280" controls type="audio/mp3">
	<source src="<?php echo $filepath; ?>">
	Your browser does not support the audio tag.
	</audio> 
	</div>
<?php
}else if ($viewer=="youtube") { ?>
	<div align="center">
	<iframe width="100%" height="100%" src="<?php echo $filepath; ?>" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
	</div>
<?php
} ?>
</body></html>