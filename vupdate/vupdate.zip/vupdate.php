<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

//Check of gebruiker is ingelogd
if ($rechten!="sup"){exit();}
error_reporting(E_ALL);
ini_set('display_errors', 1);
$updateUrl = "https://scors.nl/vupdate/vupdate.zip";
$zipFile = __DIR__ . "/vupdate.zip";
$extractPath = __DIR__; // Root of the website

echo "<p>Downloading update...</p>";
// Download the update file
if (file_put_contents($zipFile, fopen($updateUrl, 'r')) === false) {
	die("<p>Error: Download van update niet gelukt.</p>");
}
// Extract the ZIP file
$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
	$zip->extractTo($extractPath);
	$zip->close();
	unlink($zipFile); // Remove ZIP after extraction
	echo "<p>Update succesvol uitgevoerd.<br>Ververs nu uw scherm</p>";
} else {
	die("<p>Error: Update niet gelukt.</p>");
}
?>
