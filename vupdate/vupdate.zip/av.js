// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

var scrollnu=0;startloop=true;aantalloaded=0;var orgviewer; var blijfinedit=false;
function getcontainer(urlquery){
	startloop=true;var d=new Date().getTime();
	if(urlquery==''){urlquery='?t='+d;}else{if(urlquery.indexOf('t=1')<0){urlquery=urlquery+'&t='+d;}}
	if (backforwardused==false){history.pushState(null,null,location.href);history.replaceState(null,null,urlquery);}
	backforwardused=false;
	if (ctrltoets==true){ctrltoets=false;window.open(urlquery);window.focus();}
	else{
//		$(".wachtshow").removeClass("onzichtbaar");$(".emptyshow").addClass("onzichtbaar");
		urlquery=vlinden+"avdiv.php"+urlquery+'t='+d;
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET",urlquery,false);
		xmlhttp.setRequestHeader("vm",$('#vm').val());
		xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
		document.getElementById('avcontainer').innerHTML=xmlhttp.responseText;
	    var bounding = document.getElementById("top").getBoundingClientRect();
		if (scrollnu==1 || bounding.top < 0){$("body,html").animate({scrollTop: $("#top").offset().top},250);}
		scrollnu=scrollnu+1;
	}
//	$(".wachtshow").addClass("onzichtbaar");$(".emptyshow").removeClass("onzichtbaar");
	return;}
function xmltrein(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	return;}
function keyPressListener(e) {
	if (e.keyCode == 13) {avzoek();}
	return;}
function avzoek(){
	getcontainer('?av=av&sort='+$('#sort').val()+'&zoek='+$('#zoek').val());	
return;}
function checkresult(){
	if (startloop==false && blijfinedit==false){getcontainer('?av=av&sort='+$('#sort').val()+'&zoek='+$('#zoek').val()+'&pg='+$('#pg').val());}
	else{aantalloaded++;if(aantalloaded>0){startloop=false;}}
	if (blijfinedit){
		let iframe = document.getElementById("avedit");
		let iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
		let innerText = iframeDoc.body.innerText;
		$('#wachten').hide();zetviewerselect();
		if($('#viewer').val()=='mp4'){
			document.getElementById("plaatjemp4").src=innerText;document.getElementById("eigenvid").load();
			mp4thumb();
		}else if($('#viewer').val()=='panorama'){
			document.getElementById("plaatjepanorama").src=innerText+'?t='+Date.now();
			document.getElementById("plaatjepanorama").width="180";
		}
	}
	blijfinedit=false;
	$('#aktieknoppen').show();
return;}
function mp4thumb(){
    const video = document.getElementById("eigenvid");
    const canvas = document.getElementById("videoCanvas");
    const ctx = canvas.getContext("2d");
	setTimeout(function(){
		let originalWidth = video.videoWidth;
		let originalHeight = video.videoHeight;
		// Max dimensions
		const maxWidth = 299;
		const maxHeight = 250;
		// Scale while maintaining aspect ratio
		let scale = Math.min(maxWidth / originalWidth, maxHeight / originalHeight);
		let newWidth = Math.round(originalWidth * scale);
		let newHeight = Math.round(originalHeight * scale);
		// Set canvas size to the scaled width and height
		canvas.width = newWidth;
		canvas.height = newHeight;
		// Draw the video frame on the canvas
		ctx.drawImage(video, 0, 0, newWidth, newHeight);
		// Draw the current video frame onto the canvas
//		ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
		// Convert to Base64 and store in hidden input
		const thumbnailBase64 = canvas.toDataURL("image/jpeg",0.9);
		document.getElementById("thumbnailInput").value = thumbnailBase64;
	}, 350);
return;}
function changeviewer(newviewer,oldviewer){ //alleen in Nieuw-mode
	if (newviewer=='eigen'){ //van youtube of sketchfab naar eigen
		$('#viewer').val(orgviewer);
		$("#standaard").show();
		$("#yt").hide();
		$("#sf").hide();
		$('#divplaatjeyoutube').hide();
		$('#divplaatjesketchfab').hide();
		if($('#viewer').val()=='mp4'){
			$('#divplaatjemp4new').show();
		}else if($('#viewer').val()=='mp3'){
			$('#divplaatjemp3').show();
		}else if($('#viewer').val()=='panorama'){
			$('#divplaatjepanorama').show();
		}
	}else{ //naar sketchfab of youtube
		if (oldviewer=='eigen'){orgviewer=$('#viewer').val();}
		$("#standaard").hide();
		$('#viewer').val(newviewer);
		if (newviewer=='sketchfab'){$("#sf").show();zetsketchfab();}
		else{$("#yt").show();zetyoutube();}
	}
return;}
function zetyoutube(){
	$('#viewer').val('youtube');
	$('#divplaatjemp4new').hide();
	$('#divplaatjemp4').hide();
	$('#divplaatjemp3').hide();
	$('#divplaatjepanorama').hide();
	$('#divplaatjesketchfab').hide();
	$('#divplaatjeyoutube').show();
	if($('#ytcode').val()==''){$('#plaatjeyoutube').attr("src","images/playvideo.png");}
	else{$('#plaatjeyoutube').attr("src","avadmin.php?aktie=watermerk&soort=video&filenaam=https://i.ytimg.com/vi/"+$('#ytcode').val()+"/hqdefault.jpg");}
return;}
function zetsketchfab(){
	$('#viewer').val('sketchfab');
	$('#divplaatjemp4new').hide();
	$('#divplaatjemp4').hide();
	$('#divplaatjemp3').hide();
	$('#divplaatjepanorama').hide();
	$('#divplaatjeyoutube').hide();
	$('#divplaatjesketchfab').show();
	if($('#sfcode').val()==''){$('#plaatjesketchfab').attr("src","images/3dmodel.png");}
	else{$('#plaatjesketchfab').attr("src","https://www.sketchfab.com/3d-models/"+$('#sfcode').val()+'/embed?autostart=0&amp;camera=0');}
return;}
function zetviewerselect(){ //wordt uitgevoerd na kiezen bestand voor upload
	if($('#orgfilename').val().indexOf("mp4")>0){
		$('#viewer').val('mp4');
		$('#keyframediv').show();
		$('#divplaatjemp3').hide();
		$('#divplaatjemp4').show();
		$('#divplaatjepanorama').hide();
		$('#divplaatjemp4new').hide();
		mp4thumb();
	}
	else if($('#orgfilename').val().indexOf("mp3")>0){
		$('#viewer').val('mp3');
		$('#keyframediv').hide();
		$('#divplaatjemp4new').hide();
		$('#divplaatjemp4').hide();
		$('#divplaatjepanorama').hide();
		$('#divplaatjemp3').show();
	}
	else if($('#orgfilename').val().indexOf("jpg")>0){
		$('#viewer').val('panorama');
		$('#keyframediv').hide();
		$('#divplaatjemp4new').hide();
		$('#divplaatjemp4').hide();
		$('#divplaatjemp3').hide();
		$('#divplaatjepanorama').attr("src","images/360.png");
		$('#divplaatjepanorama').show();
	}
	else{
		alert('Ongeldig bestandsformaat');
		$('#orgfilename').val('');
		if($('#aktie').val()=='nieuw'){
			$('#keyframediv').hide();
			$('#divplaatjemp4new').hide();
			$('#divplaatjemp4').hide();
			$('#divplaatjemp3').hide();
			$('#divplaatjepanorama').hide();
			$('#viewer').val('');
		}
	}
return;}
function alertchange(){
	$('#savebutton').attr('class','ggbuttonrood');
return;}
function checksubmit(klaar){
	blijfinedit=klaar;
	if($('#viewer').val()=='youtube'){
		if($('#ytcode').val()==''){
			if(confirm('U heeft nog geen Youtube code ingevuld.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#orgfilename').val('');
	}else if($('#viewer').val()=='sketchfab'){
		if($('#sfcode').val()==''){
			if(confirm('U heeft nog geen Sketchfab code ingevuld.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#orgfilename').val('');
	}else{
		if($('#orgfilenaam').val()=='' && $('#aktie').val()=='nieuw'){
			if (confirm('U heeft nog geen bestand gekozen.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#ytcode').val('');
	}
	$('#wachten').show();
	$('#aktieknoppen').hide();
	$('#avform').submit();
return;}

var backforwardused=false;var ctrltoets=false;
window.onpopstate=function(event){backforwardused=true;getcontainer('?'+window.location.search.substring(1));return;};
if(window.location.search.substring(1)==''){getcontainer('')}else{getcontainer('?'+window.location.search.substring(1))};

