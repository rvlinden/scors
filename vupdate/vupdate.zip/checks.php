<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

//***Blacklist check
$bronadres="";$browsertype="";
if(isset($_SERVER['REMOTE_ADDR'])){$bronadres=$_SERVER['REMOTE_ADDR'];}
if(isset($_SERVER['HTTP_USER_AGENT'])){$browsertype=$_SERVER['HTTP_USER_AGENT'];}
$adresdelen=explode('.',$bronadres);
$subnetadres=$adresdelen[0].".".$adresdelen[1].".".$adresdelen[2].".0";
$blConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/blacklist.mdb","","");
$objRS=odbc_exec($blConnect,"SELECT COUNT(*) as aantal FROM blackip WHERE ipadres='".$bronadres."' OR ipadres='".$subnetadres."'");
$row=odbc_fetch_array($objRS);
$blcheck=$row['aantal'];
$objRS=odbc_exec($blConnect,"SELECT COUNT(*) as aantal FROM UA WHERE UA like '%".$browsertype."%'");
$row=odbc_fetch_array($objRS);
$blcheck=$blcheck+$row['aantal'];
odbc_free_result($objRS);
unset($objRS);
odbc_close($blConnect);
unset ($blConnect);
if ($blcheck<>0){exit();}

$remotekey="";
if (isset($_SERVER["HTTP_VM"])){$remotekey=$_SERVER["HTTP_VM"];}
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Lees eventuele Key en domein voor remote access vanuit b.v. Wordpress of JSON
$fprs=odbc_exec($defConnect, "SELECT * FROM SETTINGS");
$row=odbc_fetch_array($fprs);
$wpkey=$row["wpkey"];
$wpdomein=strtolower($row["wpdomein"]);
unset($fprs);
odbc_close($defConnect);
$komtvan="";
if (isset($_SERVER['HTTP_REFERER'])){$komtvan=strtolower($_SERVER['HTTP_REFERER']);}
//Check login-status en rechten van gebruiker
//Bij runnen op eigen server (o.a. in editmode) gebruik de cookiegegevens
//In presentatiemode op een externe server (b.v. Wordpress) gebruik de meegestuurde header request parameter vm
$rechten="";
if(isset($_COOKIE['logon'])){$rechten=$_COOKIE['logon'];} //runt op eigen server in editmode
if ($komtvan!=="" and $wpdomein!==""){
	if(strpos($komtvan,$wpdomein)>0){ //runt via div op hostingserver
		if($remotekey==$wpkey){$rechten="ufa";} 
	}
}
if(isset($_COOKIE['user'])){$user=$_COOKIE['user'];}
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (strpos($user_agent, 'Mobile') !== false || strpos($user_agent, 'Android') !== false || strpos($user_agent, 'iPhone') !== false) {
    // User is likely using a mobile device
	$maxbreed="768";$maxmarg="20";
} else {   // User is likely not using a mobile device
	$maxbreed="1055";$maxmarg="75";
}
?>