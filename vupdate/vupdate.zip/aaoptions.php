<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");

//Zoek suggesties voor de inhoud van velden
//Of maak een voorselectie in de velden van de zoekfunctie 
//Start zodra 3 of meer karakters worden ingevoerd in edit-mode of
//zodra in de zoekfunctie de inhoud in een bepaald veld is geselecteerd

//Verwijder niet toegestane karakters
function cleaninput($ipar){
	$acx=str_replace("'","",$ipar);
	$acx=str_replace("<", "",$acx);
	$acx=str_replace(">", "",$acx);
	$acx=str_replace(";", "",$acx);
	$acx=str_replace("%", "",$acx);
	return $acx;
}

//Lees de doelgroep: v(isitors) of e(ditors)
$doel="v";$doelstub=" WHERE doel='v' ";$doelstub2=" AND doel='v' ";
if ($rechten=="mo" or $rechten=="sup"){$doel="e";$doelstub="";$doelstub2="";}
if ($rechten=="ufa"){$doel="e";$doelstub=" WHERE doel<>'p' ";$doelstub2=" AND doel<>'p' ";}

//Lees de parameters die aangeven voor welk veld gezocht moet worden
$m="";$w="";$a="";$u="";$r="";$s="";$z="";$veld="";$moveld="";$term="";
if(isset($_REQUEST["w"])){$w=cleaninput($_REQUEST["w"]);}
if(isset($_REQUEST["a"])){$a=cleaninput($_REQUEST["a"]);}
if(isset($_REQUEST["u"])){$u=cleaninput($_REQUEST["u"]);}
if(isset($_REQUEST["r"])){$r=cleaninput($_REQUEST["r"]);}
if(isset($_REQUEST["s"])){$s=cleaninput($_REQUEST["s"]);}
if(isset($_REQUEST["m"])){$m=cleaninput($_REQUEST["m"]);}
//lees de term waarop gezocht moet worden
if(isset($_REQUEST["term"])){$z=strval(cleaninput($_REQUEST["term"]));}
//Lees het veld voor de uitgebreide zoekfunctie waarin de voorselectie moet plaatsvinden
//Of lees het edit-mode veld waarvoor gezocht wordt. Slechts 1 van de 2 kan aanwezig zijn in de querystring
if(isset($_REQUEST["veld"])){$veld=cleaninput($_REQUEST["veld"]);}
if(isset($_REQUEST["moveld"])){$moveld=cleaninput($_REQUEST["moveld"]);}

//Construeer de SQL string
$stub="";
$tussen="WHERE ";

if (strlen($w)>0 and $veld<>"w") {
	$stub=$stub.$tussen."(straat='".$w."')";
	$tussen=" AND ";
}
if (strlen($m)>0 and $veld<>"m") {
	$stub=$stub.$tussen."(persoon='".$m."' OR persoon2='".$m."')";
	$tussen=" AND ";
}
if (strlen($a)>0 and $veld<>"a") {
	$stub=$stub.$tussen."(auteur1='".$a."' OR auteur2='".$a."' OR auteur3='".$a."')";
	$tussen=" AND ";
}
if (strlen($u)>0 and $veld<>"u") {
	$stub=$stub.$tussen."(bron1='".$u."' OR bron2='".$u."' OR bron3='".$u."')";
	$tussen=" AND ";
}
if (strlen($s)>0 and $veld<>"s") {
	$stub=$stub.$tussen."(soort1='".$s."')";
	$tussen=" AND ";
}
if (strlen($r)>0 and $veld<>"r") {
	$stub=$stub.$tussen."(onderwerp1='".$r."' OR onderwerp2='".$r."' OR onderwerp3='".$r."' OR onderwerp4='".$r."')";
	$tussen=" AND ";
}
if ($doel=="v"){
	$stub=$stub.$tussen."(doel='v')";
	$tussen=" AND ";
}

if (strlen($moveld)==0) {
	//Voorselectie voor de inhoud van de velden van de uitgebreide zoekfunctie
	if ($veld=="r" and strlen($m.$w.$a.$u.$s)==0) {
		$sqlstuk="SELECT DISTINCT onderwerpen FROM rlist ".$doelstub." order by onderwerpen asc";
		$veldnaam="onderwerpen";
	}elseif($veld=="w" and strlen($m.$a.$r.$u.$s)==0) {
		$sqlstuk="SELECT DISTINCT straten FROM wlist ".$doelstub." order by straten asc";
		$veldnaam="straten";
	}elseif($veld=="m" and strlen($w.$a.$r.$u.$s)==0) {
		$sqlstuk="SELECT DISTINCT personen FROM plist ".$doelstub." order by personen asc";
		$veldnaam="personen";
	}elseif($veld=="a" and strlen($m.$w.$r.$u.$s)==0) {
		$sqlstuk="SELECT DISTINCT auteurs FROM alist ".$doelstub." order by auteurs asc";
		$veldnaam="auteurs";
	}elseif($veld=="u" and strlen($m.$w.$r.$a.$s)==0) {
		$sqlstuk="SELECT DISTINCT bronnen FROM ulist ".$doelstub." order by bronnen asc";
		$veldnaam="bronnen";
	}elseif($veld=="s" and strlen($m.$w.$r.$a.$u)==0) {
		$sqlstuk="SELECT DISTINCT soorten FROM slist ".$doelstub." order by soorten asc";
		$veldnaam="soorten";
	}else{
		if ($veld=="r") {
			$sqlstuk="SELECT onderwerp1 FROM lijst ".$stub." union select onderwerp2 from lijst ".$stub." union select onderwerp3 from lijst ".$stub." union select onderwerp4 from lijst ".$stub;
			$veldnaam="onderwerp1";
		}elseif($veld=="w") {
			$sqlstuk="SELECT DISTINCT straat FROM lijst ".$stub;
			$veldnaam="straat";
		}elseif($veld=="m") {
			$sqlstuk="SELECT DISTINCT persoon FROM lijst ".$stub." union select persoon2 from lijst ".$stub;
			$veldnaam="persoon";
		}elseif($veld=="a") {
			$sqlstuk="SELECT auteur1 FROM lijst ".$stub." union select auteur2 from lijst ".$stub." union select auteur3 from lijst ".$stub;
			$veldnaam="auteur1";
		}elseif($veld=="s") {
			$sqlstuk="SELECT DISTINCT soort1 FROM lijst ".$stub;
			$veldnaam="soort1";
		}elseif($veld=="u") {
			$sqlstuk="SELECT bron1 FROM lijst ".$stub." union select bron2 from lijst ".$stub." union select bron3 from lijst ".$stub;
			$veldnaam="bron1";
		}
	}
}else{
	//Lookup-suggesties voor zoek en input velden
	if ($moveld=="r") {
		$sqlstuk="SELECT DISTINCT onderwerpen FROM rlist WHERE onderwerpen like '%".$z."%' ".$doelstub2." ORDER BY onderwerpen ASC";
		$veldnaam="onderwerpen";
	}elseif($moveld=="w") {
		$sqlstuk="SELECT DISTINCT straten FROM wlist WHERE straten like '%".$z."%' ".$doelstub2."order by straten asc";
		$veldnaam="straten";
	}elseif($moveld=="m") {
		$sqlstuk="SELECT DISTINCT personen FROM plist WHERE personen like '%".$z."%' ".$doelstub2." order by personen asc";
		$veldnaam="personen";
	}elseif($moveld=="a") {
		$sqlstuk="SELECT DISTINCT auteurs FROM alist WHERE auteurs like '%".$z."%' ".$doelstub2." order by auteurs asc";
		$veldnaam="auteurs";
	}elseif($moveld=="s") {
		$sqlstuk="SELECT DISTINCT soorten FROM slist WHERE soorten like '%".$z."%' ".$doelstub2." order by soorten asc";
		$veldnaam="soorten";
	}elseif($moveld=="u") {
		$sqlstuk="SELECT DISTINCT bronnen FROM ulist WHERE bronnen like '%".$z."%' ".$doelstub2." order by bronnen asc";
		$veldnaam="bronnen";
	}elseif($moveld=="mapnr") {
		$sqlstuk="SELECT DISTINCT mapnrs FROM mlist WHERE mapnrs like '%".$z."%' ".$doelstub2." ORDER BY mapnrs asc";
		$veldnaam="mapnrs";
	}elseif($moveld=="z") {
		//Bij de vrije zoekfunctie wordt na ingave van 3 of meer karakters gezocht naar eventuele suggesties die matchen met de zoekvraag
		if(isset($_REQUEST["term"])){
			$z=$_REQUEST["term"];
			//Verwijder niet-relevante karakters uit de zoekterm
			$z=str_replace("'", "",$z);
			$z=str_replace("<", "",$z);
			$z=str_replace(">", "",$z);
			$z=str_replace(";", "",$z);
			$z=str_replace("]", "",$z);
			$z=str_replace("[", "",$z);
			$z=str_replace("{", "",$z);
			$z=str_replace("}", "",$z);
			$z=str_replace("+", " ",$z);
			$z=str_replace("*", "",$z);
		}else{
			//Verwijder niet-relevante karakters uit de zoekterm
			$z=str_replace("'", "",$z);
			$z=str_replace("<", "",$z);
			$z=str_replace(">", "",$z);
			$z=str_replace(";", "",$z);
			$z=str_replace("]", "",$z);
			$z=str_replace("[", "",$z);
			$z=str_replace("{", "",$z);
			$z=str_replace("}", "",$z);
			$z=str_replace("-1","",$z);
			$z=str_replace("(", "",$z);
			$z=str_replace(")", "",$z);
			$z=str_replace(",", "",$z);
			$z=str_replace("%", "",$z);
			$z=str_replace("+", " ",$z);
			$z=str_replace("*", "",$z);
			while (strpos($z,"  ")!==false){$z=str_replace("  ", " ",$z);}
		}
		
		//Creeer de SQL string
		$sqlstuk="SELECT distinct woord FROM suggesties WHERE doel='".$doel."' ";
		if (strpos($z,chr(34))!==false){
			//Zoekterm staat $tussen aanhalingstekens, dus exact zoeken
			$z=str_replace(chr(34),"",$z);
			$sqlstuk=$sqlstuk." AND (woord like '%".$z."%')";
		}else{
			//De suggestie moet alle woorden bevatten in willekeurige volgorde
			//Splits de zoekterm in de afzonderlijke zoekwoorden
			$zkw=explode(" ",$z);
			foreach ($zkw as $zk){			
				$sqlstuk=$sqlstuk." AND (woord like '%".$zk."%')";
			}
		}
		$sqlstuk=$sqlstuk." ORDER BY woord ASC";
	}
}

//Open database
$fprs=odbc_exec($objConnect, $sqlstuk);
if (strlen($moveld)>0) {
	//Retourneer het resultaat in de vorm ["<resultaat1>","<resultaat2>","<enz.>"]
	$i = 0;
	echo "[";
	while($row = odbc_fetch_array($fprs)){
	    if($i==1){echo ",";}
		echo chr(34);
	    if($moveld=="z"){echo $row['woord'];}
		else{echo $row[$veldnaam];}
		echo chr(34);
		$i = 1;
	}
	echo "]";
}else{
	//Retourneer het resultaat in de HTML vorm van een select field
$veldaanaam="aa".$veld;
	?><select id="<?php echo $veldaanaam; ?>" name="<?php echo $veldaanaam; ?>" class="invulveld zoekinvul" onfocus="zetzoek('<?php echo $veld; ?>');" onchange="zoekalloptions('<?php echo $veld; ?>');"><option></option><?php
	while($row=odbc_fetch_array($fprs)){
		$hulp=$row[$veldnaam];
		if (strlen($hulp)>0) {
			echo "<option ";
			if ($z==$hulp){echo " selected";}
			echo ">".$hulp."</option>";
		}
	}
	echo "</select>";
}
odbc_free_result($fprs);
unset($fprs);
odbc_close($objConnect);
unset($objConnect);

?>