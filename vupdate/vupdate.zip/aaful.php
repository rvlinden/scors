<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

//check of is ingelogd
if ($rechten!="mo" and $rechten!="sup"){exit();}

//plaats upload in map ful
$sleutel=$_GET["sleutel"];
$nummer=$_GET["nummer"];
$randomizefile=$sleutel.substr(md5(rand()), 0, 7);
$fulname="ful/".$randomizefile . ".";
$bestandstype=strtolower(pathinfo($_FILES["orgfilename"]["name"],PATHINFO_EXTENSION));
$fulname=$fulname.$bestandstype;
move_uploaded_file($_FILES["orgfilename"]["tmp_name"], $fulname);

$exif = @exif_read_data($fulname);
if (!empty($exif['Orientation'])) {
	// load image resource
    switch ($bestandstype) {
        case 'jpg':
        case 'jpeg':
            $img = imagecreatefromjpeg($fulname);
            break;
        case 'png':
            $img = imagecreatefrompng($fulname);
            break;
        case 'gif':
            $img = imagecreatefromgif($fulname);
            break;
        default:
            $img = null;
    }
    if ($img !== null) {
        switch ($exif['Orientation']) {
            case 3:
                $img = imagerotate($img, 180, 0);
                break;
            case 6:
                $img = imagerotate($img, -90, 0);
                break;
            case 8:
                $img = imagerotate($img,  90, 0);
                break;
        }
        imagejpeg($img, $fulname); // overwrite corrected file
        imagedestroy($img);        // free memory
    }
}

$plaatjes=array("jpg", "jpeg", "gif", "png", "webp");
$overige=array("xls", "xlsx", "doc", "docx", "ppt", "pptx", "txt", "rtf");
$newthumbname=$randomizefile.".jpg";
$newfilename=$randomizefile."." . $bestandstype;
$newimagename=$randomizefile.".jpg";
$stubdir=substr($sleutel,0,3)."/";
$filesmap="./AAD/".$stubdir;
$thumbsmap="./AAT/".$stubdir;
$beschrijving="";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");

//Verwijder niet toegestane karakters uit de input parameters
function cleaninput($ipar){
	$fieldcontent=$ipar;
	$fieldcontent=str_replace("'","&#39;",$fieldcontent);
	// Wijzig quotes in de tekst in html-quotes behalve in html-code in de tekst
	$negeer=false;
	for ($i=0; $i<strlen($fieldcontent);$i++){
		$hulp=substr($fieldcontent,$i,1);
		if($hulp=="<"){
			$negeer=true;
		}elseif ($hulp==">"){
			$negeer=false;
		}elseif ($hulp==chr(34) and $negeer==false){
			//verander quotes in karakter ^
			$fieldcontent=substr($fieldcontent,0,$i)."^".substr($fieldcontent,$i+1);
		}
	}
	$fieldcontent=str_replace("^","&quot;",$fieldcontent);
	// Voor opslaan in de database worden eerst alle html-newlines gewijzigd in standaard CRLF's
	$fieldcontent=str_replace("<br>", chr(13).chr(10),$fieldcontent);
	$fieldcontent=str_replace("<br/>", chr(13).chr(10),$fieldcontent);
	return $fieldcontent;
}

if($nummer>0){ //Nieuwe image en thumbnail
	
	// Lees de bestandsnamen van het record en nummer in en gooi evt. al bestaande grote en thumbfile weg
	$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key = " . $sleutel);
	$archiefnummer=odbc_result($fprs,"archiefnr");
	$kidx=odbc_result($fprs,"foto" . $nummer);
	if(strlen($kidx)>0){
		//verwijder oude foto en thumb
		error_reporting(0);
		$orgstubdir=substr($kidx,0,3) . "/";
		unlink("./AAD/".$orgstubdir.$kidx);
		unlink("./AAT/".$orgstubdir.$kidx);
		error_reporting(-1);
		//verwijder OCR tekst
		$ocrkidx=substr($kidx,0,13);
		$verwijder=odbc_exec($objConnect,"DELETE FROM ocr WHERE kidx= '" . strval($ocrkidx)."'");
	}

	// Maak thumbnail voor plaatjes
	$newSize=intVal(175);
	if (in_array($bestandstype,$plaatjes)) {
		switch ($bestandstype) {
			case 'jpeg':
			case 'jpg':
				$filenaam = imagecreatefromjpeg($fulname);
			break;
			case 'png':
				$filenaam = imagecreatefrompng($fulname);
			break;
			case 'gif':
				$filenaam = imagecreatefromgif($fulname);
			break;
			case 'webp':
				$filenaam = imagecreatefromwebp($fulname);
			break;
		}
		$destfile=$thumbsmap . $newthumbname;

	// Get current image size
		$srcW = imagesx($filenaam);
		$srcH = imagesy($filenaam);
		$resW = $srcW;
		$resH = $srcH;
	//	Calculate scale
		$xScale = $srcW / $newSize;
		$yScale = $srcH / $newSize;
	//	Calculate new width and height
		if ($yScale > $xScale){
			$resW = round($srcW * (1/$yScale));
			$resH = round($srcH * (1/$yScale));
		}
		else {
			$resW = round($srcW * (1/$xScale));
			$resH = round($srcH * (1/$xScale));
		}
		$resimage = @imagecreatetruecolor($resW,$resH);
		imagecopyresampled($resimage, $filenaam, 0, 0, 0, 0, $resW, $resH, $srcW, $srcH);
		imagejpeg($resimage, $destfile, 85);
		imagedestroy($filenaam);
		imagedestroy($resimage);
	}elseif (in_array($bestandstype,$overige)){
		copy("images/logo".$bestandstype.".jpg", $thumbsmap.$newthumbname);
	}elseif ($bestandstype=="pdf"){
		$im = new Imagick();
		$im->setResourceLimit(Imagick::RESOURCETYPE_MEMORY,402653184);
		$im->setResolution( 300, 300);
		$im->readImage($fulname.'[0]');
		$im->setImageFormat('jpg');
		$im->setImageBackgroundColor('white');
		$im->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
		$im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
		$im->thumbnailImage(175,175,true);
		$im->transformImageColorspace(Imagick::COLORSPACE_SRGB);
		$draw = new ImagickDraw();
		$draw->setFillColor('red');
		$draw->setFont('Arial');
		$draw->setFontSize( 18 );
		$im->annotateImage($draw, 4, $im->getImageHeight()-4, 0, 'PDF');
		$im->writeImage($thumbsmap.$newthumbname);
		unset ($im);
	}else{
		copy("images/logounknown.jpg", $thumbsmap.$newthumbname);
	}

	// Maak fullsize image quality 90 en progressive
	if (in_array($bestandstype,$plaatjes)) {
		switch ($bestandstype) {
			case 'jpeg':
			case 'jpg':
				$filenaam = imagecreatefromjpeg($fulname);
			break;
			case 'png':
				$filenaam = imagecreatefrompng($fulname);
			break;
			case 'gif':
				$filenaam = imagecreatefromgif($fulname);
			break;
			case 'webp':
				$filenaam = imagecreatefromwebp($fulname);
			break;
		}
		$destfile=$filesmap . $newimagename;

		imageinterlace($filenaam, true);
		imagejpeg($filenaam, $destfile, 90);
		imagedestroy($filenaam);
		$newfilename=$newimagename;
		unlink($fulname);
	}else{
		// Kopieer het nieuwe bestand van ful naar destinationdir
		rename($fulname, $filesmap.$newfilename);
	}

	// Werk database bij
	$now = new DateTime( 'NOW' );
	$diffSeconds = $now->getTimestamp();
	$fprs=odbc_exec($objConnect,"UPDATE archief SET foto" . $nummer . " = '" . $newfilename . "'  WHERE Key = " . $sleutel);
	$fprs=odbc_exec($objConnect,"UPDATE archief SET thumb" . $nummer . " = '" . $newthumbname . "'  WHERE Key = " . $sleutel);
	$fprs=odbc_exec($objConnect,"UPDATE archief SET foto" . $nummer . "arch = '" . $archiefnummer . "'  WHERE Key = " . $sleutel);
	$fprs=odbc_exec($objConnect,"UPDATE archief SET tse = " . strval($diffSeconds) . ",aanpasser='".$user."'  WHERE Key = " . $sleutel);

}else{ //Tekst toevoegen aan beschrijving
	$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE Key = " . $sleutel);
	$archiefnummer=odbc_result($fprs,"archiefnr");
	$beschrijving=odbc_result($fprs,"beschrijving");
	// read text from uploaded file $fulname
	if($bestandstype=="txt"){
		$beschrijving=cleaninput($beschrijving."<br>".file_get_contents($fulname));
		// add text to beschrijving field
		$fprs=odbc_exec($objConnect, "UPDATE archief SET beschrijving = '".$beschrijving."' WHERE Key=" . $sleutel);
	}
	// remove uploaded file
	unlink($fulname);
}

unset($fprs);
odbc_close($objConnect);
unset($objConnect);

// Update logfile
$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsbeeldlog.txt";
if($nummer>0){
	$logzin=" Foto upload  nr ".$nummer.", ".$newfilename;
}else{
	$logzin=" Text upload ".$newfilename;
}
$logzin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$user.": Archiefnr: ".$archiefnummer." DB-Index: ".$sleutel." ".$logzin.chr(13).chr(10);
//		error_reporting(0);
$oTextFile = fopen($logfile, "a");
fwrite($oTextFile,$logzin);
fclose($oTextFile);
//		error_reporting(-1);
if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
	$newname="log/scorsbeeldlog_".$zinDate."_".$zinTime.".txt";
	rename ($logfile,$newname);
}

// Toon het resultaat voor de parent (deze routine loopt in een iframe)
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>
<input type="hidden" name="resultaat" id="resultaat" value="<?php if($nummer>0){echo "OK";}else{echo "TXT";} ?>">
<textarea hidden name="nieuwetekst" id="nieuwetekst"><?php echo $beschrijving; ?></textarea>
<input type="hidden" name="afbsrc" id="afbsrc" value="<?php echo $filesmap.$newfilename; ?>">
<input type="hidden" name="thumbsrc" id="thumbsrc" value="<?php echo $thumbsmap.$newthumbname; ?>">
<font style="font-size:9pt;"><?php echo date("h:i:s")."&nbsp;Upload:&nbsp;".$newfilename; ?></font>
</body></html>
