<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/boeken.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Get hostserver voor media
$basis="https://" . $_SERVER['HTTP_HOST']."/";
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$basiskleur1=$row["basiskleur1"];
$basiskleur2=$row["basiskleur2"];
?>
<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
<?php
//genereer logfile voor collectie als die nog niet bestaat
$oTextFile = fopen("log/scorsboeklog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);

unset($fprs);

//Verwijder ongeoorloofde karakters van inputstrings
//'Level 1 is strenger
function cleaninput($ipar, $level){
	$acx=str_replace("<", "",$ipar);
	$acx=str_replace(">", "",$acx);
	$acx=str_replace(";", "",$acx);
	$acx=str_replace("]", "",$acx);
	$acx=str_replace("[", "",$acx);
	$acx=str_replace("{", "",$acx);
	$acx=str_replace("}", "",$acx);
	$acx=str_replace("%", "",$acx);
	$acx=str_replace("'", "",$acx);
	if ($level==1){
		$acx=str_replace("(", "",$acx);
		$acx=str_replace(")", "",$acx);
		$acx=str_replace(",", "",$acx);
		$acx=str_replace("%", "",$acx);
		$acx=str_replace(".", "",$acx);
	}
	return $acx;
}

//Voeg HTML code toe aan invoerstring om de zoekwoorden met gele achtergrond te markeren
//Indien compact=1 dan spaties negeren bij het vinden van de zoekwoorden (dus het woord erger wordt ook gevonden in de string: er geruime tijd)
function markeerzoekwoorden($invoerstring, $compact){
	global $zkw,$rechten,$zkwoorden,$mkstart,$mkeind,$zoek;
	$dezestring=$invoerstring;
	$mkgevonden=false;
	if (strlen($dezestring)>0){
		for ($mkteller=0;$mkteller<$zkw;$mkteller++){ //aantal zoekwoorden
			$zinpointer=1;
			$woordpointer=1;
			$mkstart[$mkteller]=0;
			$mkeind[$mkteller]=0;
			$mkzk=$zkwoorden[$mkteller];
			$mklengte=strlen($mkzk);
			$mksuspend=0;
			if ($mklengte>1){
				while ($zinpointer<=strlen($dezestring) and $woordpointer<=$mklengte){
					$mkhulp=strtolower(substr($dezestring,$zinpointer-1,1));
					if ($mkhulp=="<" or $mkhulp==chr(16)){
						//skip eventueel aanwezige HTML code: <
						$mksuspend=1;
					}elseif($mkhulp==strtolower(substr($mkzk,$woordpointer-1,1)) and $mksuspend==0){
						if ($woordpointer==1){
							$mkstart[$mkteller]=$zinpointer;
						}else{
							$mkeind[$mkteller]=$zinpointer;
						}
						$woordpointer=$woordpointer+1;
					}elseif($mkhulp==chr(16) or $mkhulp==chr(17) or $mksuspend==1){
						if ($mkhulp==">" or $mkhulp==chr(17)){$mksuspend=0;} //Einde HTML code >
					}elseif($mksuspend==0 and !($mkhulp==" " and $compact>0)){
						if (strpos(strtolower($dezestring), strtolower($mkzk))!==false and $mkstart[$mkteller]>0){$zinpointer=$mkstart[$mkteller];}
						$mkstart[$mkteller]=0;
						$mkeind[$mkteller]=0;
						$woordpointer=1;
					}
					$zinpointer=$zinpointer+1;
				}
				if ($woordpointer>$mklengte){
					$mkhulp="";
					$mkgevonden=true;
					if ($mkstart[$mkteller]>1){$mkhulp=substr($dezestring,0,$mkstart[$mkteller]-1);}
					$dezestring=$mkhulp.chr(16).substr($dezestring,$mkstart[$mkteller]-1,$mkeind[$mkteller]-$mkstart[$mkteller]+1).chr(17).substr($dezestring,$mkeind[$mkteller]);
				}
			}
		}
		if ($mkgevonden==true and $compact==1){
			return str_replace(chr(17),"</span>",str_replace(chr(16),"<span class=".chr(39)."markeer".chr(39).">",$dezestring));
		}elseif ($mkgevonden==true and ($compact==2 or $compact==0)){
			return str_replace(chr(16),"<font style=".chr(39)."background-color:#FFFF00;color:#000000;".chr(39).">",str_replace(chr(17),"</font>",$dezestring));
		}else{
			return $dezestring;
		}
	}else{
		return $dezestring;
	}
}


if ($rechten=="mo" or $rechten=="sup"){ ?>
	<div style="display:none;"><iframe src="" id="fou" name="fou" width=225 height=500 scrolling="yes" frameborder="0" onload="checkresult();"></iframe></div>
<?php
}
//Lees de input parameters
$sort="titelasc";$zoek="";$vi="li";$hulppg=0;$pg=1;
if (isset($_REQUEST["sort"])){$sort=cleaninput(strtolower($_REQUEST["sort"]),1);}
if (strlen($sort)==0){$sort="titelasc";}
if (isset($_REQUEST["vi"])){$vi=cleaninput(strtolower($_REQUEST["vi"]),1);}
if ($vi!="ga"){$vi="li";}
if (isset($_REQUEST["zoek"])){$zoek=cleaninput(strtolower($_REQUEST["zoek"]),1);}
if(isset($_REQUEST['pg'])){$hulppg=cleaninput($_REQUEST["pg"],1);}
if (is_numeric($hulppg)){
	$pg=0+$hulppg;
	if ($pg==0){$pg=1;}
}
if ($pg==0){$pg=1;}
if ($vi=="li"){$pagesize=35;}else{$pagesize=100;}
$ios=false;
if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPad')) {$ios=true;}
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();
$mkstart=array_fill(0, 16, '');$mkeind=array_fill(0, 16, '');
?>

<div align="center" id="top" style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;">
<br>
<!-- ZOEKBLOK-->
<div align="center">
<table><tr><td colspan="3" align="center">
	<table border="0" style="display:inline;float:left;border-collapse:collapse;"><tr><td>
		<input class="bbz" type="text" id="zoek" value="<?php echo $zoek; ?>" size="25" onkeypress="keyPressListener(event);">&nbsp;
		<button class="ggbutton" onclick="getcontainer('<?php echo $sort; ?>',$('#zoek').val(),'<?php echo $vi; ?>',1);">Zoek</button>&nbsp;
		<button class="ggbutton" onclick="getcontainer('<?php echo $sort; ?>','','<?php echo $vi; ?>',1);">Wis</button>
		&nbsp;&nbsp;&nbsp;&nbsp;
		<?php if($rechten=="mo" or $rechten=="sup"){ ?>
		<button class="ggbutton" onclick="nieuw();">Nieuw boek/serie</button>&nbsp;
		<a data-fancybox="log" data-type="iframe" href="log/scorsboeklog.txt?t=<?php echo $diffSeconds; ?>">
		<button class="ggbutton">Open logfile</button></a>
		<?php } ?>
		&nbsp;&nbsp;&nbsp;&nbsp;

	</td></tr></table>
	<table border="0" style="display:inline;float:left;border-collapse:collapse;"><tr><td>
		<font style="font-size:14px;">
		Sorteer
		<select class="bbz" id="sort" name="sort" onchange="getcontainer($('#sort').val(),$('#zoek').val(),'<?php echo $vi; ?>',1);">
			<option <?php if ($sort=="tsdesc"){ echo "selected"; } ?> value="tsdesc">Meest recent toegevoegd</option>
			<option <?php if ($sort=="titelasc"){ echo "selected"; } ?> value="titelasc">Titel oplopend</option>
			<option <?php if ($sort=="titeldesc"){ echo "selected"; } ?> value="titeldesc">Titel aflopend</option>
			<option <?php if ($sort=="auteurasc"){ echo "selected"; } ?> value="auteurasc">Auteur oplopend</option>
			<option <?php if ($sort=="auteurdesc"){ echo "selected"; } ?> value="auteurdesc">Auteur aflopend</option>
			<option <?php if ($sort=="uitgeverasc"){ echo "selected"; } ?> value="uitgeverasc">Uitgever oplopend</option>
			<option <?php if ($sort=="uitgeverdesc"){ echo "selected"; } ?> value="uitgeverdesc">Uitgever aflopend</option>
			<option <?php if ($sort=="jaarasc"){ echo "selected"; } ?> value="jaarasc">Jaar oplopend</option>
			<option <?php if ($sort=="jaardesc"){ echo "selected"; } ?> value="jaardesc">Jaar aflopend</option>
			<option <?php if ($sort=="tsedesc"){ echo "selected"; } ?> value="tsedesc">Meest recent aangepast</option>
		</select>
	</td></tr></table>
</tr></td></table>
</div>
<br>

<?php
//construeer de SQL string
$zoek=str_replace("+"," ",$zoek);
$zoek=str_replace("-"," ",$zoek);
$zoek=str_replace("%20", " ",$zoek);
$zoek=str_replace("%", "",$zoek);
$zoek=str_replace(chr(34), "",$zoek);
while (strpos($zoek,"  ")!==false){$zoek=str_replace("  ", " ",$zoek);}
$zoek=trim($zoek);$zkw=0;$somstuk="";
if (strlen($zoek)>0 and strpos($zoek," ")!==false){
	$zkwoorden=explode(" ",$zoek);$zkw=sizeof($zkwoorden);
	for ($i=0;$i<$zkw;$i++){
		if ($i>0){$somstuk=$somstuk." AND ";}
		$somstuk=$somstuk."(ID like '%".$zkwoorden[$i]."%' OR ISBN like '%".$zkwoorden[$i]."%' OR opm like '%".$zkwoorden[$i]."%' OR titel like '%".$zkwoorden[$i]."%' OR auteur like '%".$zkwoorden[$i]."%' OR uitgever like '%".$zkwoorden[$i]."%' OR jaar like '%".$zkwoorden[$i]."%')";
	}
	$somstuk=" WHERE (".$somstuk.")";
}else if(strlen($zoek)>0){	
	$somstuk=" WHERE (ISBN&' '&ID&' '&titel&' '&uitgever&' '&auteur&' '&jaar&' '&opm like '%".$zoek."%')";
}
$orderstuk=" ORDER BY ".str_replace("desc"," desc",str_replace("asc"," asc",$sort));
$fp_sQry="SELECT * FROM boeken ".$somstuk.$orderstuk;
$fp_sQryCount="SELECT COUNT(*) as aantal FROM boeken ".$somstuk;
//	echo $fp_sQry."<br>";
//	echo $fp_sQryCount."<br>";
//Doe de query
$fprs=odbc_exec($objConnect,$fp_sQryCount);
$aantalrecords=0;
if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];}
if ($aantalrecords>0){
	$fprs=odbc_exec($objConnect,$fp_sQry);
	//move to position
	$CurrentPage=$pg;
	$PageCount=intdiv($aantalrecords,$pagesize)-(($aantalrecords%$pagesize)==0)+1;
	if ($CurrentPage<1){$CurrentPage=1;}
	if ($CurrentPage>$PageCount){$CurrentPage=$PageCount;}
	$regelteller=0;
	$navpos=1;
	include 'bbdivnav.php';
	$navpos=0;
	if ($vi=="li"){	 //Lijstweergave
		?>
		<br><br>
		<table id="bblijst" width="100%" class="bcollapse" bordercolor="lightgrey" border="0" align="center" style="user-select: text;">
		<tr><td colspan="<?php if($rechten=="mo" or $rechten=="sup"){echo "3";}else{echo "2";} ?>"><hr></td></tr>
		<?php
		while(true){
			$positieteller=($pagesize*($pg-1))+$regelteller+1;
			if ($regelteller>=$pagesize){break;}
			if($positieteller>$aantalrecords){break;}
			if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
			$Key=$fp_rs["Key"];
			$fototitel="Preview: ".$fp_rs["Titel"];
			$bestandstype=$fp_rs["bestandstype"];
			if(strlen($fp_rs["Jaar"])>0){$fototitel=$fototitel.", ".$fp_rs["Jaar"];}
			?>
			<tr><td width="125" rowspan="2" class="vmidden" style="padding-top: 5px;padding-bottom: 5px;white-space:nowrap;" align="left">
				<?php
				$fotonaam=$fp_rs["foto"];
				if(strlen($fotonaam)>0){
					if ($bestandstype=="pdf"){ ?>
						<a id="fb<?php echo $Key; ?>" data-type="iframe" data-fancybox="boeken" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $basis."BB/".$fotonaam.".pdf"; ?>&zoom=page-fit" data-caption="<?php echo $fototitel; ?>" title=""><img class="bbthumb" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."BB/".$fotonaam."ga.jpg"; ?>" /></a>
					<?php
					}else{ ?>
						<a id="fb<?php echo $Key; ?>" data-type="" data-fancybox="boeken" href="<?php echo $basis."BB/".$fotonaam."JPG.".$bestandstype; ?>" data-caption="<?php echo $fototitel; ?>" title=""><img class="bbthumb" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."BB/".$fotonaam."ga.jpg"; ?>" /></a>
					<?php	
					}
				}else{ ?>
					<img class="bbthumb" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."images/qplaceholder.gif"; ?>" />
				<?php
				}
				if($rechten=="mo" or $rechten=="sup"){ ?>
					<div align="center" id="wachtimg<?php echo $Key; ?>" style="display:none;"><img src="<?php echo $basis; ?>/images/wacht.gif"></div>
					<form name="addfoto<?php echo $Key; ?>" action="<?php echo $basis; ?>bbful.php?sleutel=<?php echo $Key; ?>&t=<?php echo time(); ?>" target="fou" method="POST" enctype="multipart/form-data">
						<label class="bbedf fileContainer">
							&nbsp;Upload Preview&nbsp;<input type="file" id="fotoc<?php echo $Key; ?>" name="orgfilename" size="1" OnChange="wijzigfoto('<?php echo $Key; ?>');"/>
						</label>
					</form>
				<?php
				}
				?>
			</td><td colspan="<?php if($rechten=="mo" or $rechten=="sup"){echo "2";}else{echo "1";} ?>" style="padding-left:6px;" align="left" <?php if($rechten!="mo" and $rechten!="sup"){ ?>height="3"<?php } ?>>
				<?php if($rechten=="mo" or $rechten=="sup"){ ?>
					<i>Titel:&nbsp;</i>
					<input class="bbTitel" id="v<?php echo $Key; ?>Titel" type="text" value="<?php echo $fp_rs["Titel"]; ?>" onchange="editboek('<?php echo $Key; ?>','Titel');">
				<?php
				} ?>
			</td></tr><tr><td class="vtop" width="325" align="left" style="padding-left: 5px;">
				<?php if($rechten!="mo" and $rechten!="sup"){ ?>
					<b><?php echo $fp_rs["Titel"]; ?></b><br><br>
				<?php
				}
				$veldnamen=array("Auteur", "Uitgever", "Jaar","Blz","ISBN","ID", "tekoop"); ?>
				<table border=0 class="layoutfixed dispinline bcollapse" bordercolor="lightgrey">
				<?php if($rechten=="mo" or $rechten=="sup"){ ?>
					<tr><td class="vtop" align="left"><i>Auteur:&nbsp;</i></td><td colspan="2"><input class="bbAuteur" id="v<?php echo $Key; ?>Auteur" type="text" value="<?php echo $fp_rs["Auteur"]; ?>" onchange="editboek('<?php echo $Key; ?>','Auteur');"></td></tr>
					<tr><td class="vtop" align="left"><i>Uitgever:&nbsp;</i></td><td colspan="2"><input class="bbUitgever" id="v<?php echo $Key; ?>Uitgever" type="text" value="<?php echo $fp_rs["Uitgever"]; ?>" onchange="editboek('<?php echo $Key; ?>','Uitgever');"></td></tr>
					<tr><td align="left"><i>Jaar:&nbsp;</i></td><td><input class="bbJaar" id="v<?php echo $Key; ?>Jaar" type="text" value="<?php echo $fp_rs["Jaar"]; ?>" onchange="editboek('<?php echo $Key; ?>','Jaar');"></td>
					<td align="left"><i>Aantal&nbsp;blz:&nbsp;</i><input class="bbJaar" id="v<?php echo $Key; ?>Blz" type="text" value="<?php echo $fp_rs["Blz"]; ?>" onchange="editboek('<?php echo $Key; ?>','Blz');"></td></tr>
					<tr><td class="vtop" align="left"><i>ISBN:&nbsp;</i></td><td colspan="2"><input class="bbISBN" id="v<?php echo $Key; ?>ISBN" type="text" value="<?php echo $fp_rs["ISBN"]; ?>" onchange="editboek('<?php echo $Key; ?>','ISBN');"></td></tr>
					<tr><td class="vtop" align="left"><i>ID:&nbsp;</i></td><td colspan="2"><input class="bbID" id="v<?php echo $Key; ?>ID" type="text" value="<?php echo $fp_rs["ID"]; ?>" onchange="editboek('<?php echo $Key; ?>','ID');"></td></tr>
					<tr><td colspan="3">
						<?php
						$toevoeger=$fp_rs["toevoeger"];$toevoeger=explode("@",$toevoeger)[0];if($toevoeger!=""){$toevoeger=" (".$toevoeger.")";}
						$aanpasser=$fp_rs["aanpasser"];$aanpasser=explode("@",$aanpasser)[0];if($aanpasser!=""){$aanpasser=" (".$aanpasser.")";}
						$opvoerdatum=date("d M Y",$fp_rs["ts"]);$wijzigdatum=date("d M Y",$fp_rs["tse"]);
						?>
						<font class="tekst1"><i>
						Toegevoegd&nbsp;<?php echo $opvoerdatum.$toevoeger; ?>&nbsp;&nbsp;
						<?php if(($fp_rs["ts"]!=$fp_rs["tse"]) and $fp_rs["tse"]>0){ ?>	Aangepast&nbsp;<?php echo $wijzigdatum.$aanpasser; ?><?php } ?>
						</i></font>
					</td></tr>
				<?php
				}else{
					if(strlen($fp_rs["Auteur"])>0){ ?><tr><td class="vtop" align="left"><i>Auteur:&nbsp;</i></td><td width="250"><?php echo markeerzoekwoorden($fp_rs["Auteur"],0); ?></td></tr><?php } ?>
					<?php if(strlen($fp_rs["Uitgever"])>0){ ?><tr><td class="vtop" align="left"><i>Uitgever:&nbsp;</i></td><td><?php echo markeerzoekwoorden($fp_rs["Uitgever"],0); ?></td></tr><?php } ?>
					<?php if(strlen($fp_rs["Jaar"])>0){ ?><tr><td class="vtop" align="left"><i>Jaar:&nbsp;</i></td><td><?php echo markeerzoekwoorden($fp_rs["Jaar"],0); ?></td></tr><?php } ?>
					<?php if(strlen($fp_rs["Blz"])>0){ ?><tr><td class="vtop" align="left"><i>Blz:&nbsp;</i></td><td><?php echo $fp_rs["Blz"]; ?></td></tr><?php } ?>
					<?php if(strlen($fp_rs["ISBN"])>0){ ?><tr><td class="vtop" align="left"><i>ISBN:&nbsp;</i></td><td><?php echo markeerzoekwoorden($fp_rs["ISBN"],0); ?></td></tr><?php } ?>
					<?php if(strlen($fp_rs["ID"])>0){ ?><tr><td class="vtop" align="left"><i>ID:&nbsp;</i></td><td><?php echo markeerzoekwoorden($fp_rs["ID"],0); ?></td></tr><?php } ?>
					<tr><td colspan="2"><hr class="bcollapse" style="height:1px;color:lightgrey;"></td></tr>
				<?php } ?>
				</table>
				<?php if($rechten!="mo" and $rechten!="sup"){ ?>
					<table border=0 class="layoutfixed dispinline bcollapse" bordercolor="lightgrey"><tr><td>&nbsp;&nbsp;&nbsp;</td></tr></table>
				<?php } ?>
				<table border=0 width="290" class="layoutfixed dispinline bcollapse"><tr><td>
				<?php if($rechten=="mo" or $rechten=="sup"){ ?>
					<textarea rows="8" class="bbopm" id="v<?php echo $Key; ?>opm" onchange="editboek('<?php echo $Key; ?>','opm');"><?php echo $fp_rs['opm']; ?></textarea><br>
					<?php
				}else{
					echo markeerzoekwoorden(preg_replace('/((http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?)/', '<a href="\1">\1</a>', $fp_rs["opm"]),0);
				} ?>
				</td></tr></table>
			</td>
			<?php if($rechten=="mo" or $rechten=="sup"){ ?>
				<td width="20" class="vmidden"  align="center" style="padding-left:5px;"><button class="ggbutton" onclick="delregel('<?php echo $Key; ?>');">Del</button></td>
			<?php } ?>
			</tr><tr><td colspan="<?php if($rechten=="mo" or $rechten=="sup"){echo "3";}else{echo "2";} ?>"><hr></td></tr>
			<?php
			$regelteller++;
		} //next record
		//EINDE LIJSTWEERGAVE
		?>
		</table>
		<br>
		<?php
	}else{ //Galerijweergave
		?>
		<div style="margin:0px 0px;">
		<table class="bcollapse" width="100%"><tr>
		<td class="vtop">
		
		<?php
		while(true){
			$positieteller=($pagesize*($pg-1))+$regelteller+1;
			if ($regelteller >= $pagesize){break;}
			if($positieteller>$aantalrecords){break;}
			if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
			$Key=$fp_rs["Key"];
			$fototitel=$fp_rs["Titel"];
			$bbopm=$fp_rs["opm"];
			$identifier=$fp_rs["ID"];
			$bestandstype=$fp_rs["bestandstype"];
			if(strlen($fp_rs["Jaar"])>0){$fototitel=$fototitel." (".$fp_rs["Jaar"].")";}
			$fotonaam=$fp_rs["foto"];
			$popuptekst="";
			if(strlen($bbopm)>0 or strlen($identifier)>0){
				if(strlen($identifier)>0){$popuptekst="<i>(ID:&nbsp".$identifier.")</i>&nbsp;";}
				if(strlen($bbopm)>0){$popuptekst.=markeerzoekwoorden($bbopm,2);}
			} ?>					
			
			<TABLE class="aac layoutfixed dispinline"><TR> <!-- 1 foto -->
			
				<td width="188">
					<table class="layoutfixed bcollapse" border="0" width="188"><tr>
					<td align="center" width="188" height="188" class="vmidden fotobg">
						<div align="center">
							<table cellpadding="0" cellspacing="0" border="0" class="bcollapse"><tr><td align="center" height="188" width="188" class="vmidden">
								<div align="center">
									<?php
									if(strlen($fotonaam)>0){
										if ($bestandstype=="pdf"){ ?>
											<a class="info2 deconone" id="fb<?php echo $Key; ?>" data-type="iframe" data-fancybox="boeken" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $basis."BB/".$fotonaam.".pdf"; ?>&zoom=page-fit" data-caption="<?php echo "Preview: ".$fototitel; ?>" title="">
											<img class="bbthumb" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."BB/".$fotonaam."ga.jpg"; ?>" /><?php if(strlen($popuptekst)>0){ ?><span><font class="aatekst2"><?php echo $popuptekst; ?></font></span><?php } ?></a>
										<?php
										}else{ ?>
											<a class="info2 deconone" id="fb<?php echo $Key; ?>" data-type="" data-fancybox="boeken" href="<?php echo $basis."BB/".$fotonaam."JPG.".$bestandstype; ?>" data-caption="<?php echo $fototitel; ?>" title="">
											<img class="bbthumb" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."BB/".$fotonaam."ga.jpg"; ?>" /><?php if(strlen($popuptekst)>0){ ?><span><font class="aatekst2"><?php echo $popuptekst; ?></font></span><?php } ?></a>
										<?php	
										}
									}else{ ?>
										<img class="bbthumb info2 deconone" id="fotoa<?php echo $Key; ?>" src="<?php echo $basis."images/qplaceholder.gif"; ?>" /><?php if(strlen($popuptekst)>0){ ?><span><font class="aatekst2"><?php echo $popuptekst; ?></font></span><?php } ?>
									<?php
									} ?>
								</div>
							</td></tr></table>
							</div>
						</div>
					</td>
					</tr><tr>
					<td class="fotobg vtop" height="128" style="user-select: text;">
						<div style="margin:3px;">
						<font class="tekstgridtitel"><?php echo markeerzoekwoorden($fototitel,0); ?></font>
					</div>
					</td></tr><tr><td height="19" colspan="3">
					</td>
					</tr></table>
				</td>
				<td width="10"></td>				
			
			</TR></TABLE> <!-- Eind 1 foto -->
			
			<?php
			$regelteller++;
		} //next record ?>
		<td width="8"></td>
		</tr></table>
		</div>
	<?php
	}
	include "bbdivnav.php";
}else{ ?>
	<br><br>Geen resultaten gevonden voor &#39;<?php echo $zoek; ?>&#39;.
<?php
} ?>
</div>
<br><br>
<?php
odbc_free_result($fprs);
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
?>
<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td>
	<br>
	<div align="right"><font class="copynotice">SCORS&nbsp;v3.0&nbsp;<?php if ($rechten=="mo" or $rechten=="sup"){echo "Administratie&nbsp;";} ?>&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font></div>
</td></tr></table>
