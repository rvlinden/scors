// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

seldestination='';volgnummer=0;wisselsrcnr='';wisseldestnr='';wisselsrcsleutel='';wisseldestsleutel='';wisselstatus='OK';var onthouhref='';
var uploadstatus=['OK','OK','OK','OK','OK','OK','OK','OK','OK','OK','OK','OK','OK'];startloop=true;Fsleutel=['','','','','','','','','','','','',''];
framehook='';framepos='';aantalloaded=0;backupinhoud="";oudvolgnummer=0;

function namenlijst(letter){
	var url=vlinden+"bpshowstatus.php?aktie=naamlijst&letter="+letter;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET",url,false);
	xmlhttp.setRequestHeader("vm",$('#vm').val());
	xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	document.getElementById('alfabetdiv').innerHTML=xmlhttp.responseText;
return;}
function ocradd(sleutel,nr){
	var answer=confirm("Weet U zeker dat u tekstherkenning wil doen op document of foto "+nr+"?\nDit kan alleen ongedaan worden gemaakt door het origineel opnieuw te uploaden.\n\nTekstherkenning kan enige tijd duren.Het resultaat is pas zichtbaar nadat u het scherm heeft ververst.");
	if (answer){
		$("#ocrknop"+sleutel+nr).prop("disabled", true);
		$("#ocrknop"+sleutel+nr).prop("value", "TXT bezig");
		$("#fb"+sleutel+nr).prop("href", "images/ocrbezig-ocrpen.jpg");
		$("#updel"+nr+sleutel).hide();
		$("#fb"+sleutel+nr).fancybox({preload:false});
		window.frames['fou'+nr].location.href='bpadmin.php?aktie=ocradd&Key='+sleutel+'&nr='+nr;
	}
	return;}
function wijzigfoto(nr,sleutel) {
	Fsleutel[nr]=sleutel;var uploadfout=false;var archiefnummer=$('#archiefnr'+sleutel).val();
	if (uploadstatus[nr]=='NOK'){alert('Vorige upload nog niet klaar. Probeer opnieuw zodra deze klaar is.\nVervers het scherm als de fout niet verdwijnt.');uploadfout=true;}
	if (archiefnummer.length<6||archiefnummer=='999999'){alert('Voor u een foto kunt toevoegen moet eerst het archiefnummer correct worden ingevuld.');uploadfout=true;}
	if (uploadfout==false){
		relfocus();selframepos('framehook'+sleutel);
		uploadstatus[nr]='NOK';
		if(nr>0){
			$(".uploadhide"+sleutel+nr).addClass("onzichtbaar");
			$(".uploadshow"+sleutel+nr).removeClass("onzichtbaar");
		}
		document.getElementById('ineditlog').src='/images/red.png';
		document.forms['addfoto'+sleutel+'f'+nr].submit();
	}
	return;}
function checkarchiefnummer(sleutel,nummer){
	var archiefnummer=$('#archiefnr'+sleutel).val();
	if (archiefnummer.length<6||archiefnummer=='999999'){alert('Voor u een foto kunt toevoegen moet eerst het archiefnummer correct worden ingevuld.');}
	return;}
function verwijderfoto(nr,sleutel) {
	var answer=confirm("Weet U zeker dat u foto "+nr+" wilt verwijderen?");
	if (answer){
		$("#fotoa"+nr+sleutel).prop("src", "images/legefoto.gif");
		window.frames['fou'+nr].location.href='bpadmin.php?aktie=delfile&Key='+sleutel+'&nr='+nr;
		$("#fb"+sleutel+nr).prop("href", "images/legefoto2.gif");
		$("#fb"+sleutel+nr).fancybox({preload:false});
		$("#ocrknop"+sleutel+nr).prop("value", "---");
		document.getElementById("ocrknop"+sleutel+nr).setAttribute("onclick", "");
	}
	return;}
function verwijderrecord(sleutel){
	var nogfotos=false;
	for(var di=1;di<=12;di++){if($('#fb'+sleutel+di).prop("href").indexOf("egefoto2.gif")<1){nogfotos=true;}}
	if (nogfotos==true){alert("Dit object bevat nog foto's of documenten. Verwijder deze eerst alvorens het object te verwijderen.");}
	else{
		var answer=confirm("Weet U zeker dat U het gehele object wilt verwijderen?");
		if (answer){
			var url='bpadmin.php?aktie=delrec&Key='+sleutel;
			var archiefnr=$('#archiefnr'+sleutel).val();
			var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
			var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
			document.getElementById('rec'+sleutel).style.display='none';
			checknr(archiefnr,sleutel);
		}
	}
	return;}
function checknr(archiefnr,sleutel){
	var url='bpadmin.php?aktie=checknr&archiefnr='+archiefnr+'&Key='+sleutel;
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	var resultaat=xmlhttp.responseText;
	return resultaat;}
function archiefnummer(sleutel){
	var archiefint=$('#archiefnr'+sleutel).val().replace(/[^0-9]/g, "");
	$('.uploadknop'+sleutel).prop( "disabled", false);
	$('.uploadhide'+sleutel).show();
	$('#fout'+sleutel).hide();
	if (archiefint==''||parseInt(archiefint)<100000||parseInt(archiefint)>999998){
		alert('Ongeldig archiefnummer.\nHet archiefnummer moet uit 6 cijfers bestaan en liggen tussen 100000 en 999999.\n\nPas het archiefnummer aan.');
		$('#fout'+sleutel).show();$('#archiefnr'+sleutel).val(archiefint);		
		$('.uploadknop'+sleutel).prop( "disabled", true);
		$('.uploadhide'+sleutel).hide();
	}
	if (checknr(archiefint,sleutel).indexOf('OK')==-1){
		alert('Dit archiefnummer is al in gebruik.\nHet nummer dient uniek te zijn.\n\nPas het archiefnummer aan.');
		$('#fout'+sleutel).show();
		$('.uploadknop'+sleutel).prop( "disabled", true);
		$('.uploadhide'+sleutel).hide();
	}
	return;}
function veldupdate(sleutel,veldnaam,hoofdletter) {
	if (hoofdletter==1){
		var oudewaarde=$('#'+veldnaam+sleutel).val();
		if (oudewaarde.length>0){
			$('#'+veldnaam+sleutel).val(oudewaarde.charAt(0).toUpperCase() + oudewaarde.slice(1));
		}
	}
	document.getElementsByName('backup')[volgnummer].value=backupinhoud;
	document.getElementsByName('realfield')[volgnummer].value=veldnaam;
	document.getElementsByName('Key')[volgnummer].value=sleutel;
	if(veldnaam=='beschrijving'){
		var fieldcontent=$('#beschrijving'+sleutel).val();
		while(fieldcontent.indexOf("<br/>")>=0){fieldcontent=fieldcontent.replace("<br/>","<br>");}
		while(fieldcontent.indexOf("<p>")>=0){fieldcontent=fieldcontent.replace("<p>","");}
		while(fieldcontent.indexOf("</p>")>=0){fieldcontent=fieldcontent.replace("</p>","<br>");}
		while(fieldcontent.indexOf("<br><br><br>")>=0){fieldcontent=fieldcontent.replace("<br><br><br>","<br><br>");}
		fieldcontent="[[stub]]"+fieldcontent+"[[stub]]";
		while(fieldcontent.indexOf("<br>[[stub]]")>=0){fieldcontent=fieldcontent.replace("<br>[[stub]]","[[stub]]");}
		while(fieldcontent.indexOf("[[stub]]<br>")>=0){fieldcontent=fieldcontent.replace("[[stub]]<br>","[[stub]]");}
		while(fieldcontent.indexOf("[[stub]]")>=0){fieldcontent=fieldcontent.replace("[[stub]]","");}
		$('#beschrijving'+sleutel).val(fieldcontent);
		$('#beschrijving'+sleutel).jqteVal(fieldcontent);
		document.getElementsByName('fieldcontent')[volgnummer].value=fieldcontent;
	}
	else if(veldnaam=='jaar'){
		var jaar=$('#'+veldnaam+sleutel).val().toString().toUpperCase();
		if(jaar.length>0){for (ji=1;ji<=4;ji++){if(jaar.length<4){jaar='0'+jaar}}}
		jaar=jaar.replace(/[^0-9]/g, '0');
		if (jaar=='0000'){jaar='';}
		$('#jaar'+sleutel).val(jaar);
		var maand=$('#maand'+sleutel).val().replace(/[^0-9]/g, "");if(maand>12){maand=12};maand=maand.toString();
		if(maand.length==1){maand='0'+maand;};if (maand=='00'){maand=''}$('#maand'+sleutel).val(maand);
		var dag=$('#dag'+sleutel).val().replace(/[^0-9]/g,"");if(dag>31){dag=31};dag=dag.toString();
		if(dag.length ==1){dag='0'+dag;};if(dag=='00'){dag='';};$('#dag'+sleutel).val(dag);
		if (maand!=''&&jaar!=''){jaar=jaar+'-'+maand;if (dag!=''){jaar=jaar+'-'+dag;}}
		document.getElementsByName('fieldcontent')[volgnummer].value=jaar;
	}
	else if(veldnaam=='jaar2'){
		var jaar2=$('#jaar2'+sleutel).val().toString().toUpperCase();
		if(jaar2.length>0){for (ji=1;ji<=4;ji++){if(jaar2.length<4){jaar2='0'+jaar2}}}
		jaar2=jaar2.replace(/[^0-9]/g, '0');
		if (jaar2=='0000'){jaar2='';}
		$('#jaar2'+sleutel).val(jaar2);
		var maand2=$('#maand2'+sleutel).val().replace(/[^0-9]/g, "");if(maand2>12){maand2=12};maand2=maand2.toString();
		if(maand2.length==1){maand2='0'+maand2;};if (maand2=='00'){maand2=''}$('#maand2'+sleutel).val(maand2);
		var dag2=$('#dag2'+sleutel).val().replace(/[^0-9]/g,"");if(dag2>31){dag2=31};dag2=dag2.toString();
		if(dag2.length ==1){dag2='0'+dag2;};if(dag2=='00'){dag2='';};$('#dag2'+sleutel).val(dag2);
		if (maand2!=''&&jaar2!=''){jaar2=jaar2+'-'+maand2;if (dag2!=''){jaar2=jaar2+'-'+dag2;}}
		document.getElementsByName('fieldcontent')[volgnummer].value=jaar2;
	}
	else{document.getElementsByName('fieldcontent')[volgnummer].value=$("#"+veldnaam+sleutel).val();}
	document.forms['edit'+volgnummer].submit();
	selframepos('framehook'+sleutel);
	oudvolgnummer=volgnummer;
	if(volgnummer==2){volgnummer=0;}else{volgnummer=volgnummer+1;}
	if (veldnaam=='archiefnr'){
		var ahulp=document.getElementById("linkarchiefnr"+sleutel);
		ahulp.onclick = null;ahulp.onclick = function(){
			if (event.ctrlKey){ctrltoets=true;};
			getcontainer('?archiefnr='+$('#archiefnr'+sleutel).val()+'&uz='+$('#uz').val()+'&vi='+$('#vi').val());
			return false;
		}
	}
	return;}
function veldupdateraw(sleutel) {
	document.getElementsByName('backup')[volgnummer].value=backupinhoud;
	document.getElementsByName('realfield')[volgnummer].value='beschrijving';
	document.getElementsByName('Key')[volgnummer].value=sleutel;
	document.getElementsByName('fieldcontent')[volgnummer].value=$("#beschrijvingraw"+sleutel).val();
	document.forms['edit'+volgnummer].submit();
	selframepos('framehook'+sleutel);
	oudvolgnummer=volgnummer;
	if(volgnummer==2){volgnummer=0;}else{volgnummer=volgnummer+1;}
	return;}
function toggledoel(sleutel){
	var doel=document.getElementsByName('doel'+sleutel);
	var doelletter=['v','e','p'];var doelnummer=1;
	for (var i=0;i<doel.length;i++){if (doel[i].checked){doelnummer=[i];}}
	for (var i=0;i<doel.length;i++){doel[i].value=doelletter[doelnummer];}
	return;}
function togglep(){
	var letters=['v','e','p'];var p='';
	for (var i=0;i<=2;i++){if(document.getElementById('vep'+letters[i]).checked){p=p+letters[i];}else{p=p+'_';}}
	$('#aap').val(p);
	return;}
function relpath(pad){relpad=String(pad).substring(19);return relpad;}
function selfocus(veldnaam,Key) {
	if(veldnaam=='jaar'||veldnaam=='maand'||veldnaam=='dag'){
		backupinhoud='j'+$("#jaar"+Key).val()+' m'+$("#maand"+Key).val()+' d'+$("#dag"+Key).val();
	}
	else if(veldnaam=='jaar2'||veldnaam=='maand2'||veldnaam=='dag2'){
		backupinhoud='j'+$("#jaar2"+Key).val()+' m'+$("#maand2"+Key).val()+' d'+$("#dag2"+Key).val();
	}
	else{
		backupinhoud=$("#"+veldnaam+Key).val();
	}
	if(veldnaam=='beschrijving'){$('#cleanknop'+Key).show();}
	relfocus();selframepos('framehook'+Key);
	document.getElementById('ineditlog').src='/images/red.png';
	$("#"+veldnaam+Key).removeClass("edf");$("#"+veldnaam+Key).addClass("inedit");
	seldestination=document.getElementById(veldnaam+Key);
	if(veldnaam=='archiefnr' && $('#archiefnr'+Key).val()=='999999'){$('#archiefnr'+Key).val('');}
	return;}
function relfocus(){
	document.getElementById('ineditlog').src='/images/green.png';
	$(seldestination).removeClass('inedit');$(seldestination).addClass('edf');
	seldestination='';
	return;}
function selframepos(veldnaam){
// variabele veldnaam='framehook'+sleutel
	yframepos=getElTop(document.getElementById(veldnaam))-10;
	xframepos=getElLeft(document.getElementById(veldnaam))+15;
	document.getElementById('selframes').style.top=yframepos+'px';
	document.getElementById('selframes').style.left=xframepos+'px';
	document.getElementById('selframes').style.display='block';
	framepos=veldnaam;
	return;}
function getElLeft(el) {
	xPos=el.offsetLeft;tempEl=el.offsetParent;
	while (tempEl != null) {xPos += tempEl.offsetLeft;tempEl=tempEl.offsetParent;}
	return xPos;}
function getElTop(el) {
	yPos=el.offsetTop;tempEl=el.offsetParent;
	while (tempEl != null) {yPos += tempEl.offsetTop;tempEl=tempEl.offsetParent;}
	return yPos;}
function onderwater(sleutel){
	if ($("#previewstat"+sleutel).val()=='uit'){
		if ($('#togglestat'+sleutel).val()==''){
			veldupdate(sleutel, 'beschrijving', 1);
			$('#beschrijvingraw'+sleutel).val($('#beschrijving'+sleutel).val());
			$('#togglejqte'+sleutel).hide();
			$('#toggleraw'+sleutel).show();
			$('#togglestat'+sleutel).val('raw');
			$('#owknop'+sleutel).val('txt');
		}
		else {
			veldupdateraw(sleutel);
			$('#beschrijving'+sleutel).val($('#beschrijvingraw'+sleutel).val());
			$("#beschrijving"+sleutel).jqteVal($('#beschrijvingraw'+sleutel).val());
			$('#toggleraw'+sleutel).hide();
			$("#toggletitle"+sleutel).show();
			$('#togglejqte'+sleutel).show();
			$('#togglestat'+sleutel).val('');
			$('#owknop'+sleutel).val('html');
		}
	}
	return;}	
function preview(sleutel){
	if ($("#previewstat"+sleutel).val()=='uit'){
		if($('#togglestat'+sleutel).val()=='raw'){veldupdateraw(sleutel)}
		else{veldupdate(sleutel, 'beschrijving', 1);}
		var url="bpshowstatus.php?aktie=preview&Key="+sleutel;
		var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
		var inhoud=xmlhttp.responseText;
		document.getElementById('recprev'+sleutel).innerHTML=inhoud;
		$("#rec"+sleutel).hide();
		$("#recprev"+sleutel).show();
		$("#previewstat"+sleutel).val('aan');
		}
	else {
		$("#recprev"+sleutel).hide();
		$("#rec"+sleutel).show();
		$("#previewstat"+sleutel).val('uit');
		}
	return;}
function opschonen(sleutel){
	if ($("#previewstat"+sleutel).val()=='uit'){
		var temp=document.createElement('DIV');
		var erbij=$('#togglestat'+sleutel).val();
		var omtekst=$('#beschrijving'+erbij+sleutel).val();
		omtekst=omtekst.replace(/<br>/gi,'beejerr');
		omtekst=omtekst.replace(/<br\/>/gi,'beejerr');
		omtekst=omtekst.replace(/<p>/gi,'beejerrbeejerr');
		omtekst=omtekst.replace(/<\/p>/gi,'beejerr');
		temp.innerHTML=omtekst;
		var omtekstclean=temp.textContent || temp.innerText;
		omtekstclean=omtekstclean.replace(/beejerr/g, '<br>');
		$('#beschrijving'+erbij+sleutel).val(omtekstclean);
		if($('#togglestat'+sleutel).val()==''){veldupdate(sleutel,'beschrijving',1)}
		else{veldupdateraw(sleutel);}
	}
	return;}
function initwissel(nr,sleutel){
	if (wisselstatus='OK'){
		selframepos('framehook'+sleutel);wisselsrcnr=nr;wisseldestnr='';wisselsrcsleutel=sleutel;wisseldestsleutel='';
	}
	return;}
function execwissel(){
	if ((wisselsrcnr+'a'+wisselsrcsleutel)!=(wisseldestnr+'a'+wisseldestsleutel) && wisseldestnr!='' && wisselsrcnr!=''){
		if (wisselstatus='OK'){
			wisselstatus='NOK';
			var thumbsrcsave=$("#fotoa"+wisselsrcnr+wisselsrcsleutel).prop("src");
			var thumbdestsave=$("#fotoa"+wisseldestnr+wisseldestsleutel).prop("src");
			var afbsrcsave=$("#fb"+wisselsrcsleutel+wisselsrcnr).prop("href");
			var afbdestsave=$("#fb"+wisseldestsleutel+wisseldestnr).prop("href");
			var srctypesave=$("#fb"+wisselsrcsleutel+wisselsrcnr).prop("data-type");
			var desttypesave=$("#fb"+wisseldestsleutel+wisseldestnr).prop("data-type");
			var ocrsrctxtsave=$("#ocrknop"+wisselsrcsleutel+wisselsrcnr).prop("value");
			var ocrdesttxtsave=$("#ocrknop"+wisseldestsleutel+wisseldestnr).prop("value");
			var ocrsrcablesave=$("#ocrknop"+wisselsrcsleutel+wisselsrcnr).prop("disabled");
			var ocrdestablesave=$("#ocrknop"+wisseldestsleutel+wisseldestnr).prop("disabled");
			var ocrsrchrefsave=document.getElementById("ocrknop"+wisselsrcsleutel+wisselsrcnr).getAttribute("onclick");
			var ocrdesthrefsave=document.getElementById("ocrknop"+wisseldestsleutel+wisseldestnr).getAttribute("onclick");
			var ocrdesttitlesave=document.getElementById("ocrknop"+wisseldestsleutel+wisseldestnr).getAttribute("title");
			var ocrsrctitlesave=document.getElementById("ocrknop"+wisselsrcsleutel+wisselsrcnr).getAttribute("title");
			window.frames["fou"+wisselsrcnr].location.href='bpadmin.php?aktie=ruil&Key='+wisselsrcsleutel+'&srcnr='+wisselsrcnr+'&destnr='+wisseldestnr+'&Keydest='+wisseldestsleutel;
			$("#fotoa"+wisseldestnr+wisseldestsleutel).prop("src",thumbsrcsave);
			$("#fotoa"+wisselsrcnr+wisselsrcsleutel).prop("src",thumbdestsave);
			$("#fb"+wisseldestsleutel+wisseldestnr).prop("href",afbsrcsave)
			$("#fb"+wisselsrcsleutel+wisselsrcnr).prop("href",afbdestsave)
			$("#fb"+wisseldestsleutel+wisseldestnr).prop("data-type",srctypesave)
			$("#fb"+wisselsrcsleutel+wisselsrcnr).prop("data-type",desttypesave)
			$("#fb"+wisselsrcsleutel+wisselsrcnr).fancybox({preload:false});
			$("#fb"+wisseldestsleutel+wisseldestnr).fancybox({preload:false});
			$("#ocrknop"+wisselsrcsleutel+wisselsrcnr).prop("value",ocrdesttxtsave);
			$("#ocrknop"+wisseldestsleutel+wisseldestnr).prop("value",ocrsrctxtsave);
			$("#ocrknop"+wisselsrcsleutel+wisselsrcnr).prop("disabled",ocrdestablesave);
			$("#ocrknop"+wisseldestsleutel+wisseldestnr).prop("disabled",ocrsrcablesave);
			document.getElementById("ocrknop"+wisselsrcsleutel+wisselsrcnr).setAttribute("onclick",ocrdesthrefsave.replace("'"+wisseldestnr+"'","'"+wisselsrcnr+"'").replace("'"+wisseldestsleutel+"'","'"+wisselsrcsleutel+"'"));
			document.getElementById("ocrknop"+wisseldestsleutel+wisseldestnr).setAttribute("onclick",ocrsrchrefsave.replace("'"+wisselsrcnr+"'","'"+wisseldestnr+"'").replace("'"+wisselsrcsleutel+"'","'"+wisseldestsleutel+"'"));
			document.getElementById("ocrknop"+wisselsrcsleutel+wisselsrcnr).setAttribute("title",ocrdesttitlesave);
			document.getElementById("ocrknop"+wisseldestsleutel+wisseldestnr).setAttribute("title",ocrsrctitlesave);
		}
		wisselsrcsleutel='';wisseldestsleutel='';wisselsrcnr='';wisseldestnr='';
	}
	return;}
function checkedit(nr){
	if (startloop==false){
		var innerDoc=document.getElementById('fu'+nr).contentDocument || document.getElementById('fu'+nr).contentWindow.document; 
		var ongeldig=innerDoc.getElementById('ongeldig').value;
		$('.editresult').removeClass('randrood');
		$('.editresult').addClass('randgeen');
		$('#fu'+nr).removeClass('randgeen');
		$('#fu'+nr).addClass('randrood');
		if(ongeldig){
			var hulp=innerDoc.getElementById('correctedresult').value; //vervang inhoud betreffende input met evt. gecorrigeerd resultaat
			var hulp2=document.getElementsByName('realfield')[nr].value+document.getElementsByName('Key')[nr].value; //veldnaam
			$('#'+hulp2).val(hulp);
		}
	}
	else{aantalloaded++;if(aantalloaded=='15'){startloop=false;}}
	return;}
function copyornew(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	var vrijnummer=xmlhttp.responseText.split('vrijnummer');
	getcontainer('?z=NIEUWOBJECT%20'+vrijnummer[1]+'&vi=li&uz='+$('#uz').val());
	return;}
function checkresult(nr){
	if (startloop==false){
		var innerDoc=document.getElementById('fou'+nr).contentDocument || document.getElementById('fou'+nr).contentWindow.document; 
		var innerDocOut=document.getElementById('fouresult').contentDocument || document.getElementById('fouresult').contentWindow.document; 
		innerDocOut.body.innerHTML=innerDoc.body.innerHTML;
		$('.editresult').removeClass('randrood');
		$('.editresult').addClass('randgeen');
		$('#fouresult').removeClass('randgeen');
		$('#fouresult').addClass('randrood');
		if (innerDoc.getElementById('resultaat').value=='TXT'){
			nr=0;
			hulp=innerDoc.getElementById('nieuwetekst').value.replace(/\r/g, "");
			hulp=hulp.replace(/\n/g, "<br>");
			document.getElementById('beschrijvingraw'+Fsleutel[0]).value=hulp;
			veldupdateraw(Fsleutel[0]);
			$('#beschrijving'+Fsleutel[0]).jqteVal(hulp);
		}
		else if (innerDoc.getElementById('resultaat').value=='OK'){
			if(uploadstatus[nr]=='NOK'){
				var d=new Date().getTime();
				var afbsrcnaam=innerDoc.getElementById('afbsrc').value;
				document.getElementById('fotoa'+nr+Fsleutel[nr]).src=innerDoc.getElementById('thumbsrc').value+'?t='+d;
				$("#fb"+Fsleutel[nr]+nr).prop("href", afbsrcnaam+'?t='+d);
				var framestub='';
				extensie=afbsrcnaam.split('.')[2];
				if ('jpg jpeg gif png'.indexOf(extensie)==-1){framestub='iframe';}
				if ('jpg pdf txt'.indexOf(extensie)>=0){
					$("#ocrknop"+Fsleutel[nr]+nr).prop("value", "TXT");
					document.getElementById("ocrknop"+Fsleutel[nr]+nr).setAttribute("onclick", "selframepos('framehook"+Fsleutel[nr]+"');ocradd('"+Fsleutel[nr]+"','"+nr+"');");
					document.getElementById("ocrknop"+Fsleutel[nr]+nr).removeAttribute("disabled");
				}
				else{
					$("#ocrknop"+Fsleutel[nr]+nr).prop("value", "---");
					document.getElementById("ocrknop"+Fsleutel[nr]+nr).setAttribute("onclick", "");
				}
				$("#fb"+Fsleutel[nr]+nr).prop("data-type", framestub);
				$("#fb"+Fsleutel[nr]+nr).fancybox({preload:false});
				$(".uploadshow"+Fsleutel[nr]+nr).addClass("onzichtbaar");
				$(".uploadhide"+Fsleutel[nr]+nr).removeClass("onzichtbaar");
			}
			if(wisselstatus='NOK'){wisselstatus='OK';}
		}
		else {alert('Aktie mislukt. Ververs het scherm met Ctrl-F5 en probeer opnieuw.');}
		uploadstatus[nr]='OK';var uploadsklaar=true;
		for (usi=0;usi<13;usi++){if(uploadstatus[usi]=='NOK'){uploadsklaar=false;}}
		if (seldestination=='' && uploadsklaar){document.getElementById('ineditlog').src='/images/green.png'};
	}
	else{aantalloaded++;if(aantalloaded=='15'){startloop=false;}}
	return;}
function checknummer(nummerveld){ //Controleer of velden uit cjfers bestaan
	var echtnummer=$('#'+nummerveld).val().replace(/[^0-9]/g, '0');$('#'+nummerveld).val(echtnummer);
	return;}
function togglezid(){
	var zid=document.getElementById('zid');
	if (zid.checked){zid.value='j';}else{zid.value='';}
	return;}
function zetzoek(veld){ //Markeer het actieve zoekveld
	if ($('#z').val().toLowerCase()=="recent toegevoegd"){$('#z').val('');}
	if(veld=='z' && $('#uz').val()=='n'){wiskeus('zw');wiskeus('aaw');wiskeus('aau');wiskeus('aar');wiskeus('aaa');wiskeus('j');wiskeus('j2');wiskeus('j3');wiskeus('j4');wiskeus('aas');wiskeus('aam');}
	else {wiskeus('archiefnr');}
	return;}
function wisuz() { //Wis alle keuzes
	wiskeus('z');wiskeus('zw');wiskeus('aaw');wiskeus('aau');wiskeus('aar');wiskeus('aaa');wiskeus('j');wiskeus('j2');wiskeus('j3');wiskeus('j4');wiskeus('aas');wiskeus('aam');wiskeus('archiefnr');
	var vep=document.getElementsByName('vep');for (i=0;i<vep.length;i++){vep[i].checked=true;}$('#aap').val('vep');
	var zid=document.getElementById('zid');zid.checked=false;zid.value='';
	zoekalloptions('z');
	return;}
function wiskeus(veld) {$('#'+veld).val('');return;}
function wijzigthumb(sleutel,delta,aantal) {
	var oudenr=parseInt($('#thumbgalteller'+sleutel).val());
	if (oudenr==aantal&&delta==1){delta=-aantal+1;}
	if (oudenr==1&&delta==-1){delta=aantal-1;}
	var nieuwnr=(0+oudenr+delta).toString();
	$('#thumbgal'+sleutel+oudenr.toString()).addClass("onzichtbaar");
	$('#thumbgal'+sleutel+nieuwnr).removeClass("onzichtbaar");
	$('#thumbgalteller'+sleutel).val(nieuwnr);
	return;}
function zoekalloptions(veld){
	var a='';var u='';var r='';var s='';var w='';var m='';
	a=$('#aaa').val();if (a=='null'){a='';}
	u=$('#aau').val();if (u=='null'){u='';}
	r=$('#aar').val();if (r=='null'){r='';}
	s=$('#aas').val();if (s=='null'){s='';}
	w=$('#aaw').val();if (w=='null'){w='';}
	m=$('#aam').val();if (m=='null'){m='';}
	var urlA=vlinden+"bpoptions.php?term="+a+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=a";
	var urlR=vlinden+"bpoptions.php?term="+r+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=r";
	var urlU=vlinden+"bpoptions.php?term="+u+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=u";
	var urlS=vlinden+"bpoptions.php?term="+s+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=s";
	var urlW=vlinden+"bpoptions.php?term="+w+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=w";
	var urlM=vlinden+"bpoptions.php?term="+m+"&m="+m+"&u="+u+"&s="+s+"&r="+r+"&a="+a+"&w="+w+"&veld=m";
	var xmlhttpA=new XMLHttpRequest();
	var xmlhttpR=new XMLHttpRequest();
	var xmlhttpU=new XMLHttpRequest();
	var xmlhttpS=new XMLHttpRequest();
	var xmlhttpW=new XMLHttpRequest();
	var xmlhttpM=new XMLHttpRequest();
	xmlhttpA.open("GET",urlA,false);
	xmlhttpR.open("GET",urlR,false);
	xmlhttpU.open("GET",urlU,false);
	xmlhttpS.open("GET",urlS,false);
	xmlhttpW.open("GET",urlW,false);
	xmlhttpM.open("GET",urlM,false);
	xmlhttpA.setRequestHeader("vm",$('#vm').val());
	xmlhttpR.setRequestHeader("vm",$('#vm').val());
	xmlhttpU.setRequestHeader("vm",$('#vm').val());
	xmlhttpS.setRequestHeader("vm",$('#vm').val());
	xmlhttpW.setRequestHeader("vm",$('#vm').val());
	xmlhttpM.setRequestHeader("vm",$('#vm').val());
	if (veld!='a'){xmlhttpA.send();}
	if (veld!='r'){xmlhttpR.send();}
	if (veld!='u'){xmlhttpU.send();}
	if (veld!='s'){xmlhttpS.send();}
	if (veld!='w'){xmlhttpW.send();}
	if (veld!='m'){xmlhttpM.send();}
	var countS=0;while (xmlhttpM.readystate<4||xmlhttpA.readystate<4||xmlhttpR.readystate<4||xmlhttpU.readystate<4||xmlhttpS.readystate<4||xmlhttpW.readystate<4){setTimeout(function(){countS++},50);}
	if (veld!='a'){document.getElementById('aoptions').innerHTML=xmlhttpA.responseText;}
	if (veld!='r'){document.getElementById('roptions').innerHTML=xmlhttpR.responseText;}
	if (veld!='u'){document.getElementById('uoptions').innerHTML=xmlhttpU.responseText;}
	if (veld!='s'){document.getElementById('soptions').innerHTML=xmlhttpS.responseText;}
	if (veld!='w'){document.getElementById('woptions').innerHTML=xmlhttpW.responseText;}
	if (veld!='m'){document.getElementById('moptions').innerHTML=xmlhttpM.responseText;}
	return;}
function Left(str, n){if (n<=0){return "";}else if (n>String(str).length){return str;}else{return String(str).substring(0,n);}return;}
function sct(sleutel,itemtitle, archiefnr){
	var responsetekst='';var leegveld=false;
	var mailnaam=$('#uwnaam'+sleutel).val();
	if (mailnaam=='') {responsetekst=responsetekst+'U heeft uw naam niet ingevuld\n';leegveld=true;}
	var mailfrom=$('#uwemail'+sleutel).val();
	if (mailfrom=='') {responsetekst=responsetekst+'U heeft uw email adres niet ingevuld\n';leegveld=true;}
	if (mailfrom.length>0 && (mailfrom.indexOf('@')==-1 || mailfrom.indexOf('.')==-1)) {responsetekst=responsetekst+'U heeft geen geldig email adres ingevuld';leegveld=true;}
	var mailbody=$('#uwtip'+sleutel).val();
	if (mailbody.length<3) {responsetekst=responsetekst+'U heeft geen bericht getypt';leegveld=true;}
	if (leegveld==true) {alert(responsetekst);}
	else {
		var corrparam="mailnaam="+encodeURI(mailnaam)+"&mailfrom="+encodeURI(mailfrom)+"&mailbody="+encodeURI(mailbody)+"&Key="+encodeURI(sleutel);
		corrparam=corrparam+"&itemtitle="+encodeURI(itemtitle)+"&archiefnr="+encodeURI(archiefnr);
		var xmlA=new XMLHttpRequest();xmlA.open("POST",vlinden+"bpshowstatus.php?aktie=sct",false);xmlA.setRequestHeader("Content-type", "application/x-www-form-urlencoded");xmlA.send(corrparam);
		var countA=0;while (xmlA.readystate<4){setTimeout(function(){countA++},50);}
		document.getElementById("meldresultaat"+sleutel).innerHTML=xmlA.responseText;
		$('#meldform'+sleutel).hide();$('#meldresultaat'+sleutel).show();
	}
	return;}
function getcontainer(urlquery){
	startloop=true;aantalloaded=0;
	var d=new Date().getTime();
	if(urlquery==''){urlquery='?t='+d;}else{if(urlquery.indexOf('t=1')<0){urlquery=urlquery+'&t='+d;}}
	if (backforwardused==false){history.pushState(null,null,location.href);history.replaceState(null,null,urlquery);}
	backforwardused=false;
	if (ctrltoets==true){ctrltoets=false;window.open(urlquery);window.focus();}
	else{
		$(".wachtshow").removeClass("onzichtbaar");$(".emptyshow").addClass("onzichtbaar");
		if(urlquery==''){urlquery='?';}else{urlquery=urlquery+'&';}
		var url=vlinden+"bpdiv.php"+urlquery+'&t='+d;
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET",url,false);
		xmlhttp.setRequestHeader("vm",$('#vm').val());
		xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
		document.getElementById('bpcontainer').innerHTML=xmlhttp.responseText;
	    var bounding = document.getElementById("bpcontainer").getBoundingClientRect();
		if ((bounding.top < 0 )|| (urlquery.indexOf('topshift')>0)){window.scrollTo(0,$("#bpcontainer").offset().top);}
		$("#z").autocomplete({source:vlinden+"bpoptions.php?moveld=z",minLength: 3,delay:300});
		var matchingValue='';
		$('.bron').autocomplete({source:'bpoptions.php?moveld=u',minLength: 0});
		$('.onderwerp').autocomplete({source:'bpoptions.php?moveld=r',minLength: 0});
		$('.auteur').autocomplete({source:'bpoptions.php?moveld=a',minLength: 0});
		$('.straat').autocomplete({source:'bpoptions.php?moveld=w',minLength: 0});
		$('.persoon').autocomplete({source:'bpoptions.php?moveld=m',minLength: 0});
		$(".wachtshow").addClass("onzichtbaar");$(".emptyshow").removeClass("onzichtbaar");
	}
    // Fancybox Zoom + - 
    $.fancybox.defaults.btnTpl.zoomin = '<button data-fancybox-zoomin id="fb-zoomin" class="fancybox-button fancybox-button--zoomin" title="Vergroten"><img src='+vlinden+'images/zoomin.png></button>';
    $.fancybox.defaults.btnTpl.zoomout = '<button data-fancybox-zoomout id="fb-zoomout" class="fancybox-button fancybox-button--zoomout" title="Verkleinen"><img src='+vlinden+'images/zoomout.png></button>';
    $('.fancybox-open-tk').fancybox({idleTime: 0,arrows:true,loop:true,toolbar:true,buttons: ['slideShow','download','zoomout','zoomin','thumbs','close']});
    // zoom in/out
    $('body').on('click', '[data-fancybox-zoomin]', function() {fancyboxzoom('zoomin');});
    $('body').on('click', '[data-fancybox-zoomout]', function() {fancyboxzoom('zoomout');});
	return;}
function pft(){
	$('.fancybox-open-tk').fancybox({idleTime: 0,arrows:true,loop:true,protect:true,toolbar:true,buttons: ['slideShow','zoomout','zoomin','thumbs','close']});
	return;}
function vindwaarde (urlquery,veld){
	if (urlquery.indexOf(veld)>0){
		var hulp=urlquery.split(veld);return hulp[1].split('&')[0];
	}
	return '';}
function xmltrein(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	return;}
function keyPressListener(e) {
	if (e.keyCode == 13) {aazoek()}
	return;}
function aazoek(){
	getcontainer('?vi='+$('#vi').val()+'&zid='+$('#zid').val()+'&j2='+$('#j2').val()+'&j='+$('#j').val()+'&j4='+$('#j4').val()+'&j3='+$('#j3').val()+'&s='+$('#aas').val()+'&a='+$('#aaa').val()+'&u='+$('#aau').val()+'&m='+$('#aam').val()+'&w='+$('#aaw').val()+'&r='+$('#aar').val()+'&zw='+$('#zw').val()+'&z='+$('#z').val()+'&archiefnr='+$('#archiefnr').val()+'&uz='+$('#uz').val()+'&p='+$('#aap').val());
	return;}
	
$.fancybox.defaults.hash = false;
function fancyboxzoom(type) {
    var change = false;var w = $(".fancybox-content").width();var h = $(".fancybox-content").height();
    if (type === 'zoomin') {change = +150;}
    if (type === 'zoomout' && w > 300) {change = -150;}
    if (change) {
        var ratio = w / h;var nw = w + change;var nh = nw / ratio;
        $(".fancybox-content").width(nw);$(".fancybox-content").height(nh);
        var sw = window.innerWidth;var sh = window.innerHeight;
        if (nh < sh && nw < sw) {
            $(".fancybox-content").css({ 'transform': 'translate(' + (sw - nw) / 2 + 'px, ' + (sh - nh) / 2 + 'px)' });
        } else if (nw < sw) {
            $(".fancybox-content").css({ 'transform': 'translateX(' + (sw - nw) / 2 + 'px)' });
        }
    }
}

var backforwardused=false;var ctrltoets=false;
window.onpopstate=function(event){backforwardused=true;getcontainer('?'+window.location.search.substring(1));return;};
if(window.location.search.substring(1)==''){getcontainer('')}else{getcontainer('?'+window.location.search.substring(1))};

