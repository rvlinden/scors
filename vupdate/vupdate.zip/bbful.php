<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";
//check of is ingelogd
if ($rechten!="mo" and $rechten!="sup"){exit();}

$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsboeklog.txt";
$Key="";$zin="";

//plaats upload in map ful
$sleutel=$_GET["sleutel"];
$fulname="ful/". $sleutel.".";
$bestandstype=strtolower(pathinfo($_FILES["orgfilename"]["name"],PATHINFO_EXTENSION));
$fulname=$fulname.$bestandstype;
move_uploaded_file($_FILES["orgfilename"]["tmp_name"], $fulname);

$exif = @exif_read_data($fulname);
if (!empty($exif['Orientation'])) {
    switch ($exif['Orientation']) {
        case 3:
            $img = imagerotate($fulname, 180, 0);
            break;
        case 6:
            $img = imagerotate($fulname, -90, 0);
            break;
        case 8:
            $img = imagerotate($fulname, 90, 0);
            break;
    }
    imagejpeg($img, $fulname); // overschrijven
}

$newthumbname=$sleutel.".jpg";
$newthumbnameGa=$sleutel."ga.jpg";
$newJPGname=$sleutel."JPG.jpg";
$newPDFname=$sleutel.".pdf";
$filesmap="./BB/";

if ($bestandstype=="pdf" or $bestandstype=="jpg" or $bestandstype="jpeg"){
	// Gooi evt. al bestaande file en thumbfile weg
	error_reporting(0);
	unlink($filesmap.$newthumbname);unlink($filesmap.$newJPGname);unlink($filesmap.$newPDFname);
	if ($bestandstype=="pdf"){
		$im = new imagick();
		$im->setResourceLimit(Imagick::RESOURCETYPE_MEMORY,402653184);
		$im->setResolution( 300, 300);
		$im->readImage($fulname.'[0]');
		$im->setImageFormat('jpg');
		$im->setImageBackgroundColor('white');
		$im->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
		$im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
		$im->thumbnailImage(175,175,true);
		$im->transformImageColorspace(Imagick::COLORSPACE_SRGB);
		$im->writeImage($filesmap.$newthumbnameGa);
//		$im->thumbnailImage(100,100,true);
//		$im->transformImageColorspace(Imagick::COLORSPACE_SRGB);
//		$im->writeImage($filesmap.$newthumbname);
		unset ($im);
		// Kopieer het nieuwe bestand van ful naar destinationdir
		rename($fulname, $filesmap.$newPDFname);
		$resultaat="PDF";
	}else if($bestandstype=="jpg" or $bestandstype="jpeg"){
		switch ($bestandstype) {
			case 'jpeg':
			case 'jpg':
				$filenaam = imagecreatefromjpeg($fulname);
			break;
			case 'png':
				$filenaam = imagecreatefrompng($fulname);
			break;
			case 'gif':
				$filenaam = imagecreatefromgif($fulname);
			break;
			}
		
	// Get current image size
		$srcW = imagesx($filenaam);
		$srcH = imagesy($filenaam);
		$resW = $srcW;
		$resH = $srcH;
	//	Calculate scale
		$newSize=intVal(175);
		$xScale = $srcW / $newSize;
		$yScale = $srcH / $newSize;
	//	Calculate new width and height
		if ($yScale > $xScale){
			$resW = round($srcW * (1/$yScale));
			$resH = round($srcH * (1/$yScale));
			}
		else {
			$resW = round($srcW * (1/$xScale));
			$resH = round($srcH * (1/$xScale));
			}
		$resimage = @imagecreatetruecolor($resW,$resH);
		imagecopyresampled($resimage, $filenaam, 0, 0, 0, 0, $resW, $resH, $srcW, $srcH);
		$destfile=$filesmap.$newthumbnameGa;
		imagejpeg($resimage, $destfile, 85);
		imagedestroy($resimage);
		imagedestroy($filenaam);

		// Kopieer het nieuwe bestand van ful naar destinationdir
		rename($fulname, $filesmap.$newJPGname);
		$resultaat="JPG";
	}
	// Werk database bij
	$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/boeken.mdb","","");
	$fprs=odbc_exec($objConnect,"UPDATE boeken SET bestandstype= '".$bestandstype."', foto= '".$sleutel."'  WHERE Key = " . $sleutel);
	unset($fprs);
	odbc_close($objConnect);
	unset($objConnect);
	// Update logfile
	$zin=" Preview upload in#".$sleutel;
	//		error_reporting(0);
	$oTextFile = fopen($logfile, "a");
	$zin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$_COOKIE["user"]." ".$zin.chr(13).chr(10);
	fclose($oTextFile);
	//		error_reporting(-1);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsboeklog_".$zinDate."_".$zinTime.".txt";
		rename ($logfile,$newname);
	}
}else{
	$resultaat="Input moet PDF, JPG, JPEG, PNG of GIF zijn";	// Moet PDF of plaatje zijn
}

// Toon het resultaat voor de parent (deze routine loopt in een iframe)
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd"> 
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body>
<input type="text" name="resultaat" id="resultaat" value="<?php echo $resultaat; ?>">
</body></html>
