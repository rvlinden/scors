<p>
<br>
<div  align="center">
<table class="ttc layoutfixed" cellpadding="3"><tr>
	<td class="ttc" width="40" style="vertical-align:middle;">
	<div class="vmidden" align="center">
	<?php if ($PageCount>1){
		if ($CurrentPage>1){ ?>
			<img style="display:block;margin-left:auto;margin-right:auto;" class="handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&zsr='+$('#zsr').val()+'&znaamtt='+$('#znaamtt').val()+'&sort='+$('#sort:checked').val()+'&zoek='+$('#zoek').val()+'&pg=<?php echo ($CurrentPage-1); ?>');" alt="" border="0" src="<?php echo $basis; ?>images/pijl-links-aa.png" width="20" height="21">
			<?php
		}else{ ?>
			<img style="display:block;margin-left:auto;margin-right:auto;" alt="" src="<?php echo $basis; ?>images/pijl-links-grijs-aa.png" width="20" height="21">
			<?php
		} ?>
		</div>
		</td><td  class="ttc" align="left" style="vertical-align:middle;">
		<div align="center" style="display:block;margin-left:auto;margin-right:auto;">
		<?php for ($i=1; $i<=$PageCount;$i++){ ?>
			<a class="handje geendeco" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&zsr='+$('#zsr').val()+'&znaamtt='+$('#znaamtt').val()+'&sort='+$('#sort:checked').val()+'&zoek='+$('#zoek').val()+'&pg=<?php echo ($i); ?>');">
			<span class="pagetellerpas"><font class="nullen">0</font><?php if ($i<100 and $PageCount>=100){ ?><font class="nullen">0</font><?php }if ($i<10 and $PageCount>=10){ ?><font class="nullen">0</font><?php }if ($i==$CurrentPage){ ?><span class="pagetelleract"><?php echo $i; ?></span><?php }else{echo $i;} ?></span>
			</a>
			&nbsp;
		<?php
		} ?>
		</div>
		</td><td class="ttc" width="40" style="vertical-align:middle;">
		<div align="center">
		<?php if ($CurrentPage<$PageCount){ ?>
			<img style="display:block;margin-left:auto;margin-right:auto;" class="handje" onclick="if (event.ctrlKey) {ctrltoets=true;};getcontainer('?jaar2='+$('#jaar2').val()+'&jaar1='+$('#jaar1').val()+'&zsr='+$('#zsr').val()+'&znaamtt='+$('#znaamtt').val()+'&sort='+$('#sort:checked').val()+'&zoek='+$('#zoek').val()+'&pg=<?php echo ($CurrentPage+1); ?>');" alt="" border="0" src="<?php echo $basis; ?>images/pijl-rechts-aa.png" width="20" height="21">
			<?php
		}else{ ?>
			<img style="display:block;margin-left:auto;margin-right:auto;" alt="" src="<?php echo $basis; ?>images/pijl-rechts-grijs-aa.png" width="20" height="21">
			<?php
		}
	} ?>
	</div>
	</td>
	<td><?php echo "&nbsp;&nbsp;Aantal:&nbsp;".$aantalrecords; ?></td>
</tr></table>
</div>
</p>