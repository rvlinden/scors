<?php
	$filenaam = imagecreatefromjpeg($_GET['filenaam']);
//  Get current image size
	$srcW = imagesx($filenaam);
	$srcH = imagesy($filenaam);
	$resW = $srcW;
	$resH = $srcH;
	$newSize = intval($_GET['newSize']);
	if ($newSize > 0){
	//	Calculate scale
		$xScale = $srcW / $newSize;
		$yScale = $srcH / $newSize;
	//	Calculate new width and height
		if ($yScale > $xScale){
			$resW = round($srcW * (1/$yScale));
			$resH = round($srcH * (1/$yScale));
		}
		else {
			$resW = round($srcW * (1/$xScale));
			$resH = round($srcH * (1/$xScale));
		}
	}
	header ('Content-Type: image/jpeg');
	$resimage = @imagecreatetruecolor($resW,$resH);
	$watermerk = imagecreatefrompng('images\playicon.png');
	imagealphablending($watermerk,true);
	imagesavealpha($watermerk, true);
	$wmW=imagesx($watermerk);
	$wmH=imagesy($watermerk);
	$xpositie=($resW-$wmW)/2;
	$ypositie=($resH-$wmH)/2;
	imagecopyresampled($resimage, $filenaam, 0, 0, 0, 0, $resW, $resH, $srcW, $srcH);
	imagecopy($resimage, $watermerk, $xpositie, $ypositie, 0, 0, $wmW, $wmH);
	imagejpeg($resimage);
	imagedestroy($filenaam);
	imagedestroy($resimage);
?> 
