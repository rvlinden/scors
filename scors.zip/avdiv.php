<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/audiovideo.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Get hostserver voor media
$basis="https://" . $_SERVER['HTTP_HOST']."/";
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$basiskleur1=$row["basiskleur1"];
$basiskleur2=$row["basiskleur2"];
?>
<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
<?php
//genereer logfile voor AVcollectie als die nog niet bestaat
$oTextFile = fopen("log/scorsaudiovideolog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);

unset($fprs);

//Verwijder ongeoorloofde karakters van inputstrings
//Level 1 is strenger
function cleaninput($ipar, $level){
	$acx=str_replace("<", "",$ipar);
	$acx=str_replace(">", "",$acx);
	$acx=str_replace(";", "",$acx);
	$acx=str_replace("]", "",$acx);
	$acx=str_replace("[", "",$acx);
	$acx=str_replace("{", "",$acx);
	$acx=str_replace("}", "",$acx);
	$acx=str_replace("%", "",$acx);
	$acx=str_replace("'", "",$acx);
	if ($level==1){
		$acx=str_replace("(", "",$acx);
		$acx=str_replace(")", "",$acx);
		$acx=str_replace(",", "",$acx);
		$acx=str_replace("%", "",$acx);
		$acx=str_replace(".", "",$acx);
	}
	return $acx;
}

//Lees de input parameters
$sort="Keydesc";$zoek="";$aktie="";
if (isset($_REQUEST["aktie"])){$aktie=cleaninput(strtolower($_REQUEST["aktie"]),1);}
if (isset($_REQUEST["sort"])){$sort=cleaninput(strtolower($_REQUEST["sort"]),1);}
if (strlen($sort)==0){$sort="Keydesc";}
if (isset($_REQUEST["zoek"])){$zoek=cleaninput(strtolower($_REQUEST["zoek"]),1);}
$hulppg="";$pg=1;
if(isset($_REQUEST['pg'])){$hulppg=cleaninput($_REQUEST["pg"],1);}
if (is_numeric($hulppg)){
	$pg=0+$hulppg;
	if ($pg==0){$pg=1;}
}
if ($pg==0){$pg=1;}
$pagesize=30;$viewer="";$soort="";

$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();

if(($aktie=="edit" or $aktie=="nieuw") and ($rechten=="mo" or $rechten=="sup")){ //toon edit-item scherm

	if($aktie=="edit"){
		$Key=$_REQUEST["Key"];
		$pg=$_REQUEST["pg"];
		$sort=$_REQUEST["sort"];
		$zoek=$_REQUEST["zoek"];
		$fprs=odbc_exec($objConnect,"SELECT * FROM av WHERE Key=".strval($Key));
		$row=odbc_fetch_array($fprs);
		$ytcode=$row["ytcode"];
		$sfcode=$row["sfcode"];
		$viewer=$row["viewer"];
		$doel=$row["doel"];
		$titel=$row["titel"];
		$keyframe=$row["keyframe"];
		$jmd=$row["jmd"];
		$jaarsort=$row["jaarsort"];
		$auteur=$row["auteur"];
		$uitgever=$row["uitgever"];
		$beschrijving=$row["beschrijving"];
		$ts=$row["ts"];$tse=$row["tse"];
		$toevoeger=$row["toevoeger"];$aanpasser=$row["aanpasser"];
		odbc_free_result($fprs);
		unset($fprs);
		odbc_close($objConnect);
		unset($objConnect);
		$koptekst="Wijzig AudioVideo"; ?>

		<div style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;">
			<br><br><span style="color: basiskleur2;font-size:26px;"><b>Wijzig&nbsp
				<?php if($viewer=="youtube"){
					echo "Youtube Video";
				}else if ($viewer=="sketchfab"){
					echo "Sketchfab 3D model";
				}else{
					echo "Eigen Audio-Video";
				} ?>
			</b></span>
		</div>
		
	<?php
	}else if ($aktie="nieuw"){ //toon nieuw-item scherm

		$Key="";$pg="";$sort="";$zoek="";
		$viewer="";
		$doel="e";
		$titel="";
		$keyframe=0;
		$ytcode="";
		$sfcode="";
		$jmd="";
		$jaarsort="";
		$auteur="";
		$uitgever="";
		$beschrijving="";
		unset($objConnect);
		$koptekst="Voeg nieuwe AudioVideo toe"; ?>

		<div style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;">
			<br><br><span style="color: basiskleur2;font-size:26px;"><b>Nieuwe Audio-Video</b></span>
		</div>

	<?php
	} ?>

	<!-- EDIT/NIEUW BLOK-->
	<br><br>
	<div style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;" id="top">
		<table class="bcollapse" border="0"><tr><td rowspan="3">
			<canvas id="videoCanvas" style="display: none;"></canvas>
			<input type="hidden" name="thumbnail" id="thumbnailInput">

			<form target="avedit" id="avform" name="avform" action="avadmin.php" method="POST" enctype="multipart/form-data">
			<input name="aktie" id="aktie" type="hidden" value="<?php echo $aktie; ?>">
			<input name="Key" id="Key" type="hidden" value="<?php echo $Key; ?>">
			<input name="pg" id="pg" type="hidden" value="<?php echo $pg; ?>">
			<input name="zoek" id="zoek" type="hidden" value="<?php echo $zoek; ?>">
			<input name="sort" id="sort" type="hidden" value="<?php echo $sort; ?>">
			
			Datering:<br>
			<input onchange="alertchange();" type="text" maxlength="30" name="jmd" id="jmd" value="<?php echo $jmd; ?>"><br>Datering zoals die wordt getoond op de website (vrije tekst)<br><br>
			<input onchange="alertchange();" type="text" name="jaarsort" id="jaarsort" value="<?php echo $jaarsort; ?>">&nbsp;jjjj-mm-dd, jjjj-mm of jjjj.<br>Gebruikt voor sortering op datum (laat leeg als onbekend)<br><br>
			Titel:<br>
			<input onchange="alertchange();" size="60" type="text" name="titel" id="titel" value="<?php echo $titel; ?>"><br><br>
			Auteur(s):<br>
			<input onchange="alertchange();" size="50" type="text" name="auteur" id="auteur" value="<?php echo $auteur; ?>"><br><br>
			Uitgever(s):<br>
			<input onchange="alertchange();" size="50" type="text" name="uitgever" id="uitgever" value="<?php echo $uitgever; ?>"><br><br>
			Beschrijving:<br>
			<textarea onchange="alertchange();" cols="60" rows="4" name="beschrijving" id="beschrijving"><?php echo $beschrijving; ?></textarea><br><br>
			Publiek:&nbsp;
			<input onchange="alertchange();" type="radio" <?php if($doel=="v"){echo " checked ";} ?> name="doel" value="v">Ja&nbsp;&nbsp;
			<input onchange="alertchange();" type="radio" <?php if($doel=="e" or $doel==""){echo " checked ";} ?> name="doel" value="e">Nee<br><br>
			
			<div <?php if($aktie=="edit"){echo ' style="display:none;"';} ?>>
			<input type="radio" name="kies" value="eigen" onchange="alertchange();changeviewer('eigen',$('#viewer').val());" <?php if($viewer!="youtube" and $viewer!="sketchfab"){echo " checked ";} ?>>&nbsp;Eigen mediabestand&nbsp;&nbsp;
			<input type="radio" name="kies" value="youtu" onchange="alertchange();changeviewer('youtube',$('#viewer').val());" <?php if($viewer=="youtube"){echo " checked ";} ?>>&nbsp;Youtube Video&nbsp;&nbsp;
			<input type="radio" name="kies" value="sketc" onchange="alertchange();changeviewer('sketchfab',$('#viewer').val());" <?php if($viewer=="sketchfab"){echo " checked ";} ?>>&nbsp;Sketchfab 3D model
			<br><br>
			</div>

			<input id="viewer" name="viewer" type="hidden" value="<?php echo $viewer; ?>">

			<div style="display:<?php if($viewer=="mp4"){echo "block";}else{echo "none";} ?>" id="keyframediv" name="keyframediv">
				Maak thumbnail van video op tijdstip:&nbsp;
				<input type="number" id="keyframe" name="keyframe" value="<?php echo $keyframe; ?>" onchange="alertchange();wijzigvideothumb();">
				&nbsp;seconden<br><br>
			</div>
			
			<div id="yt" name="yt" style="display:<?php if($viewer=="youtube"){echo "block";}else{echo "none";} ?>;">
				Youtube Code (code die op Youtube achter &nbsp;&nbsp;<strong><code>www.youtube.com/watch?v=</code></strong>&nbsp;&nbsp;staat):&nbsp;
				<input type="text" name="ytcode" id="ytcode" value="<?php echo $ytcode; ?>" size="20" onchange="alertchange();zetyoutube();">
				<br><br>
			</div>

			<div id="sf" name="sf" style="display:<?php if($viewer=="sketchfab"){echo "block";}else{echo "none";} ?>;">
				Sketchfab Code (code die op Sketchfab achter &nbsp;&nbsp;<strong><code>sketchfab.com/3d-models/<i>modelnaam</i>-</strong>&nbsp;&nbsp;staat):&nbsp;
				<input type="text" name="sfcode" id="sfcode" value="<?php echo $sfcode; ?>" size="40" onchange="alertchange();zetsketchfab();">
				<br><br>
			</div>
			
			<div id="aktieknoppen" name="aktieknoppen" style="display:block;">
				<input id="savebutton" type="submit" name="submittekst" value="Sla op" onclick="checksubmit('<?php echo $aktie ?>');">
				&nbsp;&nbsp;&nbsp;
				<button onclick="getcontainer('?av=av<?php if($aktie=="edit"){echo "&sort=".$sort."&zoek=".$zoek."&pg=".$pg;} ?>');">Exit</button>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="submit" name="submittekst" value="Verwijder dit item" onclick="return confirm('Weet u zeker dat u dit item wilt verwijderen?');">
			</div>
		
			</form>
			
			<div id="standaard" name="standaard" style="display:<?php if($viewer!="youtube" and $viewer!="sketchfab"){echo "block";}else{echo "none";} ?>;">
				<br>Upload of vervang Video (MP4), Audio (MP3) of 360 graden Panorama bestand (JPG):&nbsp;&nbsp;&nbsp;&nbsp;<br>
				<input class="zoekinvul" type="file" accept=".jpg,.mp4, .mp3" name="orgfilename" id="orgfilename" onchange="checkfile();alertchange();zetviewerselect();">
				<br><br>
			</div>
		</td><td valign="top" width="250" height="170">
			<div align="center" id="divplaatjeyoutube" style="display:<?php if($viewer=="youtube"){ echo "block";}else{echo "none";} ?>;">
				<?php if ($aktie=="edit" and $viewer=="youtube"){ ?>
					<img style="display:block;" height="100%" width="100%" id="plaatjeyoutube" src="avadmin.php?aktie=watermerk&soort=video&filenaam=https://i.ytimg.com/vi/<?php echo $ytcode; ?>/hqdefault.jpg&t=?t=<?php echo $diffSeconds; ?>">
				<?php }else{ ?>
					<img style="display:block;" id="plaatjeyoutube" src="images/playvideo.png">
				<?php } ?>
			</div>
			<div align="center" id="divplaatjesketchfab" style="display:<?php if($viewer=="sketchfab"){ echo "block";}else{echo "none";} ?>;">
				<?php if ($aktie=="edit"){ ?>
					<div id="sketchfab-embed-wrapper" class="sketchfab-embed-wrapper" style="display:block;">
						<iframe id="iframesketchfab" src="https://sketchfab.com/models/<?php echo $sfcode; ?>/embed?autostart=0&amp;camera=0" height="170" width="250" allow="fullscreen" allowfullscreen frameborder="0"> </iframe>
					</div>
					<img style="display:none;" id="plaatjesketchfab" src="images/3dmodel.png">
				<?php }else{ ?>
					<div id="sketchfab-embed-wrapper" class="sketchfab-embed-wrapper" style="display:none;">
						<iframe id="iframesketchfab" src="https://sketchfab.com/models/<?php echo $sfcode; ?>/embed?autostart=0&amp;camera=0" height="170" width="250" allow="fullscreen" allowfullscreen frameborder="0"> </iframe>
					</div>
					<img style="display:block;" id="plaatjesketchfab" src="images/3dmodel.png">
				<?php } ?>
			</div>
			<div align="center" id="divplaatjepanorama" style="display:<?php if($viewer=="panorama"){ echo "block";}else{echo "none";} ?>;">
				<?php if ($aktie=="edit"){ ?>
					<img style="display:block;" height="100%" width="100%" id="plaatjepanorama" src="avadmin.php?aktie=watermerk&soort=panorama&filenaam=AV/<?php echo $Key; ?>t.jpg&t=<?php echo $diffSeconds; ?>">
				<?php }else{ ?>
					<img style="display:block;" width="40%" height="40%" id="plaatjepanorama" src="images/360.png">
				<?php } ?>
			</div>
			<div align="center" id="divplaatjemp3" style="display:<?php if($viewer=="mp3"){ echo "block";}else{echo "none";} ?>;">
				<img style="display:block;" src="images/logomp3.jpg">
				<div id="mp3tekst" name="mp3tekst"></div>
			</div>
			<div align="center" id="divplaatjemp4" style="display:<?php if($viewer=="mp4"){ echo "block";}else{echo "none";} ?>;">
				<?php if ($aktie=="edit"){ ?>
					<div style="display:none;">
						<video id="eigenvid" style="display:block;" height="145" width="250" preload="metadata" currentTime="0">
						<source id="plaatjemp4" src="AV/<?php echo $Key; ?>.mp4?t=<?php echo $diffSeconds; ?>" type="video/mp4">
						</video>
					</div>
					<img id="mp4thumb" name="mp4thumb" src="avadmin.php?aktie=watermerk&soort=eigenvid&filenaam=AV/<?php echo $Key; ?>t.jpg&t=<?php echo $diffSeconds; ?>" width="250">
				<?php }else{ ?>
					<div style="display:none;">
						<video id="eigenvid" style="display:block;" height="145" width="250" preload="metadata" currentTime="0">
						<source id="plaatjemp4" src="" type="video/mp4">
						</video>
					</div>
					<img id="mp4thumb" name="mp4thumb" src="images/eigenvideo.png">
				<?php } ?>
			</div>
			<div align="center" id="divplaatjemp4new" style="display:none;">
				<img style="display:block;" width="75%" height="75%" src="images/eigenvideo.png">
			</div>
			<div align="center" id="wachten" style="display:none;">
				<br><br><img width="30" src="images/wacht.gif">
			</div>
			<div id="progressContainer" style="display:none; margin-top:10px;">
				<progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
				<span id="progressPercent">0%</span>
			</div>
			<div id="status"></div>
		</td></tr><tr><td>
			<?php
			function convertToBytes($value) { // Convert value to bytes (e.g., "2M" to bytes)
				$value = substr($value,0,strlen($value)-1);$last = strtolower($value[strlen($value)-1]);
				switch($last) {
					case 'g': $value *= 1024;
					case 'm': $value *= 1024;
					case 'k': $value *= 1024;
				}
			return $value;}
			// Get the maximum post en file upload size
			$maxUploadSize=ini_get('upload_max_filesize');$maxPostSize = ini_get('post_max_size');
			$maxUploadSizeBytes = convertToBytes($maxUploadSize);$maxPostSizeBytes = convertToBytes($maxPostSize);
			if(min($maxUploadSizeBytes,$maxPostSizeBytes)==$maxPostSizeBytes){$maxUploadSize=$maxPostSize;}
			?>
			<table border="1" class="bcollapse"><tr><td>
			<i>Let op: u kunt op uw webserver bestanden van maximaal <?php echo $maxUploadSize; ?>bytes uploaden.<br>
			Daarnaast kan er op uw webserver of in uw browser een timeout fout optreden bij grote uploads.<br>
			Uw webmaster kan hier mogelijk in assisteren.</i>
			</td></tr></table>
			<br><br>
			<?php
			if ($aktie=="edit"){
				$toevoeger=explode("@",$toevoeger)[0];if($toevoeger!=""){$toevoeger=" (".$toevoeger.")";}
				$aanpasser=explode("@",$aanpasser)[0];if($aanpasser!=""){$aanpasser=" (".$aanpasser.")";}
				$opvoerdatum=date("d M Y",$ts);
				$wijzigdatum=date("d M Y",$tse);
				?>								
				<font class="tekst1"><i>
				Toegevoegd&nbsp;<?php echo $opvoerdatum.$toevoeger; ?><br>
				<?php if(($ts!=$tse) and $tse>0){ ?>	Aangepast&nbsp;<?php echo $wijzigdatum.$aanpasser; ?><?php } ?>
				</i></font>
			<?php
			} ?>
		</td></tr></table>
	</div>
	<br>
	<!-- EINDE EDIT/NIEUW BLOK -->
	<iframe style="display:none;" name="avedit" id="avedit" src="" onload="checkresult();"></iframe>

<?php
}else{ //toon galerij

	//ADMIN BLOK
	?>
	<div align="center" id="top">
	<br>
	<?php if($rechten=="mo" or $rechten=="sup"){ ?>
	<div align="center">
		<button class="ggbutton" onclick="getcontainer('?aktie=nieuw');">Nieuwe AV</button></a>&nbsp;
		<a data-fancybox="log" data-type="iframe" href="log/scorsaudiovideolog.txt?t=<?php echo $diffSeconds; ?>">
		<button class="ggbutton">Open logfile</button></a>&nbsp;
	</div>
	<?php } ?>

	<!-- ZOEKBLOK-->
	<div align="center">
	<table border="0"><tr><td colspan="3" align="center">
		<table border="0" style="display:inline;float:left;border-collapse:collapse;"><tr><td>
			<input class="avz" type="text" id="zoek" value="<?php echo $zoek; ?>" size="25" onkeypress="keyPressListener(event);">&nbsp;
			<button class="ggbutton" onclick="avzoek();">Zoek</button>&nbsp;
			<button class="ggbutton" onclick="getcontainer('?av=av&sort='+$('#sort').val());">Wis</button>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</td></tr></table>
		<table border="0" style="display:inline;float:left;border-collapse:collapse;"><tr><td>
			<font style="font-size:14px;">
			Sorteer
			<select class="avz" id="sort" name="sort" onchange="getcontainer('?av=av&sort='+$('#sort').val());">
				<option <?php if ($sort=="Keydesc"){ echo "selected"; } ?> value="Keydesc">Meest recent toegevoegd</option>
				<option <?php if ($sort=="jaarsortasc"){ echo "selected"; } ?> value="jaarsortasc">Jaar oplopend</option>
				<option <?php if ($sort=="jaarsortdesc"){ echo "selected"; } ?> value="jaarsortdesc">Jaar aflopend</option>
				<option <?php if ($sort=="tsedesc"){ echo "selected"; } ?> value="tsedesc">Meest recent aangepast</option>
			</select>
		</td></tr></table>
	</tr></td></table>
	</div>
	<!-- EINDE ZOEKBLOK-->
	
	<?php
	//construeer de SQL string
	$zoek=str_replace("+"," ",$zoek);
	$zoek=str_replace("-"," ",$zoek);
	$zoek=str_replace("%20", " ",$zoek);
	$zoek=str_replace("%", "",$zoek);
	$zoek=str_replace(chr(34), "",$zoek);
	while (strpos($zoek,"  ")!==false){$zoek=str_replace("  ", " ",$zoek);}
	$zoek=trim($zoek);$zkw=0;$somstuk="";
	if (strlen($zoek)>0 and strpos($zoek," ")!==false){
		$zkwoorden=explode(" ",$zoek);$zkw=sizeof($zkwoorden);
		for ($i=0;$i<$zkw;$i++){
			if ($i>0){$somstuk=$somstuk." AND ";}
			$somstuk=$somstuk."(beschrijving like  '%".$zkwoorden[$i]."%' OR titel like '%".$zkwoorden[$i]."%' OR auteur like '%".$zkwoorden[$i]."%' OR uitgever like '%".$zkwoorden[$i]."%' OR jmd like '%".$zkwoorden[$i]."%')";
		}
		$somstuk=" WHERE (".$somstuk.")";
		if($rechten==""){$somstuk=$somstuk." AND doel='v' ";}
	}else if(strlen($zoek)>0){	
		$somstuk=" WHERE (titel&' '&uitgever&' '&auteur&' '&jmd like '%".$zoek."%')";
		if($rechten==""){$somstuk=$somstuk." AND doel='v' ";}
	}else{
		if($rechten==""){$somstuk=" WHERE doel='v' ";}
	}
	$orderstuk=" ORDER BY ".str_replace("desc"," desc",str_replace("asc"," asc",$sort));
	$fp_sQry="SELECT * FROM av ".$somstuk.$orderstuk;
	$fp_sQryCount="SELECT COUNT(*) as aantal FROM av ".$somstuk;

	//Doe de query
	$fprs=odbc_exec($objConnect,$fp_sQryCount);
	$aantalrecords=0;
	if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];}
	if ($aantalrecords>0){
		$CurrentPage=$pg;
		$PageCount=intdiv($aantalrecords,$pagesize)-(($aantalrecords%$pagesize)==0)+1;
		if ($CurrentPage<1){$CurrentPage=1;}
		if ($CurrentPage>$PageCount){$CurrentPage=$PageCount;}
		?>
		
		<div style="margin:0px 65px!important;" align="center"><?php $eerste=true; include 'avdivnav.php'; $eerste=false; ?></div>
		<?php
		//Doe de query
		$regelteller=1;
		$fprs=odbc_exec($objConnect,$fp_sQry);
		//GALLERIJWEERGAVE
		?>

		<div style="margin:0px 0px 0px 45px!important;">
		<table style="table-layout:fixed!important;border-collapse:collapse!important;" width="100%"><tr>
		<td style="vertical-align: top!important;">

		<?php
		while($fp_rs=odbc_fetch_array($fprs)){ 
			$positieteller=($pagesize*($pg-1))+$regelteller;
			if ($regelteller>$pagesize){break;}
			if($positieteller>$aantalrecords){break;}
			if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
			$titel=$fp_rs["titel"];
			$Key=$fp_rs["Key"];
			$auteur=$fp_rs["auteur"];
			$uitgever=$fp_rs["uitgever"];
			$beschrijving=$fp_rs["beschrijving"];
			$keyframe=$fp_rs["keyframe"];
			$viewer=$fp_rs["viewer"];
			$jaar=$fp_rs["jmd"];
			$doel=$fp_rs["doel"];if($doel=="v"){$doeltekst="Publiek";}else{$doeltekst="Alleen leden";}
			if ($viewer=="mp3" or $viewer=="mp4"){$filepath=$basis."AV/".$Key.".".$viewer;}
			$avtitel=$titel." (".$jaar.")";

			?>
			<TABLE width="307" style="border-collapse:separate!important;border-spacing:3px!important;table-layout: fixed!important;display:inline!important;float:left!important;border-collapse:collapse!important;" border="0"><TR> <!-- 1 item -->
			
				<td width="2"></td>				
				<td width="303">
					<table style="table-layout: fixed!important;border-collapse:collapse!important;" border="0" width="292">
					<tr><td align="center" width="299" height="270" style="margin-left:auto!important;margin-right:auto!important;vertical-align: middle!important;" class="fotobg">
						<div align="center">
							<?php
							if ($viewer=="mp4") {
								$soort="Video&nbsp;&nbsp;";
								$videothumb=str_replace(".mp4", "t.jpg",$filepath);
								$videotag='v'.$Key;
								?>
								<a data-type="iframe" data-fancybox href="<?php echo $basis ?>avviewer.php?filepath=<?php echo $filepath; ?>&viewer=<?php echo $viewer; ?>" data-caption="<?php echo $avtitel; ?>" title="">
								<img src="<?php echo $basis."avwatermerk.php?newSize=270&filenaam=".$videothumb."&t=".$diffSeconds; ?>"></a>
							<?php
							}else if ($viewer=="mp3") {
								$soort="Audio&nbsp;&nbsp;";
								?>
								<img src="<?php echo $basis; ?>/images/logomp3.jpg">
								<audio controls>
								<source src="<?php echo $filepath ?>" type="audio/mp3">
								Your browser does not support the audio tag.
								</audio> 
							<?php
							}else if ($viewer=="youtube") {
								$soort="Youtube Video&nbsp;&nbsp;";
								?>
								<iframe width="299" height="247" src="https://www.youtube.com/embed/<?php echo $fp_rs["ytcode"]; ?>?rel=0" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
								<?php
							}else if ($viewer=="sketchfab") {
								$soort="Sketchfab 3D model&nbsp;&nbsp;";
								?>
								<div class="sketchfab-embed-wrapper">
									<iframe src="https://sketchfab.com/models/<?php echo $fp_rs["sfcode"]; ?>/embed?autostart=0&amp;camera=0" height="240" width="299" allow="fullscreen" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
								</div>
								<?php
							}else if ($viewer=="panorama"){
								$soort="Panorama&nbsp;" ?>
								<iframe width="299" allowfullscreen style="border-style:none;" src="/pannellum/pannellum.htm#autoRotate=4&autoLoad=true&panorama=<?php echo $basis; ?>AV/<?php echo $Key; ?>.jpg?t=<?php echo $diffSeconds; ?>"></iframe>
							<?php
							} ?>
						</div>
					</td></tr><tr><td height="27" class="bgzoek" >
						<table width="100%" style="border-collapse:collapse;!important"><tr><td>
							<div align="left" style="margin:0px 3px!important;">
								<b><font class="tekst2"><?php echo $soort.$jaar; ?></b></font>
							</div>
						</td><td align="right">
							<?php if(strlen($beschrijving)>0){ ?>
								</td><td align="right">
								<a class="vinfo deconone"><button class="qbutton"><b>&nbsp;i&nbsp;</b></button><span><font class="aatekst2"><?php echo $beschrijving; ?></font></span></a>
							<?php
							}
							if($rechten=="mo" or $rechten=="sup"){ ?>
								<button class="ggbutton" onclick="getcontainer('?aktie=edit&Key=<?php echo $Key; ?>&sort=<?php echo $sort; ?>&zoek=<?php echo $zoek; ?>&pg=<?php echo $pg; ?>')";)>Edit</button>
							<?php
							} ?>							
						</td></tr></table>
					</td></tr><tr><td style="vertical-align: top;!important" class="fotobg" height="100">
						<div style="margin:3px!important;">
							<font class="tekstgridtitel">
							<?php echo $titel; ?><br>
							<?php if(strlen($auteur)>0){ ?><br><b>Auteur:</b>&nbsp;<?php echo $auteur; } ?>
							<?php if(strlen($uitgever)>0){ ?><br><b>Uitgever:</b>&nbsp;<?php echo $uitgever; } ?>
							</font>
						</div>
					</td></tr><tr><td height="32" align="right" class="fotobg">
						<div align="right" style="margin:3px!important;">
							<font class="tekst1">
							<?php if($rechten=="mo" or $rechten=="sup"){ echo $doeltekst."&nbsp;"; } ?>
							</font>
						</div>
					</td></tr><tr><td height="8"></td>
					</tr></table>
				</td>
				<td width="2"></td>				
			</TR></TABLE> <!-- Eind 1 item -->
			
			<?php
			$regelteller=$regelteller+1;
		} //next record 
		?>
		</tr></table>

		</div>
		<?php include 'avdivnav.php'; ?>
		<div style="margin:0px 95px 0px 0px;" align="right"><button class="ggbutton" onclick="$('body,html').animate({scrollTop: $('#top').offset().top},400);">TOP</button></div>

	<?php
	}else{ ?>
		<br><br>Geen resultaten gevonden voor &#39;<?php echo $zoek; ?>&#39;.
	<?php
	} ?>
	</div>
<?php
// EINDE WEERGAVE
odbc_free_result($fprs);
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
} ?>
<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td>
	<br>
	<div align="right"><font class="copynotice">SCORS&nbsp;v3.0&nbsp;<?php if ($rechten=="mo" or $rechten=="sup"){echo "Administratie&nbsp;";} ?>&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font></div>
</td></tr></table>