<?php
$afbdir="";
$keydir="";
$thumbsdir="";
$i=1;

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/archief.mdb","","");
$fprs=odbc_exec($objConnect,"SELECT * FROM archief WHERE soort1 NOT LIKE '%Bidprentje%'");
$row=odbc_fetch_array($fprs);
$Key=$row["Key"];
//verwijder files
for($i=1;$i<=12;$i++){
	$filenummer=strval($i);
	$veldnaamfile=$row['foto'.$filenummer];
	if (strlen($veldnaamfile)>0){
		$keydir=substr($veldnaamfile,0,3);
		$afbdir="AAD/".$keydir."/".$veldnaamfile;
		$thumbsdir="AAT/".$keydir."/".$veldnaamfile;
		if (file_exists($afbdir)){unlink($afbdir);}
		if (file_exists($thumbsdir)){unlink($thumbsdir);}
	}
}
//verwijder record
	$fprsdel=odbc_exec($objConnect,"DELETE FROM archief WHERE Key = ".$Key);
//verwijder eventuele OCR teksten
	$fprsdel=odbc_exec($objConnect,"DELETE FROM ocr WHERE kidx like '".strval($Key)."%'");
echo $Key.chr(10).chr(13);

// Close connection
odbc_free_result($fprs);
unset($fprs);
odbc_close($objConnect);
unset($objConnect);
?>