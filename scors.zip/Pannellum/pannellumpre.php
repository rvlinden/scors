<html><head></head><body>
<script type="text/Javascript">
var hoogte=screen.height-270;
var breedte=screen.width-128;
var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", "pannellum.htm#autoRotate=8&autoLoad=true&panorama=<?php echo $_REQUEST["filenaam"]; ?>");
        ifrm.style.width = breedte;
        ifrm.style.height = hoogte;
        document.body.appendChild(ifrm);
</script>
</body></html>
