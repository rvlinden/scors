<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<?php
$startnr='';$eindnr='';
if(isset($_REQUEST['startnr'])){$startnr=$_REQUEST['startnr'];}
if(isset($_REQUEST['startnr'])){$eindnr=$_REQUEST['eindnr'];}
?>

<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Schoon archief op</title>
<script type="text/javascript" src="jquery/jquery-3.4.1.min.js"></script>
</head>
<br>

<script type="text/javascript">
var migraterecord=0;var d = new Date();var startnr=0;var eindnr=0;var gadoor=true;var teller=0;var eerstekeer=true;var scrolltekst='';

function migrate(){
	gadoor=true;
	startnr=$('#startnr').val();eindnr=$('#eindnr').val();migraterecord=startnr-1;
	volgende();
	return;}
function autostop(){gadoor=false;return;}
function volgende(){
	if (eerstekeer==true){eerstekeer=false;}
	else{
		setTimeout(function timer(){
			var innerDoc = document.getElementById('resultaat').contentDocument || document.getElementById('resultaat').contentWindow.document; 
			scrolltekst=scrolltekst+innerDoc.body.innerText;
			document.getElementById('outtekst').innerText=scrolltekst;
			var objDiv = document.getElementById('outtekst');objDiv.scrollTop = objDiv.scrollHeight;
			migraterecord=migraterecord+1;teller=teller+1;
			if(migraterecord<=eindnr){volgendenr=migraterecord;}else{volgendenr='nvt';}
			document.getElementById('teller').innerHTML='&nbsp;&nbsp;Opgeschoonde mappen: '+(teller-1)+' Nu: '+volgendenr;
			if (gadoor==true && migraterecord<=eindnr){
				$('#resultaat').attr('src','bpopschoon.php?t='+d.getTime());
			}
		}, 150 );
	}
	return;}
</script>

<table cellpadding="0" cellspacing="0"><tr>	
<td>StartNr:&nbsp;<input type="text" id="startnr" name="startnr" value="<?php echo $startnr ?>">&nbsp;</td>
<td>EindNr:&nbsp;<input type="text" id="eindnr" name="eindnr" value="<?php echo $eindnr ?>">&nbsp;</td>
<td><input type="button" onclick="autostop();" value="Stop"></td>
<td><input type="button" onclick="migrate();" value="Schoon op"></td>
<td><div id="teller" name="teller"><div></td>
</tr></table>

<div id="outtekst" name="outtekst" style="width:800px;height:400px;overflow: scroll;"></div>

<div style="display:none;"><iframe src="" id="resultaat" name="resultaat" onload="volgende();"></iframe></div>

</body>
</html>