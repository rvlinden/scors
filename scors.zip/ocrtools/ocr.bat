@echo on
REM OCR script voor SCORS
REM SCORS plaatst een kopie van de te bewerken bestanden in de map OCR.
REM Plaatjes worden geconverteerd naar PDF en dan ge-OCR-ed.
REM Bij plaatjes blijft het origineel in de AAD map aanwezig
REM en wordt het PDF-resultaat er bij geplaatst. Men kan dus
REM altijd nog het originele plaatje terugvinden indien nodig.
call :getLock
exit

:getLock
:: The CALL will fail if another process already has a write lock on the script
call :NOTRUNNING 9>>"%~f0"
exit

:NOTRUNNING
REM Lees het domein van SCORS uit bestand domein.scors en zet dat in een variabele
for /f "usebackq tokens=*" %%a in ("domein.scors") do (set "scorsdomein=%%a")

cd ..\ocr

REM Converteer images naar pdf en gooi de images weg
for %%F in ("*.jpg" "*.png" "*.gif" "*.jpeg") do (
	..\ocrtools\i_view64.exe "%%F" /convert="%%~nF.pdf"
	del /q %%F
)

REM Plaats wat al .txt is in de out map en verwerk deze meteen
move /Y *.txt out
for %%b in (out\*.txt) do ..\ocrtools\curl "http://%scorsdomein%/ocrimport.php?aktie=ocrimport&kidx=%%b&extensie=txt"

REM Verwerk alle .pdf's, inclusief de zojuist geconverteerde plaatjes
for %%a in ("*.pdf") do call :PDF "%%a"
exit

:PDF
set hulp=%1
set textfilenaam=%hulp:.pdf=.txt%
REM Check of de PDF al is ge-OCR-ed
..\ocrtools\pdftotext "%1"
find "e" "%textfilenaam%"
if %errorlevel%==0 (
REM Er is tekst gevonden in de PDF
move /Y "%textfilenaam%" out
move /Y "%1" out
GOTO STAP2
)
REM Er is geen tekst gevonden in de PDF
del /q %textfilenaam%

REM ***********************************************************************
REM Plaats hier uw OCR scanning oplossing voor nog niet       
REM ge-OCR-de PDF bestanden. Hieronder 2 voorbeelden
REM ***********************************************************************
REM Voorbeeld 1: Adobe Api Services for OCR
REM Het script gebruikt de credentials van een geregistreerd account.
REM U dient deze credentials in te vullen in ocrapi.php 

REM ****un-REM onderstaand gedeelte om deze methode te gebruiken***********
REM ..\ocrtools\curl "http://%scorsdomein%/ocrtools/ocrapi.php?aktiestap=1&inputfile=%1"
REM ..\ocrtools\curl "http://%scorsdomein%/ocrtools/ocrapi.php?aktiestap=2&inputfile=%1"
REM ..\ocrtools\curl "http://%scorsdomein%/ocrtools/ocrapi.php?aktiestap=3&inputfile=%1"
REM ***********************************************************************

REM Voorbeeld 2: Adobe Acrobat DC 2020 welke na openen wordt bestuurd met AutoHotkey.
REM Het script Autohotkey.man bevat de besturingsinstructies voor Acrobat.
REM Het script vereist dat Acrobat in full-screen mode is opgestart en in
REM de settings van "Edit PDF" "Recognize Text in Dutch" is ingesteld en
REM het vinkje is gezet bij "Make all the pages editable".
REM Deze settings worden onthouden door Acrobat bij een volgende start.
REM Bepaal de coordinaten (relative) van de "Edit PDF" functie op het
REM scherm van te voren met de Autohotkey Window Spy functie.
REM Vul deze coordinaten in bij de MouseMove functie in automan.ahk.

REM ****un-REM onderstaand gedeelte om deze methode te gebruiken***********
REM Check of Autohotkey al draait, zoniet start deze
REM tasklist /FI "IMAGENAME eq autohotkey.exe" 2>NUL | find /I /N "autohotkey.exe">NUL
REM if NOT "%ERRORLEVEL%" == "0" start "" "C:\Program Files\AutoHotkey\AutoHotkey.exe" ..\ocrtools\automan.ahk
REM Start Acrobat en OCR de PDF
REM "C:\Program Files (x86)\Adobe\Acrobat 2020\Acrobat\Acrobat.exe" %1
REM Beeindig Autohotkey
REM taskkill /IM "autohotkey.exe" /F
REM ***********************************************************************

move /Y "%1" out
cd out
REM extract de text uit de PDF
..\..\ocrtools\pdftotext "%1"
cd ..
GOTO STAP2

:STAP2
REM Importeer tekst, gooi .txt file weg en verplaatst PDF naar eindbestemming
..\ocrtools\curl "http://%scorsdomein%/ocrimport.php?aktie=ocrimport&kidx=%1&extensie=pdf"