
<?php
//****Enter client registration info for Adobe Api Services
$clientID = 'ac33ad8b634143209f9fa5b7a62a1cd3'; //Rob van Linden
$clientSecret = 'p8e-UYWoRebwGPqQi-Vf_DTOBYzMSjkKuwPb';
//*********************************************************

$inputFile = "";$outputFilename="";$assetID="";$aktiestap=0;
if (isset($_REQUEST["aktiestap"])){$aktiestap=$_REQUEST["aktiestap"];}
if (isset($_REQUEST["inputfile"])){
	$inputFile="../ocr/".$_REQUEST["inputfile"];
	$outputFilename=$inputFile;
}

if($aktiestap>1){ // Read parameters
	$oTextFile = fopen("ocrapi.credentials", "r");
	$accessToken=rtrim(fgets($oTextFile),"\r\n");
	$locationHeader=rtrim(fgets($oTextFile),"\r\n");
	$assetID=rtrim(fgets($oTextFile),"\r\n");
	fclose($oTextFile);
}

if (isset($_REQUEST["aktiestap"])){ //call vanuit handmatige browsersessie of curl
	if ($aktiestap==1){	// Get accessToken, uploadUri, assetID, upload file and make OCR request
		$accessToken = getAccessToken($clientID, $clientSecret);
		$uploadUri = getUploadUri($clientID, $accessToken);
		uploadFile($inputFile,$uploadUri);
		$locationHeader=requestOcr($accessToken,$clientID,$assetID);
		$oTextFile = fopen("ocrapi.credentials", "w");
		fwrite($oTextFile,$accessToken.chr(13).chr(10));
		fwrite($oTextFile,$locationHeader.chr(13).chr(10));
		fwrite($oTextFile,$assetID.chr(13).chr(10));
		fclose($oTextFile);
		echo "Access token received\r\n";
		echo "UploadUri received\r\n";
		echo "AssetID: ".$assetID."\r\n";
		echo "File ".$inputFile." uploaded\r\n";
		echo "OCR requested for: ".$locationHeader."\r\n";
	}else if($aktiestap==2){ // Wait for the job to complete
		$jobStatus = checkJobStatus($clientID, $accessToken, $locationHeader);
		echo "JobStatus: ".$jobStatus."\r\n";
		while($jobStatus=="in progress"){
			sleep(5); //wait 5 sec before checking again
			$jobStatus = checkJobStatus($clientID, $accessToken, $locationHeader);
			echo "JobStatus: ".$jobStatus."\r\n";
		}
		sleep(5); //wait 5 sec before proceeding
	}else if($aktiestap==3){ // If job succeeded, retrieve downloadUri and download result
		$downloadUri=getDownloadUri($locationHeader, $clientID, $accessToken);
		$downloadResultaat=downloadResult($downloadUri,$outputFilename);
		updateLogfile($downloadResultaat);
		echo "DownloadUri received\r\n";
		echo $downloadResultaat."\r\n";
	}

}else{ //browsersession (handmatig opgestart via browser)
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="UTF-8">
<meta name="author" content="Rob van Linden, R.F.J. van Linden">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<title>Adobe OCR API</title>
</head><body>
	<script type="text/javascript">
	var aktiestap=0;var d = new Date();var scrolltekst='';

	function volgende(){
		setTimeout(function timer(){
			var innerDoc = document.getElementById('resultaat').contentDocument || document.getElementById('resultaat').contentWindow.document; 
			addtekst=innerDoc.body.innerText;
			scrolltekst=scrolltekst+addtekst;
			document.getElementById('outtekst').innerText=scrolltekst;
			var objDiv = document.getElementById('outtekst');objDiv.scrollTop = objDiv.scrollHeight;
			aktiestap=aktiestap+1;
			if (aktiestap<=3){
				$('#resultaat').attr('src','ocrapi.php?aktiestap='+aktiestap+'&inputfile=<?php echo $inputFile; ?>&t='+d.getTime());
			}
		}, 150 );
		return;}
	</script>

	<div id="outtekst" name="outtekst" style="width:800px;height:400px;overflow: scroll;"></div>
	<div style="display:none;"><iframe src="" id="resultaat" name="resultaat" onload="volgende();"></iframe></div>
</body></html>

<?php
}	
//FUNCTIONS========================================================================

// Function to get access token
function getAccessToken($clientID, $clientSecret) {
    $response = file_get_contents('https://pdf-services-ew1.adobe.io/token', false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query(['client_id' => $clientID,'client_secret' => $clientSecret,]),
        ],
    ]));
	// Process response
    $tokenData = json_decode($response, true);
    return $tokenData['access_token'];
}

//Function to get the upload URI
function getUploadUri($clientID, $tokenData) {
	global $assetID,$inputFile;
	$response = file_get_contents('https://pdf-services-ew1.adobe.io/assets', false, stream_context_create([
		'http' => [
			'header' => [
				'X-API-Key: ' . $clientID,
				'Authorization: Bearer ' . $tokenData,
				'Content-Type: application/json',
			],
			'method' => 'POST',
			'content' => json_encode(['mediaType' => 'application/pdf',]),
		],
	]));
	if ($response === FALSE) {
		$logzin="OCR api failed in getting uploadUri for ".$inputFile;
		updateLogfile($logzin);
		echo $logzin;
		exit();
	}
	else { // Process the response
		$uploadUriData=json_decode($response, true);
		$assetID=$uploadUriData['assetID'];
		return $uploadUriData['uploadUri'];
	}
}

//Function to upload the file
Function uploadFile($inputFile,$uploadUri){
	$response = file_get_contents($uploadUri, false, stream_context_create([
		'http' => [
			'header' => ['Content-Type: application/pdf',],
			'method' => 'PUT',
			'content' => file_get_contents($inputFile),
		],
	]));
	if ($response === FALSE) {
		$logzin="Error uploading file ".$inputFile;
		updateLogfile($logzin);
		echo $logzin;
		exit();
	}
}

//Function to make OCR request job
function requestOcr($tokenData, $clientID, $assetID) {
	global $inputFile;
    $response = file_get_contents('https://pdf-services-ew1.adobe.io/operation/ocr', false, stream_context_create([
        'http' => [
            'header' => [
                'Authorization: Bearer ' . $tokenData,
                'x-api-key: ' . $clientID,
                'Content-Type: application/json',
            ],
            'method' => 'POST',
            'content' => json_encode([
                'assetID' => $assetID,
                'ocrLang' => 'nl-NL',
                'ocrType' => 'searchable_image',
            ]),
        ],
    ]));
    if ($response === FALSE) {
        echo "Error making OCR request.";
		$logzin="Error making OCR request for ".$inputFile;
		updateLogfile($logzin);
		echo $logzin;
		exit();
    }else{
		$header=$http_response_header;
		for ($i=0;$i<count($header);$i++){
			if (strpos($header[$i],"location:")!==false){$locationHeader = substr($header[$i],strpos($header[$i],":")+2);break;}
		}
		return $locationHeader;
	}
}

// Function to check job status
function checkJobStatus($clientID, $accessToken, $locationHeader) {
	global $inputFile;
    $response = file_get_contents($locationHeader, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
				'Authorization: Bearer ' . $accessToken,
				'x-api-key: ' . $clientID,
				'Content-Type: application/json',
			],
        ],
    ]));
	if ($response === FALSE) {
		$logzin="Error checking OCR jobstatus for ".$inputFile;
		updateLogfile($logzin);
		echo $logzin;
		exit();
	}
	else{ //process response
		$jobStatus = json_decode($response, true)['status'];
		return $jobStatus;
	}
}

//Function to get the downloadUri for the result
function getDownloadUri($locationHeader, $clientID, $accessToken) {
    $response = file_get_contents($locationHeader, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
				'Authorization: Bearer ' . $accessToken,
				'x-api-key: ' . $clientID,
				'Content-Type: application/json',
			],
        ],
    ]));
	$data = json_decode($response, true);
// Access the downloadUri field
	$downloadUri = $data['asset']['downloadUri'];
    return $downloadUri;
}

//Function to download the result from downloadUri
function downloadResult($downloadUri,$outputFilename){
	$pdfContent = file_get_contents($downloadUri);
	if ($pdfContent !== false) {
		// Save the PDF to a file
		file_put_contents($outputFilename, $pdfContent);
		return "PDF with OCR text overlay downloaded successfully as ".$outputFilename;
	} else {
		$logzin="Failed to download PDF with OCR text overlay ".$outputFilename;
		updateLogfile($logzin);
		echo $logzin;
		exit();
	}
}

//Function to delete the asset from the cloud
function cleanupAsset($clientID, $accessToken, $assetId) {
    $response = file_get_contents("https://pdf-services-ew1.adobe.io/assets/".$assetId, false, stream_context_create([
        'http' => [
            'method' => 'DELETE',
            'header' => 'Authorization: Bearer ' . $accessToken,
			'Content-Type: application/json',
			'x-api-key: ' . $clientID,
        ],
    ]));
}

//Function to update logfile
function updateLogfile($logzin){
	$zinDate=date("Y-M-d");$zinTime=date("h.i.s");
	$logfile="../log/ocrapilog.txt";
	if(strlen($logzin)>0){
		$logzin=$zinDate." ".$zinTime." ".$logzin.chr(13).chr(10);
		//		error_reporting(0);
		$oTextFile = fopen($logfile, "a");
		fwrite($oTextFile,$logzin);
		fclose($oTextFile);
		//		error_reporting(-1);
		if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
			$newname="../log/ocrapilog ".$zinDate." ".$zinTime.".txt";
			rename ($logfile,$newname);
		}
	}
}
?>
