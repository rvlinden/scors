;Scipt om Adobe Acrobat een OCR scan te laten doen op een reeds geladen PDF.
;Acrobat kan dit (helaas) niet via een command-line opdracht.
;Voor de OCR scan wordt de "Edit PDF" functie uit de Tools set aan de rechterzijde van het scherm gestart.
;Het script vereist dat Acrobat in full-screen mode is opgestart en in de settings van "Edit PDF"
;"Recognize Text in Dutch" is ingesteld en het vinkje is gezet bij "Make all the pages editable".
;Deze settings worden onthouden door Acrobat bij een volgende start.
;Bepaal de coordinaten (relative) van de "Edit PDF" functie op het scherm van te voren met de Autohotkey Window Spy functie.
;Vul deze coordinaten dan in bij de MouseMove functie in dit script.
SetTitleMatchMode, 2
Loop {
WinWaitActive, ahk_class AcrobatSDIWindow
Sleep 5000
WinActivate ahk_class AcrobatSDIWindow
MouseMove, 900, 311
Click
Sleep 2000
while WinExist("ahk_class AVL_AVWindow"){
Sleep 2000
}
WinActivate ahk_class AcrobatSDIWindow
Send ^s
Sleep 6000
WinActivate ahk_class AcrobatSDIWindow
Send ^q
Sleep 2000
}
return