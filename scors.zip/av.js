// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

var scrollnu=0;startloop=true;aantalloaded=0;var orgviewer; var blijfinedit=false;
function getcontainer(urlquery){
	startloop=true;var d=new Date().getTime();
	if(urlquery==''){urlquery='?t='+d;}else{if(urlquery.indexOf('t=1')<0){urlquery=urlquery+'&t='+d;}}
	if (backforwardused==false){history.pushState(null,null,location.href);history.replaceState(null,null,urlquery);}
	backforwardused=false;
	if (ctrltoets==true){ctrltoets=false;window.open(urlquery);window.focus();}
	else{
//		$(".wachtshow").removeClass("onzichtbaar");$(".emptyshow").addClass("onzichtbaar");
		urlquery=vlinden+"avdiv.php"+urlquery+'t='+d;
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET",urlquery,false);
		xmlhttp.setRequestHeader("vm",$('#vm').val());
		xmlhttp.send();
		var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
		document.getElementById('avcontainer').innerHTML=xmlhttp.responseText;
	    var bounding = document.getElementById("top").getBoundingClientRect();
		if (scrollnu==1 || bounding.top < 0){$("body,html").animate({scrollTop: $("#top").offset().top},250);}
		scrollnu=scrollnu+1;
	}
//	$(".wachtshow").addClass("onzichtbaar");$(".emptyshow").removeClass("onzichtbaar");
	return;}
function xmltrein(url){
	var xmlhttp=new XMLHttpRequest();xmlhttp.open("GET",url,false);xmlhttp.send();
	var countS=0;while (xmlhttp.readystate<4){setTimeout(function(){countS++},50);}
	return;}
function keyPressListener(e) {
	if (e.keyCode == 13) {avzoek();}
	return;}
function avzoek(){
	getcontainer('?av=av&sort='+$('#sort').val()+'&zoek='+$('#zoek').val());	
return;}
function getFileExtension(filename) {
  const lastDot = filename.lastIndexOf('.');
  return (lastDot !== -1 && lastDot < filename.length - 1) 
    ? filename.substring(lastDot + 1) 
    : '';
}
function changeviewer(newviewer,oldviewer){ //alleen in Nieuw-mode
	if (newviewer=='eigen'){ //van youtube of sketchfab naar eigen
		$('#viewer').val(orgviewer);
		$("#standaard").show();
		$("#yt").hide();
		$("#sf").hide();
		$('#divplaatjeyoutube').hide();
		$('#divplaatjesketchfab').hide();
		if($('#viewer').val()=='mp4'){
			$('#divplaatjemp4new').show();
		}else if($('#viewer').val()=='mp3'){
			$('#divplaatjemp3').show();
		}else if($('#viewer').val()=='panorama'){
			$('#divplaatjepanorama').show();
		}
	}else{ //naar sketchfab of youtube
		if (oldviewer=='eigen'){orgviewer=$('#viewer').val();}
		$("#standaard").hide();
		$('#viewer').val(newviewer);
		if (newviewer=='sketchfab'){$("#sf").show();zetsketchfab();}
		else{$("#yt").show();zetyoutube();}
	}
return;}
function zetyoutube(){
	$('#viewer').val('youtube');
	$('#divplaatjemp4new').hide();
	$('#divplaatjemp4').hide();
	$('#divplaatjemp3').hide();
	$('#divplaatjepanorama').hide();
	$('#divplaatjesketchfab').hide();
	$('#divplaatjeyoutube').show();
	if($('#ytcode').val()==''){$('#plaatjeyoutube').attr("src","images/playvideo.png");}
	else{$('#plaatjeyoutube').attr("src","avadmin.php?aktie=watermerk&soort=video&filenaam=https://i.ytimg.com/vi/"+$('#ytcode').val()+"/hqdefault.jpg");}
return;}
function zetsketchfab(){
	$('#viewer').val('sketchfab');
	$('#divplaatjemp4new').hide();
	$('#divplaatjemp4').hide();
	$('#divplaatjemp3').hide();
	$('#divplaatjepanorama').hide();
	$('#divplaatjeyoutube').hide();
	$('#divplaatjesketchfab').show();
	if($('#sfcode').val()==''){
		$('#plaatjesketchfab').show();
		$('#sketchfab-embed-wrapper').hide();
		$('#iframesketchfab').attr("src","");
	}else{
		$('#plaatjesketchfab').hide();
		$('#sketchfab-embed-wrapper').show();
		$('#iframesketchfab').attr("src","https://www.sketchfab.com/3d-models/"+$('#sfcode').val()+'/embed?autostart=0&amp;camera=0');
	}
return;}
function zetviewerselect(){ //wordt uitgevoerd na kiezen bestand voor upload
	if($('#orgfilename').val().indexOf("mp4")>0){
		$('#viewer').val('mp4');
		$('#keyframediv').show();
		$('#divplaatjemp3').hide();
		$('#divplaatjemp4').show();
		$('#divplaatjepanorama').hide();
		$('#divplaatjemp4new').hide();
	}
	else if($('#orgfilename').val().indexOf("mp3")>0){
		$('#viewer').val('mp3');
		$('#keyframediv').hide();
		$('#divplaatjemp4new').hide();
		$('#divplaatjemp4').hide();
		$('#divplaatjepanorama').hide();
		$('#divplaatjemp3').show();
	}
	else if($('#orgfilename').val().indexOf("jpg")>0){
		$('#viewer').val('panorama');
		$('#keyframediv').hide();
		$('#divplaatjemp4new').hide();
		$('#divplaatjemp4').hide();
		$('#divplaatjemp3').hide();
		$('#divplaatjepanorama').attr("src","images/360.png");
		$('#divplaatjepanorama').show();
	}
	else{
		alert('Ongeldig bestandsformaat');
		$('#orgfilename').val('');
		if($('#aktie').val()=='nieuw'){
			$('#keyframediv').hide();
			$('#divplaatjemp4new').hide();
			$('#divplaatjemp4').hide();
			$('#divplaatjemp3').hide();
			$('#divplaatjepanorama').hide();
			$('#viewer').val('');
		}
	}
return;}
function alertchange(){
	$('#savebutton').attr('class','ggbuttonrood');
return;}

//functies t.b.v. file uploads and thumb generation
function checkfile(){ //Wordt uitgevoerd zodra een bestand is gekozen. Deze wordt alvast ge-upload t.b.v. thumb generation.
	$('#ytcode').val('');
	$('#wachten').show();$('#aktieknoppen').hide();
	const d=new Date().getTime();
	const fileInput = document.getElementById('orgfilename');
	const file = fileInput.files[0];
	const formData = new FormData();
	formData.append('orgfilename', file);
	const xhr = new XMLHttpRequest();
	xhr.open('POST', 'avadmin.php', true);
	// Show progress container
	document.getElementById('progressContainer').style.display = 'block';
	xhr.upload.addEventListener('progress', function(e) {
		if (e.lengthComputable) {
			const percent = Math.round((e.loaded / e.total) * 100);
			document.getElementById('progressBar').value = percent;
			document.getElementById('progressPercent').innerText = percent + '%';
		}
	});
	//verwerk de file zodra de upload klaar is
	xhr.onload = function () {
		if (xhr.status === 200) {
			if (getFileExtension(file.name) === 'jpg') {
				imgElement=document.getElementById('plaatjepanorama');
				imgElement.onload = function () {
					// Clean up the handler
					imgElement.onload = null;
					const maxWidth = 299;
					const maxHeight = 250;
					const width = imgElement.naturalWidth;
					const height = imgElement.naturalHeight;
					const widthRatio = maxWidth / width;
					const heightRatio = maxHeight / height;
					const scale = Math.min(widthRatio, heightRatio, 1);
					imgElement.width = width * scale;
					imgElement.height = height * scale;
				};
				imgElement.src = 'avadmin.php?aktie=watermerk&soort=panorama&filenaam=AV/temp.jpg&t='+d;
				$('#wachten').hide();$('#aktieknoppen').show();
			}else if (getFileExtension(file.name) === 'mp3') {
				document.getElementById("mp3tekst").innerText = file.name;
				$('#wachten').hide();$('#aktieknoppen').show();
			}else if (getFileExtension(file.name) === 'mp4') {
				const videoElement = document.getElementById('eigenvid');
				const videoElementSrc = document.getElementById('plaatjemp4');
				const keyframeTime = parseFloat(document.getElementById('keyframe').value) || 0;
				// Load the new video file
				videoElementSrc.src = 'AV/temp.mp4?t=' + d;
				document.getElementById('eigenvid').load();
				// Once enough data is loaded, seek to the keyframe time
				videoElement.addEventListener('canplaythrough', function onLoaded() {
					videoElement.removeEventListener('canplaythrough', onLoaded);
					videoElement.currentTime = keyframeTime;
				});
				//after seeking to currentTime, generate the thumbnail after short delay
				videoElement.addEventListener('seeked', function onSeeked() {
					videoElement.removeEventListener('seeked', onSeeked);
					setTimeout(() => {maakmp4thumb();}, 500);
				});
			}
		}
	};
	xhr.send(formData);
return;}

function wijzigvideothumb(){
	const videoElement = document.getElementById('eigenvid');
	const keyframeTime = parseFloat(document.getElementById('keyframe').value) || 0;
	videoElement.currentTime = keyframeTime;
	//after seeking to currentTime, generate the thumbnail after short delay
	videoElement.addEventListener('seeked', function onSeeked() {
		videoElement.removeEventListener('seeked', onSeeked);
		setTimeout(() => {maakmp4thumb();}, 500);
	});
return;}

function maakmp4thumb(){
	const video = document.getElementById('eigenvid');
	const thumbsrc=document.getElementById('plaatjemp4').src.match(/AV\/(.*?)\.mp4/)[1];
    const canvas = document.getElementById('videoCanvas');
    const ctx = canvas.getContext('2d');
	let originalWidth = video.videoWidth;
	let originalHeight = video.videoHeight;

	const maxWidth = 299;
	const maxHeight = 250;

	let scale = Math.min(maxWidth / originalWidth, maxHeight / originalHeight);
	let newWidth = Math.round(originalWidth * scale);
	let newHeight = Math.round(originalHeight * scale);

	canvas.width = newWidth;
	canvas.height = newHeight;

	ctx.drawImage(video, 0, 0, newWidth, newHeight);

	const thumbnailBase64 = canvas.toDataURL('image/jpeg', 0.9);
	document.getElementById("thumbnailInput").value = thumbnailBase64;
	const formData = new FormData();
	formData.append('thumbnail', thumbnailBase64);
	formData.append('aktie', 'thumbcreate');
	formData.append('thumbnaam', thumbsrc);
	const xhr = new XMLHttpRequest();
	xhr.open('POST', 'avadmin.php', true);

	xhr.onload = function () {
		if (xhr.status === 200) {
		  const d = Date.now();
		// Load the new thumb on screen
		setTimeout(() => {document.getElementById('mp4thumb').src='avadmin.php?aktie=watermerk&soort=eigenvid&filenaam=AV/'+thumbsrc+'t.jpg&t='+d;}, 200);
		document.getElementById('wachten').style.display = 'none';
		document.getElementById('aktieknoppen').style.display = 'block';
		}
	};
	xhr.send(formData);
return;}

//Opslag
function checksubmit(aktie){ //Wordt uitgevoerd zodra op 'Sla op' is geklikt
	if($('#viewer').val()=='youtube'){
		if($('#ytcode').val()==''){
			if(confirm('U heeft nog geen Youtube code ingevuld.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#orgfilename').val('');
	}else if($('#viewer').val()=='sketchfab'){
		if($('#sfcode').val()==''){
			if(confirm('U heeft nog geen Sketchfab code ingevuld.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#orgfilename').val('');
	}else{ //eigen bestand
		if(aktie=='nieuw' && $('#orgfilename').val()==''){
			if (confirm('U heeft nog geen bestand gekozen.\nWilt u toch doorgaan?')==false){return false;}
		}
		$('#ytcode').val('');$('#sfcode').val('');
		$('#wachten').show();$('#aktieknoppen').hide();
	}
	$('#avform').submit();
}

function checkresult(){ //Wordt uitgevoerd zodra een POST naar avadmin.php een load genereert in het hidden iframe (a.g.v. Sla op)
	if (startloop==false){getcontainer('?av=av&sort='+$('#sort').val()+'&zoek='+$('#zoek').val()+'&pg='+$('#pg').val());}
	else{aantalloaded++;if(aantalloaded>0){startloop=false;}}
return;}

var backforwardused=false;var ctrltoets=false;
window.onpopstate=function(event){backforwardused=true;getcontainer('?'+window.location.search.substring(1));return;};
if(window.location.search.substring(1)==''){getcontainer('')}else{getcontainer('?'+window.location.search.substring(1))};
