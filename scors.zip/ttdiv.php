﻿<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/tt.mdb","","");
$defConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/definities.mdb","","");
//Get hostserver voor media
$basis="https://" . $_SERVER['HTTP_HOST']."/";
$fprs=odbc_exec($defConnect,"SELECT * from settings");
$row = odbc_fetch_array($fprs);
$basiskleur1=$row["basiskleur1"];
$basiskleur2=$row["basiskleur2"];
//Check of OCR enabled
$ocr=$row["txt"];
?>
<style>:root {--basiskleur1: <?php echo $basiskleur1; ?>;} :root {--basiskleur2: <?php echo $basiskleur2; ?>;}</style>
<?php
//genereer logfile voor TTcollectie als die nog niet bestaat
$oTextFile = fopen("log/scorsttlog.txt", "a");fwrite($oTextFile,"");fclose($oTextFile);

unset($fprs);

//Verwijder ongeoorloofde karakters van inputstrings
//'Level 1 is strenger
function cleaninput($ipar, $level){
	$acx=str_replace("<", "",$ipar);
	$acx=str_replace(">", "",$acx);
	$acx=str_replace(";", "",$acx);
	$acx=str_replace("]", "",$acx);
	$acx=str_replace("[", "",$acx);
	$acx=str_replace("{", "",$acx);
	$acx=str_replace("}", "",$acx);
	$acx=str_replace("%", "",$acx);
	$acx=str_replace("'", "",$acx);
	if ($level==1){
		$acx=str_replace("(", "",$acx);
		$acx=str_replace(")", "",$acx);
		$acx=str_replace(",", "",$acx);
		$acx=str_replace("%", "",$acx);
		$acx=str_replace(".", "",$acx);
	}
	return $acx;
}

function leesfilenaam(){
	global $naamttocr,$jaarocr,$jaargangocr,$maandocr,$noocr,$extratitelocr, $objConnect,$pdfnaam,$afbpath,$thumbpath,$fototitel,$fototitellang,$maanden,$basis;
	$filenaamquery="SELECT * FROM tt WHERE naamtt='".$naamttocr."' AND jaar='".$jaarocr."' AND jaargang='".$jaargangocr."' AND maand='".$maandocr."' AND nummer='".$noocr."' AND extratitel='".$extratitelocr."'";
	$fprs2=odbc_exec($objConnect,$filenaamquery);
	$fp_rs2=odbc_fetch_array($fprs2);
	$filenaam=$fp_rs2["filenaam"];
	odbc_free_result($fprs2);unset($fprs2);
	$thumbnaam=$filenaam.".jpg";
	$pdfnaam=$filenaam.".pdf";
	$afbpath=$basis."TTD/".$pdfnaam;
	$thumbpath=$basis."TTT/".$thumbnaam;
	$fototitel="Jaargang ".$jaargangocr;
	if ($noocr=="X"){$noocr="";}
	if ($extratitelocr=="X"){$extratitelocr="";}
	if($noocr!=""){$fototitel=$fototitel." No ".$noocr;}
	if($extratitelocr!=""){$fototitel=$fototitel." ".$extratitelocr;}
	$fototitellang=$jaarocr." ".$maanden[intval($maandocr)]." ".$fototitel;
	return;
}

function plaatsblok(){
	global $doel,$zsr,$jaar1,$jaar2,$naamtt,$znaamtt,$naamttocr,$Keyocr,$afbpath,$thumbpath,$fototitel,$fototitellang,$startpagocr,$eindpagocr,$maanden,$maandocr,$basis,$zkwoorden,$zkw,$zoek,$jaarocr,$rechten,$pg,$sort,$inhoud;
	$totaalinhoud="";$deelvoor="";$deelna="";$aantalgevonden=0;$eerstekeer=true;
	for ($teksti=$startpagocr;$teksti<=$eindpagocr;$teksti++){
		for ($zki=0;$zki<$zkw;$zki++){
			$beginpos=0;$hulp=strpos($inhoud[$teksti],strtolower($zkwoorden[$zki]));
			while ($hulp!==false and $aantalgevonden<6){
				if ($hulp>150){$beginpos=$hulp-150;}else{$beginpos=0;}
				if($eerstekeer==false){$totaalinhoud.="<br>----//----<br>";}
				$deelvoor=substr($inhoud[$teksti],$beginpos,150);
				$deelna=substr($inhoud[$teksti],$hulp,150);
				$deelna=str_replace($zkwoorden[$zki],"<font class=markeerblauw>".$zkwoorden[$zki]."</font><font class=tekst2>",$deelna);
				$eerstekeer=false;
				$hulp=strpos($inhoud[$teksti],strtolower($zkwoorden[$zki]),$hulp+strlen($zkwoorden[$zki]));
				$totaalinhoud.=$deelvoor.$deelna;$aantalgevonden++;
				if($aantalgevonden==6 and $hulp!==false){$totaalinhoud.="<br>.......<br><i>meer resultaten gevonden</i>";}
			}
		}
	}
	?>	
	<div align="left" class="ttc dispinline" width="249" valign="top">
		<div>
			<table class="layoutfixed ttc dispinline" width="290" cellspacing="0" cellpadding="0" class="bcollapse"><tr>
			<?php if($rechten=="mo" or $rechten=="sup"){ ?>	
				<td colspan="4" class="ttc" width="249" height="18">
					<button onclick="getcontainer('?zsr=<?php echo $zsr; ?>&znaamtt=<?php echo $znaamtt; ?>&jaar1=<?php echo $jaar1; ?>&jaar2=<?php echo $jaar2; ?>&av=tt&aktie=edit&Key=<?php echo $Keyocr; ?>&pg=<?php echo $pg; ?>&sort=<?php echo $sort; ?>&zoek=<?php echo $zoek; ?>')" title="Wijzig gegevens van dit tijdschrift" class="ggbutton">Edit</button>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<button onclick="delcheck('<?php echo $Keyocr; ?>','<?php echo $fototitellang; ?>');" title="verwijder dit tijdschrift" class="ggbutton">Del</button>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1>
					<?php if ($doel=="v"){echo "publiek";}else if ($doel=="e"){echo "leden";}else{echo "prive";} ?>
					</font>
				</td>
			</tr><tr>
			<?php
			} ?>
			<td class="ttc" width="186" height="283" style="vertical-align:middle;background-color:#eeeeee;">
				<div align="center" class="frame">
					<a data-type="iframe" data-fancybox="ttocr" class="deconone" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $afbpath; ?>&search=<?php echo $zkwoorden[0]; ?>&zoom=page-fit" data-caption="<?php echo $fototitellang; ?>" title="">
						<img  class="thumbttc handje" alt="" border="0" src="<?php echo $thumbpath."?t=".time(); ?>">
					</a>
				</div>
			</td>
			<td class="ttc" width="3">&nbsp;</td>
			<td class="ttc" width="30" rowspan="2" style="vertical-align:top;">
				<a class="ttinfo deconone"><font class="tekst2">
				Treffers:<br>
				<img style="border:2px solid #aaaaaa;border-radius:4px;" src="<?php echo $basis; ?>images/docview.gif" alt="" border="0" width="20" height="20"><span><font class="tekst2"><?php echo $totaalinhoud; ?></font></span></a>	
			</td>
			<td class="ttc" width="30" rowspan="2"></td>
			</tr><tr>
				<td class="ttc" width="186" height="105" valign="top">
					<div align="center" style="line-height:100%;position:relative;top:5px;">
					<font  style="font-size:14px;"><?php echo $naamtt; ?><br><?php echo $maanden[intval($maandocr)]." ".$jaarocr; ?></font>
					</div>
					<div align="center" style="line-height:85%;position:relative;top:8px;">
					<font  style="font-size:12px;">&nbsp;<?php echo $fototitel; ?></font>
					</div>
				</td>
				<td class="ttc" width="3">&nbsp;</td>
			</tr></table>
		</div>
	</div>
	<?php
return;
}

//Lees de input parameters
$sort="DESC";$zoek="";$aktie="";$pg="";$Key="";$zsr=1;$znaamtt="";$jaar1="";$jaar2="";
$now = new DateTime( 'NOW' );
$diffSeconds = $now->getTimestamp();
$maanden=array("","JANUARI","FEBRUARI","MAART","APRIL","MEI","JUNI","JULI","AUGUSTUS","SEPTEMBER","OKTOBER","NOVEMBER","DECEMBER");
$maandnummers=array("","01","02","03","04","05","06","07","08","09","10","11","12");

if(isset($_REQUEST["sort"])){$sort=cleaninput($_REQUEST["sort"],1);}
if(isset($_REQUEST["zoek"])){$zoek=cleaninput($_REQUEST["zoek"],1);}
if(isset($_REQUEST["aktie"])){$aktie=cleaninput($_REQUEST["aktie"],1);}
if(isset($_REQUEST['pg'])){$pg=cleaninput($_REQUEST["pg"],1);}
if(isset($_REQUEST['Key'])){$Key=cleaninput($_REQUEST["Key"],1);}
if(isset($_REQUEST['zsr'])){$zsr=cleaninput($_REQUEST["zsr"],1);}
if(isset($_REQUEST['znaamtt'])){$znaamtt=cleaninput($_REQUEST["znaamtt"],1);}
if(isset($_REQUEST['jaar1'])){$jaar1=cleaninput(strval($_REQUEST["jaar1"]),1);}
if(isset($_REQUEST['jaar2'])){$jaar2=cleaninput(strval($_REQUEST["jaar2"]),1);}

?>
<div align="center" id="top"></div>
<?php
if(($aktie=="edit" or $aktie=="nieuw") and ($rechten=="mo" or $rechten=="sup")){ //toon edit-item scherm

	if($aktie=="edit"){
		$koptitel="Edit bestaand tijdschrift";
		$fprs=odbc_exec($objConnect,"SELECT * FROM tt WHERE Key=".strval($Key));
		$fp_rs=odbc_fetch_array($fprs);
		$jaar=$fp_rs["jaar"];
		$maand=$fp_rs["maand"];
		$jaargang=$fp_rs["jaargang"];
		$naamtt=$fp_rs["naamtt"];
		$no=$fp_rs["nummer"];if($no=="X"){$no="";}
		$extratitel=$fp_rs["extratitel"];if($extratitel=="X"){$extratitel="";}
		$filenaam=$fp_rs["filenaam"];
		$doel=$fp_rs["doel"];
		$ts=$fp_rs["ts"];$tse=$fp_rs["tse"];
		$toevoeger=$fp_rs["toevoeger"];$aanpasser=$fp_rs["aanpasser"];
	}else if($aktie=="nieuw"){
		$koptitel="Voeg nieuw tijdschrift toe";
		$jaar="";$maand="";$jaargang="";$no="";	$extratitel="";$filenaam="";$naamtt="";$doel="e";
		// Zoek een vrij Indexnummer in de TT tabel
		// Lees alle Indexnummers in
		$fprs=odbc_exec($objConnect,"SELECT Key FROM tt ORDER BY Key ASC");
		$gevonden=false;
		$vorignummer=0;
		while ($gevonden==false and $row = odbc_fetch_array($fprs)){
			$testnummer=intval($row['Key']);
			if ($testnummer-$vorignummer>1 and $vorignummer>0) {	
				$gevonden=true;
			}else{
				$vorignummer=$testnummer;
			}
		}
		$Key=$vorignummer+1;
		odbc_free_result($fprs);
	} ?>

	<div style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;">
		<br><br><span style="color: basiskleur2;font-size:26px;"><b><?php echo $koptitel; ?></b></span>
	</div>

	<div align="center">
		<br><br>
		<table border="0" cellspacing="0" width="1055" style="border-collapse: collapse;background-color:#FFFFFF; border-color:#afafaf;border-left-width:0px; border-right-width:0px; border-top-style:solid; border-top-width:2px; border-bottom-width:0px"><tr><td>

			<br><br>
			<div style="margin:0px <?php echo $maxmarg; ?>px;">
				<form target="ttedit" id="ttform" name="ttform" action="ttadmin.php" method="POST" enctype="multipart/form-data">
				<input name="aktie" id="aktie" type="hidden" value="<?php echo $aktie; ?>">
				<input name="filenaam" id="filenaam" type="hidden" value="<?php echo $filenaam; ?>">
				<input name="pg" id="pg" type="hidden" value="<?php echo $pg; ?>">
				<input name="zoek" id="zoek" type="hidden" value="<?php echo $zoek; ?>">
				<input name="zsr" id="zsr" type="hidden" value="<?php echo $zsr; ?>">
				<input name="znaamtt" id="znaamtt" type="hidden" value="<?php echo $znaamtt; ?>">
				<input name="sort" id="sort" type="hidden" value="<?php echo $sort; ?>">
				<input name="Key" id="Key" type="hidden" value="<?php echo $Key; ?>">
				<input name="jaar1" id="jaar1" type="hidden" value="<?php echo $jaar1; ?>">
				<input name="jaar2" id="jaar2" type="hidden" value="<?php echo $jaar2; ?>">
				
				Naam tijdschrift:&nbsp;<input onfocus="vulnamen();" class="naamtt" name="naamtt" id="naamtt" value="<?php echo $naamtt; ?>"><br><br>
				Jaar:&nbsp;<input name="jaar" id="jaar" value="<?php echo $jaar; ?>">
				Jrg:&nbsp; <input name="jaargang" id="jaargang" value="<?php echo $jaargang; ?>">
				Maand:&nbsp;
				<select name="maand" id="maand">
				<?php for ($i=1;$i<=12;$i++){ ?><option <?php if($maand==$maandnummers[$i]){echo " selected ";} ?> value="<?php echo $maandnummers[$i]; ?>"><?php echo $maanden[$i]; ?></option><?php } ?>
				</select>
				Nummer:&nbsp;<input name="no" id="no" value="<?php echo $no; ?>">
				<br><br>

				Extra titel, b.v. Kerst, Carnaval, Bijlage..., Extra ivm... etc.:<br>
				<input type="text" name="extratitel" id="extratitel" value="<?php echo $extratitel; ?>" size="100"><br><br>
				
				<input name="doel" type="radio" value="v" <?php if($doel=="v"){echo " checked ";} ?>>Publiek&nbsp;&nbsp;&nbsp;
				<input name="doel" type="radio" value="e" <?php if($doel=="e"){echo " checked ";} ?>>Leden&nbsp;&nbsp;&nbsp;
				<input name="doel" type="radio" value="p" <?php if($doel=="p"){echo " checked ";} ?>>Prive<br><br>

				Upload of vervang PDF:<br>
				<input type="file" accept="application/pdf" name="orgfilename" id="orgfilename" /><br><br>
				
				<button class="ggbutton" onclick="wachtimage();">Sla op</button>&nbsp;&nbsp;&nbsp;
				<button class="ggbutton" onclick="getcontainer('?jaar1=<?php echo $jaar1; ?>&jaar2=<?php echo $jaar2; ?>&znaamtt=<?php echo $znaamtt; ?>&zsr=<?php echo $zsr; ?>&av=tt&pg=<?php echo $pg; ?>&sort=<?php echo $sort; ?>&zoek=<?php echo $zoek; ?>')">Exit</button>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<?php
				if ($aktie=="edit"){
					$toevoeger=explode("@",$toevoeger)[0];if($toevoeger!=""){$toevoeger=" (".$toevoeger.")";}
					$aanpasser=explode("@",$aanpasser)[0];if($aanpasser!=""){$aanpasser=" (".$aanpasser.")";}
					$opvoerdatum=date("d M Y",$ts);
					$wijzigdatum=date("d M Y",$tse);
					?>								
					<font class="tekst1"><i>
					Toegevoegd&nbsp;<?php echo $opvoerdatum.$toevoeger; ?><br>
					<?php if(($ts!=$tse) and $tse>0){ ?>	Aangepast&nbsp;<?php echo $wijzigdatum.$aanpasser; ?><?php } ?>
					</i></font>
				<?php
				} ?>
				
				</form>
				<br>
				<div align="center" id="wachtdiv" name="wachtdiv" style="display:none;"><img src="images/wacht.gif"></div>
			</div>
			<br>
			
		</td></tr></table>
		<br><br><br>
	</div>
	<iframe style="display:none;" name="ttedit" id="ttedit" src="" onload="checkresult();"></iframe>

<?php
	
}else{ //gewoon scherm

	//ADMIN BLOK
	if($rechten=="mo" or $rechten=="sup"){ ?>
		<div align="center">
			<button class="ggbutton" onclick="getcontainer('?aktie=nieuw');">Nieuw tijdschrift</button></a>&nbsp;
			<a data-fancybox="log" data-type="iframe" href="log/scorsttlog.txt?t=<?php echo $diffSeconds; ?>">
			<button class="ggbutton">Open logfile</button></a>&nbsp;
			<?php
			$bestanden=scandir("./ocr/");$aantal=0;
			foreach($bestanden as $bestand){
				if($bestand!="." and $bestand!=".." and $bestand!="out"){
					$bestandstype=strtolower(pathinfo($bestand,PATHINFO_EXTENSION));
					if (strpos("jpg pdf txt",$bestandstype)!==false){$aantal++;}
				}
			} ?>
			<a data-fancybox="ocrqueue" data-type="iframe" href="aashowstatus.php?aktie=ocrqueue"><button class="ggbutton<?php if($aantal>0){echo "rood";} ?>">TXT wachtrij</button></a>&nbsp;
			<a class="ainfo deconone" id="buttonteksten" style="color:white"><button class="ggbutton"><b>?</b></button>
			<span><font size="2">
				<b>TXT wachtrij</b>: toont de bestanden die nog voor tekstherkenning in de wachtrij staan (de knop is dan rood).
			</span></font></a>
			<br><br>
		</div>
	<?php }
	if(strpos("asc desc ts tse",$sort)===false){$sort="desc";}
	$hulppg="";$pg=1;
	if(isset($_REQUEST['pg'])){$hulppg=cleaninput($_REQUEST["pg"],1);}
	if (is_numeric($hulppg)){
		$pg=0+$hulppg;
		if ($pg==0){$pg=1;}
	}
	if ($pg==0){$pg=1;}
	$pagesize=60; ?>
	<input type="hidden" name="zsr" id="zsr" value="<?php echo $zsr; ?>">
	<?php
	//Stel de SQL Querystring samen
	$zoek=str_replace("+"," ",$zoek);
	$zoek=str_replace("%20", " ",$zoek);
	$zoek=str_replace("%", "",$zoek);
	$zoek=str_replace(chr(34), "",$zoek);
	$zoek=str_replace("'", "",$zoek);
	while (strpos($zoek,"  ")!==false){$zoek=str_replace("  ", " ",$zoek);}
	$zoek=trim($zoek);$zoektabel="tt";
	$somstuk="";
	if($sort!="tse" and $sort!="ts"){
		$orderstuk=" ORDER BY tt.jaar ".$sort.",tt.maand ".$sort.",tt.nummer ".$sort.",tt.naamtt ".$sort.",tt.extratitel ".$sort;
	}else{
		$orderstuk=" ORDER BY ".$sort." DESC";
	}
	if (strlen($zoek)>0 or strlen($znaamtt)>0 or strlen($jaar1)>0 or strlen($jaar2)>0){
		$zkwoorden=explode(" ",$zoek,10);
		$zkw=count($zkwoorden);
		if($zsr==1){ //zoek alle tijdschriften van een bepaalde naam en met zoekterm in jaar of extratitle
			$zoektabel="tt";
			$somstuk="(naamtt&extratitel like '%".$zkwoorden[0]."%')";
			for($zki=1;$zki<$zkw;$zki++){
				$somstuk.=" AND (naamtt&extratitel like '%".$zkwoorden[$zki]."%')";
			}
			if(strlen($znaamtt)>0){$somstuk.=" AND (naamtt='".$znaamtt."')";}
			if($rechten==""){$somstuk.=" AND (doel='v')";}
			if($rechten=="ufa"){$somstuk.=" AND (doel='v' OR doel='e')";}
			if (strlen($jaar1)>0){
				if (strlen($jaar2)>0){
					$somstuk.=" AND ((jaar >='".$jaar1."' AND jaar <='".$jaar2."') OR jaar like '%".$jaar2."%')";
				}else{
					$somstuk.=" AND ((jaar >='".$jaar1."') OR jaar like '%".$jaar1."%')" ;
				}
			}else{
				if (strlen($jaar2)>0){$somstuk.="(jaar <= '".$jaar2."' OR jaar like '%".$jaar2."%')";}
			}			
			$somstuk=" WHERE (".$somstuk.")";
			$fp_sQry="SELECT * FROM tt ".$somstuk.$orderstuk;
			$fp_sQryCount="SELECT COUNT(*) as aantal FROM (SELECT * FROM tt ".$somstuk.")";
		}else{//zoek in artikelteksten
			$orderstuk.=",volgnummer ASC";
			$zoektabel="ocr";
			$somstuk="(ocr2.tekst like '%".$zkwoorden[0]."%')";
			for($zki=1;$zki<$zkw;$zki++){
				$somstuk=$somstuk." AND (ocr2.tekst like '%".$zkwoorden[$zki]."%')";
			}
			if(strlen($znaamtt)>0){$somstuk.=" AND (tt.naamtt='".$znaamtt."')";}
			if($rechten==""){$somstuk.=" AND (tt.doel='v')";}
			if($rechten=="ufa"){$somstuk.=" AND (tt.doel='v' OR tt.doel='e')";}
			if (strlen($jaar1)>0){
				if (strlen($jaar2)>0){
					$somstuk.=" AND ((tt.jaar >='".$jaar1."' AND tt.jaar <='".$jaar2."') OR tt.jaar like '%".$jaar2."%')";
				}else{
					$somstuk.=" AND ((tt.jaar >='".$jaar1."') OR tt.jaar like '%".$jaar1."%')" ;
				}
			}else{
				if (strlen($jaar2)>0){$somstuk.="(tt.jaar <= '".$jaar2."' OR tt.jaar like '%".$jaar2."%')";}
			}			
			$somstuk=" WHERE (".$somstuk.")";
			$fp_sQry="SELECT ocr2.* FROM ocr2 INNER JOIN tt ON ocr2.Key = tt.Key ".$somstuk.$orderstuk;
			$fp_sQryCount="SELECT COUNT(*) as aantal FROM (SELECT ocr2.* FROM ocr2 INNER JOIN tt ON ocr2.Key = tt.Key ".$somstuk.")";
		}
	}else{
		if($rechten==""){
			$fp_sQry="SELECT * FROM tt WHERE doel='v' ".$orderstuk;
			$fp_sQryCount="SELECT COUNT(*) as aantal FROM tt WHERE doel='v' ".$somstuk;
		}
		else{
			$fp_sQry="SELECT * FROM tt ".$orderstuk;
			$fp_sQryCount="SELECT COUNT(*) as aantal FROM tt ".$somstuk;
		}
	}
	//echo $fp_sQry."<br>";
	//echo $fp_sQryCount."<br>";
	//Doe de count-query
	$fprs=odbc_exec($objConnect,$fp_sQryCount);
	$aantalrecords=0;
	if($fp_rs=odbc_fetch_array($fprs)){$aantalrecords=$fp_rs['aantal'];};
	?>

	<div class="ttc" align="center" id="top" style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;">
		<!-- ZOEKBLOK-->
		<div class="aac dispinline">
			<?php
				$sqltekst="SELECT DISTINCT naamtt FROM tt WHERE LEN(naamtt)>0 ORDER BY naamtt ASC";
				if($rechten==""){$sqltekst="SELECT DISTINCT naamtt FROM tt WHERE LEN(naamtt)>0 AND doel='v' ORDER BY naamtt ASC";}
				if($rechten=="ufa"){$sqltekst="SELECT DISTINCT naamtt FROM tt WHERE LEN(naamtt)>0 AND (doel='v' OR doel='e') ORDER BY naamtt ASC";}
				$tnamen=odbc_exec($objConnect,$sqltekst);$ttaantal=0;
				while ($tnaam=odbc_fetch_array($tnamen)){$ttaantal++;}
				odbc_free_result($tnamen);
				unset($tnamen);
			?>
			<table width="350" class="layoutfixed dispinline aac bgzoek" border="0"><tr>
				<td width="10" height="35" class="aac geenwrap" align="left">&nbsp;</td>			
				<td width="20" class="aac geenwrap" align="left">
					<a class="info deconone"><button class="ggbutton">?</button>
					<span><font class="tekst2">
					<b>Algemeen</b><br>
					<ul>
					<li>In het zoekveld kunnen geen letters met trema&#39;s (b.v. <b>&uuml;</b>), accenten (b.v. <b>&eacute;</b>), tildes (b.v. <b>&ntilde;</b>), cedilles (b.v. <b>&ccedil;</b> ) of andere z.g. diacritische tekens worden gebruikt.</li>
					<li>Laat algemene woorden als &#39;het&#39;, &#39;een&#39;, &#39;de&#39; enz. weg.</li>
					<li>Het zoeken is niet hoofdletter-gevoelig.</li>
					<li>Alleen resultaten waarin alle gebruikte zoekwooden voorkomen worden getoond.</li>
					<li>Soms helpt het om een deel van de zoekterm te gebruiken, b.v. <b>meester kempena</b> i.p.v. <b>burgemeester Kempenaars</b>.<br>
					Ook het splitsen van woorden kan soms helpen, b.v. <b>sport&nbsp;&nbsp;wedstrijd</b> i.p.v. <b>sportwedstrijd</b>.</li>
					</ul>
					<b>Zoek tijdschrift</b>
					<ul><li>Zoekt in de naam, het jaartal en eventuele aanvullende tekst in de titel van de tijdschriften.</li></ul>
					<?php if($ocr!=""){ ?>
					<b>Zoek in artikelteksten</b>
					<ul>
					<li>Levert alleen resultaten op van tijdschriften waarvan de PDF pagina-teksten ook daadwerkelijk doorzoekbaar zijn.
					<li>Bij gestencilde tijdschriften is het zoeken op tekst niet altijd even succesvol als gevolg van de soms slecht afgedrukte letters.</li>
					</ul>
					<?php } ?>
					</font></span></a>
				</td>
				<td width="320" class="aac geenwrap" align="left">
					<input style="border-radius:4px;" type="text" name="zoek" id="zoek" value="<?php echo $zoek; ?>" size="40" onkeypress="keyPressListener(event);">
				</td>
			</tr></table>

			<table width="350" class="layoutfixed dispinline aac bgzoek" border="0" ><tr>
				<td width="10" height="35" class="aac geenwrap" align="left">&nbsp;</td>			
				<td width="20" class="aac geenwrap" align="left">
					<a class="info deconone"><button class="ggbutton">?</button>
					<span><font class="tekst2"><b>Zoeken op jaartallen:</b><ul><li>Vul alleen het VANAF jaar in om 
					tijdschriften te tonen vanaf dat jaar tot nu.</li>
					<li>Vul zowel het VANAF jaar als het T/M jaar in om tijdschriften te tonen 
					uit de tussenliggende periode (incl. tijdschriften uit de ingevulde jaartallen 
					zelf).</li>
					<li>Vul alleen het T/M jaar in om tijdschriften te tonen tot en met dat 
					jaar en ouder.</li>
					</ul>
					</font></span></a>
				</td>
				<td width="320" class="aac geenwrap" align="left">
					<i>Jaar&nbsp;vanaf:</i>
					<i>
					<input id="jaar1" name="jaar1" value="<?php echo $jaar1; ?>" size="4" maxlength="4" onblur="checknummer('jaar1');">
					&nbsp;t/m:&nbsp;<input id="jaar2" name="jaar2" value="<?php echo $jaar2; ?>" size="4" maxlength="4" onblur="checknummer('jaar2');">
					</i>
				</td>
			</tr></table>

			<table width="350" class="layoutfixed dispinline aac bgzoek" border="0" ><tr>
				<td width="10" height="35" class="aac geenwrap" align="left">&nbsp;</td>			
				<td width="55" height="35" class="aac geenwrap" align="left">&nbsp;<?php if($ttaantal>1){echo '<i>Tijdschrift:</i>';} ?></td>
				<td width="285" class="aac geenwrap" align="left">
					<div id="ttlijst" name="ttlijst" style="display:<?php if($ttaantal>1){echo 'block';}else{echo 'none';} ?>">
					<select naam="znaamtt" id="znaamtt">
						<option value="" <?php if($znaamtt==""){echo " selected ";} ?>>Alle</option>
						<?php
						if($ttaantal>1){
							$tnamen=odbc_exec($objConnect,$sqltekst);
							while ($tnaam=odbc_fetch_array($tnamen)){
								$hulp=$tnaam["naamtt"];	?>
								<option value="<?php echo $hulp; ?>" <?php if($znaamtt==$hulp){echo " selected ";} ?>><?php echo $hulp; ?></option>
							<?php
							}
						}
						odbc_free_result($tnamen);
						unset($tnamen);
					?>					
					</select>
					</div>
				</td>
			</tr></table>
			
			<table width="350" class="layoutfixed dispinline aac bgzoek" border="0" ><tr>
				<td width="10" height="35" class="aac geenwrap" align="left">&nbsp;</td>			
				<td width="55" class="aac geenwrap" align="left">&nbsp;<i>Sorteer:</i></td>
				<td width="285" class="aac geenwrap" align="left">
						<select onchange="getsearch();" id="sort" name="sort">
						<option value="desc" <?php if($sort=="desc"){echo "selected";} ?>>Jaar aflopend</option>
						<option value="asc" <?php if($sort=="asc"){echo "selected";} ?>>Jaar oplopend</option>
						<option value="ts" <?php if($sort=="ts"){echo "selected";} ?>>Meest recent toegevoegd</option>
						<option value="tse" <?php if($sort=="tse"){echo "selected";} ?>>Meest recent aangepast</option>
						</select>
				</td>
			</tr></table>
			
			<table width="350"  class="layoutfixed dispinline aac bgzoek" border="0" ><tr>
				<td width="10" height="35" class="aac geenwrap" align="left"></td>			
				<td width="20" class="aac geenwrap" align="left"></td>			
				<td width="320" class="aac geenwrap" align="left">
					<button class="ggbutton<?php if($zsr==1){echo 'B';} ?>" id="zoektt" name="OK" onclick="ttzoek(1);">Zoek tijdschrift</button>&nbsp;&nbsp;
					<?php if ($ocr!=""){ ?>
					<button class="ggbutton<?php if($zsr==2){echo 'B';} ?>" id="zoekstart" name="OK" onclick="ttzoek(2);">Zoek in artikelteksten</button>&nbsp;&nbsp;
					<?php } ?>
				</td>
			</tr></table>
			
			<table width="350"  class="layoutfixed dispinline aac bgzoek" border="0" ><tr>
				<td width="350" height="35" class="aac geenwrap">
					<button class="ggbutton" onclick="getcontainer('?zsr='+$('#zsr').val()+'&sort='+$('#sort:checked').val());">Wis selecties</button>
				</td>
			</tr></table>

			<table width="350"  class="layoutfixed dispinline aac" border="0" ><tr>
				<td width="350" height="35" class="aac geenwrap">&nbsp;</td>
			</tr></table>
		</div>
	</div>

	<?php
	if ($aantalrecords>0){ 
		if ($aantalrecords>900){$pagesize=intdiv($aantalrecords*$pagesize,900);}
		//move to position
		$CurrentPage=$pg;
		$PageCount=intdiv($aantalrecords,$pagesize)-(($aantalrecords%$pagesize)==0)+1;
		if ($CurrentPage<1){$CurrentPage=1;}
		if ($CurrentPage>$PageCount){$CurrentPage=$PageCount;}
		?>
		<div align="center" style="margin:0px 35px;max-width:<?php echo $maxbreed; ?>px;">
		
		<?php include 'ttdivnav.php';	?>	
		<?php
		if($zoektabel=="tt"){ //Start zoektabel=tt
			
			$regelteller=1;$jaaroud="";$eerstetop=true;
			$fprs=odbc_exec($objConnect,$fp_sQry);
			while($fp_rs=odbc_fetch_array($fprs)){
				$positieteller=($pagesize*($pg-1))+$regelteller;
				if ($regelteller>$pagesize){break;}
				if($positieteller>$aantalrecords){break;}
				if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
				$Key=$fp_rs["Key"];
				$jaar=$fp_rs["jaar"];
				$maand=$fp_rs["maand"];
				$naamtt=$fp_rs["naamtt"];
				$doel=$fp_rs["doel"];
				$jaargang=$fp_rs["jaargang"];
				$no=$fp_rs["nummer"];if($no=="X"){$no="";}
				$filenaam=$fp_rs["filenaam"];
				if($jaar!=$jaaroud){$jaarwissel=true;$jaaroud=$jaar;}else{$jaarwissel=false;}
				$thumbnaam=$filenaam.".jpg";
				$pdfnaam=$filenaam.".pdf";
				$afbpath=$basis."TTD/".$pdfnaam;
				$thumbpath=$basis."TTT/".$thumbnaam;
				$fototitel=" Jaargang ".$jaargang;
				if($no!=""){$fototitel=$fototitel." No ".$no;}
				$extratitel=$fp_rs["extratitel"];if($extratitel=="X"){$extratitel="";}
				if($extratitel!=""){$fototitel=$fototitel." ".$extratitel;}
				$fototitellang=$naamtt." ".$jaar." ".$maanden[intval($maand)]." ".$fototitel;
				
				if($jaarwissel){ ?>
					<table class="ttc bcollapse" width="100%" cellspacing="0" cellpadding="0"><tr>
						<td class="ttc" align="left">
							<font style="font-size:20px;"><?php if($zoektabel=="tt"){echo $jaar;}else{echo $jaarocr;} ?></font><br>&nbsp;
						</td><td class="ttc" align="right">
							<?php
							if($eerstetop==false){ ?>
								<button class="ggbutton" onclick="$('body,html').animate({scrollTop: $('#top').offset().top},400);">TOP</button>
							<?php
							} ?>
						</td>
					</td></tr></table>
					<?php
					$eerstetop=false;
				} ?>

				<div align="left" class="ttc dispinline" width="189" valign="top">
					<div id="blok<?php echo $Key; ?>">
					<table class="layoutfixed ttc dispinline" width="189" cellspacing="0" cellpadding="0" class="bcollapse"><tr>
					<?php if($rechten=="mo" or $rechten=="sup"){ ?>	
						<td colspan="2" class="ttc" width="189" height="18">
							<button class="ggbutton" onclick="getcontainer('?znaamtt=<?php echo $znaamtt; ?>&zsr=<?php echo $zsr; ?>&jaar1=<?php echo $jaar1; ?>&jaar2=<?php echo $jaar2; ?>&av=tt&aktie=edit&Key=<?php echo $Key; ?>&pg=<?php echo $pg; ?>&sort=<?php echo $sort; ?>&zoek=<?php echo $zoek; ?>')" title="Wijzig gegevens van dit tijdschrift" class="ggbutton">Edit</button>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<button class="ggbutton" onclick="delcheck('<?php echo $Key; ?>','<?php echo $fototitellang; ?>');" title="Verwijder dit tijdschrift">Del</button>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1>
							<?php if ($doel=="v"){echo "publiek";}else if ($doel=="e"){echo "leden";}else{echo "prive";} ?>
							</font>
						</td>
					</tr><tr>
					<?php
					} ?>
					<td class="ttc" width="186" height="265" style="vertical-align:middle;background-color:#eeeeee;">
						<div align="center" class="frame">
							<a id="fotohref<?php echo $Key; ?>" data-type="iframe" data-fancybox="<?php echo $Key; ?>" class="deconone" href="<?php echo $basis ?>pdfjs/web/viewer.html?t=<?php echo time(); ?>&file=<?php echo $afbpath; ?>#page=1&zoom=page-fit" data-caption="<?php echo $fototitellang; ?>" title="">
								<img  class="thumbttc handje" id="foto<?php echo $Key; ?>" alt="" border="0" src="<?php echo $thumbpath."?t=".time(); ?>">
							</a>
						</div>
					</td>
					<td class="ttc" width="3">&nbsp;</td>
					</tr><tr>
					<td class="ttc" width="186" height="105" valign="top">
						<div align="center" style="line-height:100%;position:relative;top:5px;">
						<font  style="font-size:14px;"><?php echo $naamtt; ?><br><?php echo $maanden[intval($maand)]." ".$jaar;; ?></font>
						</div>
						<div align="center" style="line-height:85%;position:relative;top:8px;">
						<font  style="font-size:12px;">&nbsp;<?php echo $fototitel; ?></font>
						</div>
					</td>
					<td class="ttc" width="3">&nbsp;</td>
					</tr></table>
					</div>
				</div>
					
			<?php
			$regelteller=$regelteller+1;
		}
		//next record
		// Einde zoektabel=tt
			
		}else{ // Start zoektabel=ocr
			$regelteller=1;$eerstetop=true;
			$fprs=odbc_exec($objConnect,$fp_sQry);
			$naamtt="";$jaar="";$maand="";$jaargang="";$no="";$extratitel="";$Key="";$fototitel="";$fototitellang="";
			$startpagocr=($pagesize*($pg-1))+1;
			$inhoud=array_fill(0, 8000, '');
			while($fp_rs=odbc_fetch_array($fprs)){
				$positieteller=($pagesize*($pg-1))+$regelteller;
				if ($regelteller>$pagesize){break;}
				if($positieteller>$aantalrecords){break;}
				if (!$fp_rs=odbc_fetch_array($fprs,$positieteller)){break;}
				$Keyocr=$Key;$Key=$fp_rs["Key"];
				$fprstt=odbc_exec($objConnect,"SELECT * FROM tt WHERE Key=".strval($Key));
				$ttrow=odbc_fetch_array($fprstt);
				$doel=$fp_rs["doel"];
				$jaarocr=$jaar;$jaar=$ttrow["jaar"];
				$naamttocr=$naamtt;$naamtt=$ttrow["naamtt"];
				$maandocr=$maand;$maand=$ttrow["maand"];
				$jaargangocr=$jaargang;$jaargang=$ttrow["jaargang"];
				$noocr=$no;$no=$ttrow["nummer"];
				$extratitelocr=$extratitel;$extratitel=$ttrow["extratitel"];
				odbc_free_result($fprstt);
				unset($fprstt);
				$inhoud[$positieteller]=strtolower($fp_rs["tekst"]);
				$hulp1=$naamtt.$jaar.$maand.$jaargang.$no.$extratitel;
				$hulp2=$naamttocr.$jaarocr.$maandocr.$jaargangocr.$noocr.$extratitelocr;

				if(($hulp1!=$hulp2) and $regelteller>1){
					leesfilenaam();
					$eindpagocr=$positieteller-1;
					plaatsblok();
					$startpagocr=$positieteller;
				}

				if($jaar!=$jaarocr and $positieteller<=$aantalrecords){ ?>
					<table class="ttc bcollapse" width="100%"><tr>
						<td class="ttc">
							<font style="font-size:20px;"><?php echo $jaar; ?></font><br>&nbsp;
						</td><td class="ttc">
							<font class="tekst3"><b>Gezocht op:&nbsp;<?php echo $zoek; ?></b></font><br>&nbsp;
						</td><td class="ttc">
							<?php
							if($eerstetop==false){ ?>
								<button class="ggbutton" onclick="$('body,html').animate({scrollTop: $('#top').offset().top},400);">TOP</button>
							<?php
							} ?>
						</td>
					</td></tr></table>
					<?php
					$eerstetop=false;	
				}

				if(($positieteller==$aantalrecords) or ($regelteller==$pagesize)){
					//laatste moet ook nog
					$jaarocr=$jaar;
					$maandocr=$maand;
					$naamttocr=$naamtt;
					$jaargangocr=$jaargang;
					$noocr=$no;
					$extratitelocr=$extratitel;
					leesfilenaam();
					$eindpagocr=$positieteller;
					plaatsblok();
				}
				$regelteller=$regelteller+1;
			} //next record
		}  //Einde zoektabel=OCR
		?>

		<table class="ttc bcollapse" width="100%" cellspacing="0" cellpadding="0"><tr><td class="ttc">
			<?php include 'ttdivnav.php';	?>
		</td></tr></table>

	<?php
	}else{ ?>
		<table width="100%" class="ttc" style="margin:0px <?php echo $maxmarg; ?>px;max-width:<?php echo $maxbreed; ?>px;"><tr><td class="ttc"><font style="font-size:13px;">Geen resultaten gevonden voor &#39;<?php echo $zoek; ?>&#39;.</font></td></tr></table>
	<?php
	} ?>
	</div>
	<br>

	<?php
	odbc_free_result($fprs);
	unset($fprs);
	odbc_close($objConnect);
}
?>
<table border="1" width="100%" style="border-collapse: collapse" bordercolor="#E1E1E1"><tr><td>
	<br>
	<div align="right"><font class="copynotice">SCORS&nbsp;v3.0&nbsp;<?php if ($rechten=="mo" or $rechten=="sup"){echo "Administratie&nbsp;";} ?>&copy;<?php echo date('Y') ?>&nbsp;RFJ van Linden</font></div>
</td></tr></table>