<?php
// SCORS Conditions en Disclaimer
//
// Copyright ©2024 R.F.J. van Linden (rob@vlinden.com)
//
// Permission is hereby granted, free of charge and for
// non-commercial use only, to any person obtaining a
// copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including // without limitation the rights
// to use, copy, modify, merge, publish, and/or distribute
// copies of the Software, and to // permit persons to whom
// the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice
// shall be included in all copies or substantial portions
// of the Software.
// The Software must only be used for non-commercial purposes.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
// KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
// OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include "checks.php";

//check of is ingelogd
if ($rechten!="mo" and $rechten!="sup"){exit();}
$objConnect=odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=db/audiovideo.mdb","","");

$bronadres=$_SERVER["REMOTE_ADDR"];
$zinDate=date("Y-M-d");
$zinTime=date("h.i.s");
$logfile="log/scorsaudiovideolog.txt";
$Key="";$zin="";$uitzin="";
$aktie="";

function diak($inputString) {
    // Replace diacritical characters for single-byte characters
    $replaceTable = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
        'Å'=>'A', 'Æ'=>'Ae', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
        'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
        'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O',
        'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
        'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'Th',
        'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
        'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e',
        'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i',
        'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n', 'ò'=>'o',
        'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o',
        'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y',
        'þ'=>'th', 'ÿ'=>'y', '"'=>'', "'"=>''
    );
    $inputString=strtr($inputString, $replaceTable);
	iconv('UTF-8', 'ASCII//TRANSLIT', $inputString);
	// verwijder ongeldige karakters in de inputstring
	$karyes="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?-1234567890#.,/()= :";
	for ($i=0;$i<strlen($inputString);$i++){
		$hulp=substr($inputString,$i,1);
		if (strpos($karyes, $hulp)===false){
			$inputString=str_replace($hulp," ",$inputString);
		}
	}
	$inputString=trim(str_replace("  "," ",$inputString));
    return $inputString;
}

function verwijder($sleutel){
	error_reporting(0);
	unlink("AV/".$sleutel.".mp3");
	unlink("AV/".$sleutel.".mp4");
	unlink("AV/".$sleutel.".jpg");
	unlink("AV/".$sleutel."t.jpg");
	error_reporting(-1);
	return;
}

// Lees de aktie die moet worden uitgevoerd: 
// edit: wijzig bestaande gegevens
// del: verwijder record
// nieuw: voeg bij submit gegevens uit form voor nieuwe AV toe in database
// watermerk: zet 360graden of youtube watermerk over thumb in edit scherm
if ($_SERVER['REQUEST_METHOD']=="POST"){
	$now = new DateTime( 'NOW' );
	$diffSeconds = $now->getTimestamp();
	if (ISSET($_POST["aktie"])){$aktie=$_POST["aktie"];}
	$submittekst="";
	if (ISSET($_POST["submittekst"])){$submittekst=$_POST["submittekst"];}
	if (ISSET($_POST["Key"])){$Key=$_POST["Key"];}

	// Voer de gevraagde aktie uit en maak een zin voor de logfile
	// Voor Youtube videos gebruik de syntax: <code>https://www.youtube.com/embed/<i>Youtube-nummer</i></code><br>b.v. https://www.youtube.com/embed/4od4OfSdB9U<br><br>
	// Voor Youtube thumbs gebruik de syntax: <code>https://i.ytimg.com/vi/<i>Youtube-nummer</i>/hqdefault.jpg</code><br>b.v. <code>https://i.ytimg.com/vi/4od4OfSdB9U/hqdefault.jpg</code><br><br>
	if($submittekst=="Sla op"){ //haal gegevens uit form
		$ytcode=$_POST["ytcode"];
		$sfcode=$_POST["sfcode"];
		$viewer=$_POST["viewer"];
		$doel=$_POST["doel"];
		$titel=diak($_POST["titel"]);
		$jmd=diak($_POST["jmd"]);
		$jaarsort=diak($_POST["jaarsort"]);
		$auteur=diak($_POST["auteur"]);
		$uitgever=diak($_POST["uitgever"]);
		$beschrijving=diak($_POST["beschrijving"]);
		$keyframe=$_POST["keyframe"];if($keyframe==""){$keyframe=0;}
		if($aktie=="nieuw"){ //maak een leeg record en lees de nieuwe Key
			$fprs=odbc_exec($objConnect,"INSERT INTO av (titel,toevoeger,ts,tse) VALUES ('___NIEUW___','".$user."','".strval($diffSeconds)."','".strval($diffSeconds)."')");
			$fprs=odbc_exec($objConnect,"SELECT Key,titel FROM av WHERE titel='___NIEUW___'");
			$row=odbc_fetch_array($fprs);$Key=$row["Key"];
		}
		//werk mediabestanden bij
		if($viewer=="youtube" or $viewer=="sketchfab"){ //Youtube
			verwijder($Key);
		}else{ //eigen bestand
			if (file_exists("AV/temp.jpg")) { //er is een panorama upload
				verwijder($Key);
				$filename="AV/".$Key.".jpg";
				$thumbnailFile = "AV/".$Key."t.jpg";
				rename("AV/temp.jpg",$filename);
				ini_set('memory_limit', '512M');
				$tempfile=imagecreatefromjpeg($filename);
			// 	Get current image size
				$srcW = imagesx($tempfile);$srcH = imagesy($tempfile);
				$resW = $srcW;$resH = $srcH;
			//	Calculate scale
				$xScale = $srcW / 299;$yScale = $srcH / 250;
			//	Calculate new width and height
				if ($yScale > $xScale){$resW = round($srcW * (1/$yScale));$resH = round($srcH * (1/$yScale));}
				else {$resW = round($srcW * (1/$xScale));$resH = round($srcH * (1/$xScale));}
				$resimage = @imagecreatetruecolor($resW,$resH);
				imagecopyresampled($resimage, $tempfile, 0, 0, 0, 0, $resW, $resH, $srcW, $srcH);
				imagejpeg($resimage, $thumbnailFile, 85);
				imagedestroy($tempfile);
				imagedestroy($resimage);
			}else if(file_exists("AV/temp.mp3")){ //er is een mp3 upload
				verwijder($Key);
				$filename="AV/".$Key.".mp3";
				rename("AV/temp.mp3",$filename);
			}else if(file_exists("AV/temp.mp4")){ //er is een nieuwe mp4 upload
				verwijder($Key);
				$filenaam="AV/".$Key.".mp4";
				rename("AV/temp.mp4",$filenaam);
				$filenaam="AV/".$Key."t.jpg";
				rename("AV/tempt.jpg",$filenaam);
			}else if(file_exists("AV/tempt.jpg")){ //er is een nieuwe mp4 thumbnail
				$filenaam="AV/".$Key."t.jpg";
				unlink($filenaam);
				rename("AV/tempt.jpg",$filenaam);
			}
		}
		//werk database bij
		$fprs=odbc_exec($objConnect,"UPDATE av SET tse=".strval($diffSeconds).",aanpasser='".$user."',keyframe='".strval($keyframe)."',viewer='".$viewer."',jaarsort='".$jaarsort."',doel='".$doel."',titel='".$titel."',jmd='".$jmd."',auteur='".$auteur."',uitgever='".$uitgever."',sfcode='".$sfcode."',ytcode='".$ytcode."',beschrijving='".$beschrijving."' WHERE Key=".$Key);
		//werk thumbnail voor eigen video bij indien van toepassing
		if (!empty($_POST["thumbnail"])) {
			$thumbnailData = $_POST["thumbnail"];
			$thumbnailData = str_replace('data:image/jpeg;base64,', '', $thumbnailData);
			$thumbnailData = base64_decode($thumbnailData);
			$thumbnailPath = "AV/".$Key."t.jpg";
			file_put_contents($thumbnailPath, $thumbnailData);
		}
		//tekst voor logfile
		$zin="AudioVideo ".$titel." ".$jmd." toegevoegd/aangepast";
		$uitzin="<font color=red><b>"."AudioVideo ".$titel." ".$jmd." toegevoegd/aangepast"."</b></font><br><br>";
		// Close connection
		unset($fprs);
		odbc_close($objConnect);
		unset($objConnect);
		echo "OK";
	}
	else if($submittekst=="Verwijder dit item"){
		$titel=diak($_POST["titel"]);
		$jmd=diak($_POST["jmd"]);
		$fprs=odbc_exec($objConnect,"DELETE FROM av WHERE key=".$Key);
		$zin="AudioVideo ".$titel." ".$jmd." verwijderd";
		verwijder($Key);
		// Close connection
		unset($fprs);
		odbc_close($objConnect);
		unset($objConnect);
		echo "OK";
	}else{ //alleen bestand gekozen voor eigen file. Pre-upload middels xmlhttp t.b.v. de tijdelijke thumb generation zonder definitieve opslag.
		if(strlen($_FILES["orgfilename"]["tmp_name"])>0){ //er is een upload
			$bestandstype=strtolower(pathinfo($_FILES["orgfilename"]["name"],PATHINFO_EXTENSION));
			$renamedfile="AV/temp.".$bestandstype;
			move_uploaded_file($_FILES["orgfilename"]["tmp_name"], $renamedfile);
			echo $renamedfile;
		}else{
			echo "OK";
		}
		//werk thumbnail voor eigen video bij indien van toepassing
		if (!empty($_POST["thumbnail"])) {
			$thumbnailData = $_POST["thumbnail"];
			$thumbnaam = $_POST["thumbnaam"];
			$thumbnailData = str_replace('data:image/jpeg;base64,', '', $thumbnailData);
			$thumbnailData = base64_decode($thumbnailData);
			if($aktie=="thumbcreate"){$thumbnailPath = "AV/".$thumbnaam."t.jpg";}
			file_put_contents($thumbnailPath, $thumbnailData);
			echo "OK";
		}
	}

// Update logfile
	$zin=$zinDate." ".$zinTime." ip:".$bronadres." user:".$_COOKIE["user"]." ".$zin.chr(13).chr(10);
	$oTextFile = fopen($logfile, "a");
	fwrite($oTextFile,$zin);
	fclose($oTextFile);
	if (filesize($logfile)>(2*1024*1024)){ //logfile groter dan 2MB. Nieuwe file
		$newname="log/scorsaudiovideolog_".$zinDate."_".$zinTime.".txt";
		rename ($logfile,$newname);
		$oTextFile = fopen($logfile, "a");
		fwrite($oTextFile,"Log recycled: ".$newname.chr(13).chr(10));
		fclose($oTextFile);
	}

}else{ //not POST

	$aktie=$_REQUEST["aktie"];

	if($aktie=="watermerk"){ //Zet watermerk in thumbpath

		if ($_REQUEST["soort"]=="video"){$inlay="images/playvideo.png";}
		if ($_REQUEST["soort"]=="panorama"){$inlay="images/360.png";}
		if ($_REQUEST["soort"]=="eigenvid"){$inlay="images/eigenvideo.png";}
		$filenaam = imagecreatefromjpeg($_GET['filenaam']);
	//  Get current image size
		$srcW = imagesx($filenaam);
		$srcH = imagesy($filenaam);
		$resW = $srcW;
		$resH = $srcH;
	//	Calculate scale
		$xScale = $srcW / 299;
		$yScale = $srcH / 250;
	//	Calculate new width and height
		if ($yScale > $xScale){
			$resW = round($srcW * (1/$yScale));
			$resH = round($srcH * (1/$yScale));
		}
		else {
			$resW = round($srcW * (1/$xScale));
			$resH = round($srcH * (1/$xScale));
		}
		header ('Content-Type: image/jpeg');
		$resimage = @imagecreatetruecolor($resW,$resH);
		$watermerk = imagecreatefrompng($inlay);
		imagealphablending($watermerk,true);
		imagesavealpha($watermerk, true);
		$wmW=imagesx($watermerk);
		$wmH=imagesy($watermerk);
		$xpositie=($resW-$wmW)/2;
		$ypositie=($resH-$wmH)/2;
		imagecopyresampled($resimage, $filenaam, 0, 0, 0, 0, $resW, $resH, $srcW, $srcH);
		imagecopy($resimage, $watermerk, $xpositie, $ypositie, 0, 0, $wmW, $wmH);
		imagejpeg($resimage);
		imagedestroy($filenaam);
		imagedestroy($resimage);
		
	}
}